// Fill out your copyright notice in the Description page of Project Settings.

#include "CombatHUD.h"
#include "Components/WidgetComponent.h"
#include "Blueprint/UserWidget.h"



void ACombatHUD::BeginPlay()
{
	Super::BeginPlay();
}

void ACombatHUD::CreateWorldWidget(UWidgetComponent* WidgetComponent)
{

	if(!IsValid(WidgetComponent)) return;
	
	CharacterWidgetComponent = WidgetComponent;
	CharacterWidgetComponent->SetWidgetClass(WorldWidgetClass);
	CharacterWidgetComponent->SetWidgetSpace(EWidgetSpace::Screen);
	CharacterWidgetComponent->SetDrawAtDesiredSize(true);
	//auto* WidgetHealth = Cast<UWorldWidget>(CharacterWidgetComponent->GetWidget());
	
}

void ACombatHUD::CreateScreenWidgets(UStatsWidgetComponent* StateWidgetComp)
{
	if(!ScreenWidgetClass) return;
	
	ScreenWidget = Cast<UScreenWidget>(CreateWidget(GetWorld(), ScreenWidgetClass ));
	ScreenWidget->AddToViewport();
	ScreenWidget->InitializeScreenWidget(StateWidgetComp);
}
