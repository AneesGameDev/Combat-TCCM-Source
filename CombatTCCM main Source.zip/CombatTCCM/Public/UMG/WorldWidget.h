// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "WorldWidget.generated.h"

/**
 * 
 */
UCLASS(Abstract)
class COMBATTCCM_API UWorldWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	

	UPROPERTY()
	class UStatsWidgetComponent* StatsWidgetComponent;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite , meta=(BindWidget))
	class UProgressBar* HealthBar;
	UPROPERTY(EditAnywhere, BlueprintReadWrite , meta=(BindWidget) )
	class UTextBlock* HealthText;
UFUNCTION()
	void SetHealthPercentage(float Value);

	UFUNCTION()
	void InitializeWorldWidget(class UStatsWidgetComponent* OwnerStatsWidgetComponent);
	

	
	
};