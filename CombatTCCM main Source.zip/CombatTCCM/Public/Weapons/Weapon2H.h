// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Weapons.h"
#include "Components/BoxComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/SphereComponent.h"
#include "GameFramework/Actor.h"
#include "Structs/S_WeaponStats.h"
#include "Weapon2H.generated.h"

UCLASS()
class COMBATTCCM_API AWeapon2H : public AWeapons
{
	GENERATED_BODY()
   

	
public:	
	// Sets default values for this actor's properties
	AWeapon2H();
	
	
	UPROPERTY(BlueprintReadWrite,EditAnywhere, Replicated)
	USkeletalMeshComponent* WeaponMesh;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	USceneComponent* WeaponRootSceneComponent;


	
	UPROPERTY(EditAnywhere, BlueprintReadWrite , Category= "StringNames")
	FName EquipeHandSocketName;
	UPROPERTY(EditAnywhere, BlueprintReadWrite , Category= "StringNames")
	FName HostlerSocketName;
	UPROPERTY(EditAnywhere, BlueprintReadWrite , Category= "StringNames")
	FName HostlerWeaponAnimMontageName ="HostlerWeaponMontag";
	UPROPERTY(EditAnywhere, BlueprintReadWrite , Category= "StringNames")
	FName DrawWeaponAnimMontageName ="DrawWeaponMontag";
	UPROPERTY(EditAnywhere, BlueprintReadWrite , Category= "StringNames")
	FName AttackTraceMeshProfileName ="PlayerMeshProfile";
	FTimerHandle TimerHandle;



	//Attack Mechanics Sockets Variable
private:

	
protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	virtual void EquippeWeapon(ACombatPlayerCharacter* _instigator) override;
	/*UFUNCTION(NetMulticast, Reliable)
	void Multicast_EquippeWeapon(ACombatPlayerCharacter* _instigator);*/
	

	//This Function Will Run On Server From Interact Component and call Multicast Function
	virtual void DrawAndSheathWeapon() override;
	//UFUNCTION(NetMulticast, Reliable)
	//void Multicast_DrawAndSheathWeapon(ACombatPlayerCharacter* _instigator, FName MontageName , bool AttachWeapon , USkeletalMeshComponent* WeaponMesh , FName HostlerSocketName);

	//This Function Will Run On Server and Replicated Variable Will Update Shield Animations
	//UFUNCTION()
	virtual void DrawAndSheathShieldAssaults( bool Pressed) override;
	
	//This Function is Called From Server from Interact Component and Also Called Another Multicast Function Given Below
	virtual void StartAttackVisuals() override;
	/*UFUNCTION(NetMulticast, Reliable)
	void Multicast_StartAttackVisuals(ACombatPlayerCharacter* _instigator , int32 MontageId);*/
	
	virtual void EndAttackVisuals() override;


	//AttackMechanics
	virtual void SetStartAttackSocketLocation() override;
	virtual void StartAttackMechanics(int32 DualWeildIndex) override;
	virtual void EndAttackMechanics() override;
//	UFUNCTION()
   // virtual void StartAttackWeaponLineTraces() override;
	//UFUNCTION(NetMulticast, Reliable)
	

	// TTuple<FName, UE::Math::TVector<double>> SocketEntry; 
//	UFUNCTION()
//	virtual void EndSocketLocationAndTraceLine() override;
	//Multiplayer Functions




//	void AddHittedCharacterInfo(ACombatPlayerCharacter* Player, FHitResult HitResult);
	
	
	


};


