// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Weapons.h"
#include "GameFramework/Actor.h"
#include "DualWield.generated.h"

UCLASS()
class COMBATTCCM_API ADualWield : public AWeapons 
{
	GENERATED_BODY()

	
public:	
	// Sets default values for this actor's properties
	ADualWield();

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	class USkeletalMeshComponent* RightWeaponMesh;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	class USkeletalMeshComponent* LeftWeaponMesh;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	class USceneComponent* WeaponRootSceneComponent;

	
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FName EquipeLeftHandSocketName;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FName EquipeRightHandSocketName;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FName HostlerLeftSocketName;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FName HostlerRightSocketName;
	FTimerHandle TimerHandle;

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;
	
	void EquippeWeapon(ACombatPlayerCharacter* _instigator) override;
	/*UFUNCTION(NetMulticast, Reliable)
	void Multicast_EquippeWeapon(ACombatPlayerCharacter* _instigator);*/
	
	//This Function Will Run On Server From Interact Component and call Multicast Function
	void DrawAndSheathWeapon() override;
	/*UFUNCTION(NetMulticast, Reliable)
	void Multicast_DrawAndSheathWeapon(ACombatPlayerCharacter* _instigator, FName MontageName , bool AttachWeapon);*/
	
	//This Function is Called From Server from Interact Component and Also Called Another Multicast Function Given Below
	void StartAttackVisuals() override;
	/*UFUNCTION(NetMulticast, Reliable)
	void Multicast_StartAttackVisuals(ACombatPlayerCharacter* _instigator , int32 MontageId);*/

	//This Function Will Run On Server and Replicated Variable Will Update Shield Animations
	void DrawAndSheathShieldAssaults(bool Pressed) override;

	virtual void EndAttackVisuals() override;



	virtual void SetStartAttackSocketLocation() override;
	virtual void StartAttackMechanics(int32 DualWeildIndex) override;
	virtual void EndAttackMechanics() override;

	void RightStartAttackMechanics();
	void LeftStartAttackMechanics();
	void DualStartAttackMechanics();
	
	
};
