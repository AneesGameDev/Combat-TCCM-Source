// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "CombatTCCM/CombatPlayerCharacter.h"
#include "GameFramework/Actor.h"
#include "Structs/S_WeaponStats.h"
#include "Weapons.generated.h"



USTRUCT()
struct FHitAndBoneInfo
{
	GENERATED_BODY()
	
	UPROPERTY()
	FHitResult HitResult;
	UPROPERTY()
	TArray<FName> BoneNames;
};


UCLASS()
class COMBATTCCM_API AWeapons : public AActor 
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AWeapons();

	UPROPERTY(BlueprintReadWrite , EditAnywhere , Category="WeaponConfig")
	FS_WeaponStats WeaponStats;
	
    UPROPERTY(BlueprintReadWrite,EditAnywhere )
	ACombatPlayerCharacter* OwnerPlayerCharacter;//Replicated before
	UPROPERTY(BlueprintReadWrite, EditAnywhere )//Replicated before
	UInteractComponent* OwnerInteractComponent;
	UPROPERTY(BlueprintReadWrite , EditAnywhere)
	UStatsWidgetComponent* OwnerHealthComponent;
	UPROPERTY(EditAnywhere,BlueprintReadWrite  )
	int32 AttackComboAnimCount =0;
	UPROPERTY(BlueprintReadWrite , EditAnywhere) //Replicated before
	bool WeaponDrawState;


	//Temporary Variables
	UPROPERTY()
	FVector AttackLocation;
	UPROPERTY()
	FVector AttackDirection;


	/*Attack Mechanics Varaible is Here and Use Mostly in Child Classed
	 *
	 */
	UPROPERTY(EditAnywhere)
	TMap<ACombatPlayerCharacter* , FHitAndBoneInfo> HittedCharacterInfo;
	UPROPERTY()
	TMap<FName, FVector> PreviousSocketLocations;
	UPROPERTY(Replicated)
	TArray<FName> AllSocketName;
	UPROPERTY()
	TArray<AActor*> ActorsToIgnore;


	UPROPERTY(EditAnywhere,BlueprintReadWrite , Replicated )
	 class UPhysicsConstraintComponent* LeftHandPhysicsConstraintComponent;
	UPROPERTY(EditAnywhere,BlueprintReadWrite, Replicated)
	 class UPhysicsConstraintComponent* RightHandPhysicsConstraintComponent;

	
	
protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	//  Called every frame
	virtual void Tick(float DeltaTime) override;

	// Virtual Overrided Functions From Interface ICombatInputInterface
	UFUNCTION()
	virtual void Interaction(bool pressed) ;
	UFUNCTION()
	virtual void EquippeWeapon(ACombatPlayerCharacter* _instigator);
	UFUNCTION()
	virtual void DrawAndSheathWeapon();
	UFUNCTION()
	virtual void DrawAndSheathShieldAssaults(bool Pressed);
	
	UFUNCTION()
	virtual void StartAttackVisuals(); //Function Run On Server But Need to Optimize code
	UFUNCTION()
	virtual void SetAimingWeaponDirection(); //Temporary Function for making logic to run
	UFUNCTION()
	virtual void EndAttackVisuals();

	UFUNCTION(NetMulticast, Reliable)
	void Multicast_DrawandSheathWeapon(ACombatPlayerCharacter* _instigator, FName MontageName , USkeletalMeshComponent* WeaponMesh , FName HostlerSocketName);

	UFUNCTION(NetMulticast, Reliable)
	void Multicast_PlayAnimationMontage(ACombatPlayerCharacter* _instigator ,FName AnimationName);
	

	virtual  void SetStartAttackSocketLocation();
		
	virtual void StartAttackMechanics(int32 DualWeildIndex);
	//virtual void StartAttackMechanics(int32 DualWeildIndex);

	virtual void EndAttackMechanics();

	
protected:

	UFUNCTION()
	void AddHittedCharacterInfo(ACombatPlayerCharacter* Player, FHitResult HitResult);

	/*UFUNCTION()
	void AddHittedCharacterinArray(ACombatPlayerCharacter* PlayerCharacter);*/
	UFUNCTION()
	void SetSingleHandWeaponSocketNames(TArray<USkeletalMeshComponent*> MeshComponent);
	UFUNCTION()
	void SetDualHandWeaponSocketNames(TArray<USkeletalMeshComponent*> MeshComponent);

	void SetStartMeshSocketLocations(USkeletalMeshComponent* MeshComponent);

private:
	

};

