// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Weapons.h"
#include "Components/BoxComponent.h"
#include "GameFramework/Actor.h"
#include "Structs/S_WeaponStats.h"
#include "Fists.generated.h"

UCLASS()
class COMBATTCCM_API AFists : public AWeapons
{
	GENERATED_BODY()

	/*ACombatPlayerCharacter* PlayerCharacter;
	UInteractComponent* InteractComponent;*/
	
public:	
	// Sets default values for this actor's properties
	AFists();
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	 USceneComponent* RootSceneComponent;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	 UBoxComponent* LeftHandBox;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	 UBoxComponent* RightHandBox;

		
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FName LeftHandFistsSocket;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FName RightHandFistsSocket;
	FTimerHandle TimerHandle;

	int32 AttackComboAnimCount;
	bool ActiveAbility = false;
	bool ActiveShield=false;

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;
    /*
    virtual void equippeFists(ACombatPlayerCharacter* instigator);
	virtual void ApplyFistAttack(ACombatPlayerCharacter* instigator);
	virtual void ApplyFistsSheild(ACombatPlayerCharacter* instigator,bool Pressed);
	*/
	virtual void EquippeWeapon(ACombatPlayerCharacter* instigator) override;
	virtual void DrawAndSheathWeapon() override;
	virtual void StartAttackVisuals() override;
	virtual void DrawAndSheathShieldAssaults( bool Pressed) override;

};
