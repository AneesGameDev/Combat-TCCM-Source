// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Weapons/Weapons.h"
#include "Components/BoxComponent.h"
#include "Fist.generated.h"

class UBoxComponent;
/**
 * 
 */
UCLASS()
class COMBATTCCM_API AFist : public AWeapons
{
	GENERATED_BODY()
	
	
public:	
	// Sets default values for this actor's properties
	AFist();
	
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	USceneComponent* RootSceneComponent;

	
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TArray<FName> LeftHandSocketNameArray;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TArray<FName> RightHandSocketNameArray;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FName LeftHandSocketName;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FName RightHandSocketName;
	FTimerHandle TimerHandle;


	
protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	virtual void EquippeWeapon(ACombatPlayerCharacter* _instigator) override;
	virtual void DrawAndSheathWeapon() override;
	
	// Function Will Run OnServer Call From InteractComponent And Update replicated Variable to Update Animation Sequence 
	virtual void DrawAndSheathShieldAssaults(bool Pressed) override;
	
	// Function Will Run On Server and Call Multicast Function
	virtual void StartAttackVisuals() override; 
	//virtual void StartAttackMechanics(FHitResult& HitResult , ACombatPlayerCharacter* HitCharacter);
	virtual void EndAttackVisuals() override;
	//virtual void EndAttackMechanics() override;
	

	/*
	UFUNCTION(NetMulticast, Reliable)
	void Multicast_StartAttackVisuals(ACombatPlayerCharacter* _instigator , int32 MontageId);
	*/




	virtual void SetStartAttackSocketLocation() override;
	virtual void StartAttackMechanics(int32 DualWeildIndex) override;
	virtual void EndAttackMechanics() override;
	//UFUNCTION(NetMulticast, Reliable)
	//void Server_StartDarwAndSheathShieldAssaults(ACombatPlayerCharacter* _instigator,bool pressed);

	
};
