// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ArcheryArrowProjectile.h"
#include "Components/CameraZoomComponent.h"
#include "Weapons/Weapons.h"
#include "ArcheryAssaults.generated.h"

/**
 * 
 */
UCLASS()
class COMBATTCCM_API AArcheryAssaults : public AWeapons
{
	GENERATED_BODY()

	
	
public:
	AArcheryAssaults();
	
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	class UStaticMeshComponent* ArcheryMesh;
	UPROPERTY(EditAnywhere, BlueprintReadWrite )
	class UStaticMeshComponent* QuiverMesh;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	class USceneComponent* RootSceneComponent;
	UPROPERTY(EditAnywhere, BlueprintReadWrite , Category="ClassReferences")
	TSubclassOf<AArcheryArrowProjectile> ArcheryArrowProjectileClass;

	
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FName AttackTraceMeshProfileName;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FName EquipeLeftHandSocketName;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FName EquipeRightHandSocketName;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FName HostlerLeftSocketName;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FName HostlerRightSocketName;
	FTimerHandle TimerHandle;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float VelocityMultiplier;
	UPROPERTY(EditAnywhere, BlueprintReadWrite , Category="Object")
	AArcheryArrowProjectile* ArcheryArrowProjectileObject;

	//Components to Attached
	UPROPERTY(EditAnywhere, BlueprintReadWrite ,Category = "ZoomComponent")
    UCameraZoomComponent* CameraZoomComponent;


private:
	/*UPROPERTY(Replicated)
	FVector StartAttackLocation ;
	UPROPERTY(Replicated)//= 	OwnerPlayerCharacter->GetFollowCamera()->GetComponentLocation();
	FVector AttackDirection;
	UPROPERTY(Replicated)
	FVector EndAttackLocation ;*/
protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	virtual void EquippeWeapon(ACombatPlayerCharacter* _instigator) override;
	UFUNCTION(NetMulticast, Reliable)
	void Multicast_EquippeWeapon(ACombatPlayerCharacter* _instigator);

	//This Function Will Run On Server From Interact Component and call Multicast Function
	virtual void DrawAndSheathWeapon() override;
	UFUNCTION(NetMulticast, Reliable)
	void Multicast_DrawAndSheathWeapon(ACombatPlayerCharacter* _instigator, FName MontageName , bool AttachWeapon);

	//This Function is Called From Server from Interact Component and Also Called Another Multicast Function Given Below
	virtual void StartAttackVisuals() override;
	UFUNCTION(NetMulticast, Reliable)
	void Multicast_StartAttackVisuals(ACombatPlayerCharacter* _instigator , int32 MontageId);

	//This Function Will Run On Server and Replicated Variable Will Update Shield Animations
	
	virtual void DrawAndSheathShieldAssaults(bool Pressed) override;

	//UFUNCTION(Client, Reliable)
	void CameraZoomeClientRPC(bool Pressed);
	UFUNCTION(Server, Reliable)
	void MulticastDrawAndSheathShieldAssaults(bool Pressed);

	virtual void StartAttackMechanics(int32 DualWeildIndex) override;

	void SetAimingWeaponDirection() override;
	virtual void SetStartAttackSocketLocation() override;
	UFUNCTION(Client,Reliable)
	void ClientSetViewPortLocation();
    UFUNCTION(Server,Reliable)
	void ServerStartAtatckSocketLocation();
	UFUNCTION(NetMulticast ,Reliable)
	void MulticastArrowMovingEffect(FVector Direction);
	//virtual void StartAttackMechanics(FHitResult& HitResult , ACombatPlayerCharacter* HitCharacter);
	virtual void EndAttackVisuals() override;

	UFUNCTION(Server, Reliable)
	void AimingActorUpdateLocation();
	UFUNCTION(NetMulticast , Reliable)
	void SetActorRotationInMultiplayer(ACombatPlayerCharacter* PlayerCharacter ,FRotator NewRotation);

	
	virtual void EndAttackMechanics() override;

	/*UFUNCTION(BlueprintImplementableEvent , BlueprintCallable)
	void StartAttackMechanicsEvent() = delete;*/

	UFUNCTION(BlueprintNativeEvent, Category = "MyEvents")
	void CustomStartAttackEvent();
	
};
