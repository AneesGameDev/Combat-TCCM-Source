// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "CombatTCCM/CombatPlayerCharacter.h"
#include "Components/ActorComponent.h"
#include "UMG/CrossHairWidget.h"
#include "CameraZoomComponent.generated.h"


UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) , BlueprintType)
class COMBATTCCM_API UCameraZoomComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	UCameraZoomComponent();

	protected:
	
	UPROPERTY(EditDefaultsOnly, Category = "Camera")
	float ZoomedFOV = 70.0f;
	UPROPERTY(EditDefaultsOnly, Category = "Camera")
	float ZoomedCameraArmLength = -70.0f;
	UPROPERTY(EditAnywhere, Category ="Camera")
	FVector3d ZoomedSocketOffset = FVector3d(20.f,0.f,60.f);
	UPROPERTY(EditAnywhere, Category ="Camera")
	FVector3d ZoomedTargetOffset = FVector3d(0.f,0.f,0.f);
	UPROPERTY(EditAnywhere, Category ="Camera")
	float ZoomedCameraMaxPitch =30.f;
	UPROPERTY(EditAnywhere, Category ="Camera")
	float ZoomedCameraMinPitch = -80.f;


	//State Of Zoome Camera
	bool bIsZoomedIn = false;


//Widget and UIs Of Zoomed COmpoennt
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSubclassOf<UCrossHairWidget> CrossHairWidgetClass;
	UCrossHairWidget* CrossHairWidgetObj;

protected:
	// Called when the game starts
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	
	//UPROPERTY(BlueprintCallable)
   // void ToggleZoom(ACombatPlayerCharacter* PlayerCharacter);
   // UPROPERTY(BlueprintCallable)
	UFUNCTION()
	void ToggleCameraZoomed(bool bNewZoomed , ACombatPlayerCharacter* PlayerCharacter);

		
};
