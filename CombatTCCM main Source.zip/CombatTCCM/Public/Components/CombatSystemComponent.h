// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Weapons/Weapons.h"
#include "CombatSystemComponent.generated.h"

/*struct FHitInfo
{
	FHitResult HitResult;
	TArray<FName> BoneNames;
};*/


UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class COMBATTCCM_API UCombatSystemComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	UCombatSystemComponent();
     //Hitted Bone Names
	/*
	TArray<ACombatPlayerCharacter*> HittedActorsArray;
	TMap<ACombatPlayerCharacter*, FHitInfo> HittedActorsInfo;
	*/

protected:
	// Called when the game starts
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	void CombatSystemAttackFunctionality(FHitResult& HitResult, AWeapons* EquippedWeapon , ACombatPlayerCharacter* Character);
	
	void CombatSystemAttackFunctionalityRun(AWeapons* EquippedWeapons,const UInteractComponent* OwneInteractComponent);

	float GetMaxDamageFromBoneList(const TArray<FName>& BoneNames ,const UInteractComponent* OwnerInteractComponent);
};
