// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "CombatSystemComponent.h"
#include "CombatTCCM/CombatPlayerCharacter.h"
#include "Components/ActorComponent.h"
#include "FiniteStateMachine/StatesManagerComponent.h"
#include "Interfaces/InteractionMechanicsInterface.h"
#include "Shields/Shields.h"
#include "Structs/S_WeaponStats.h"
#include "Weapons/Weapons.h"
#include "InteractComponent.generated.h"


UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class COMBATTCCM_API UInteractComponent : public UStatesManagerComponent  , public IInteractionMechanicsInterface
{
	GENERATED_BODY()
    int32 WeaponIndexIncrement=1;
	int32 CurrentWeaponIndex=0;

	int32 ShieldIndexIncrement = 0;
	int32 CurrentShieldIndex = 0;
	
public:

	
	// Sets default values for this component's properties
	UInteractComponent();
	/*UFUNCTION(BlueprintCallable)
	static UInteractComponent* GetInteractComponent(AActor* Actor){return Actor ? (Actor->FindComponentByClass<UInteractComponent>()) : nullptr;}*/
	//Object Runtime To be get Reference is Here
    UPROPERTY(EditAnywhere, BlueprintReadWrite)
	ACombatPlayerCharacter* PlayerCharacter;
	UPROPERTY(EditAnywhere, BlueprintReadWrite  ,Replicated) //Replicated Before
	AWeapons* EquippedWeapon;
	UPROPERTY(EditAnywhere,BlueprintReadWrite  )//Replicated Before
	AWeapons* EquippeFist;
	UPROPERTY(EditAnywhere, BlueprintReadWrite ) //Replicated Before
	AShields* DefenceShield;

	//Data getting and updating runtime is here
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FS_WeaponStats WeaponStats;
	// UPROPERTY(EditAnywhere, BlueprintReadWrite , Replicated)
	// bool bIsStartSheildActivate =false;



	//Components Runtime To be get Reference is Here
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	UCombatSystemComponent* CombatSystemComponent;
	UPROPERTY(EditAnywhere, BlueprintReadWrite , Replicated)
	UStatsWidgetComponent* StatsWidgetComponent;

	
	
	/****************************************/

	//Data Set From Editor
    UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TArray<TSubclassOf<AWeapons>> WeaponsArray;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TArray<TSubclassOf<AShields>> ShieldsArray;

	
	//This Bone Damage Multiplier Data Will be Saved in Data Assets or in other data container
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TMap<FName, float> BoneDamageMultipliers;

	//UPROPERTY()
	//TMap<AWeapons*, FHitInfo> HittedActorsInfo;

 

protected:
	// Called when the game starts
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	

	//Interfaces form where we can call Private function Where Working Functionality of Each Action is Written
	
	 virtual void EquippeWeapon_Implementation(bool pressed) override;
	 virtual void DrawAndSheathWeapon_Implementation(bool pressed) override;
	 virtual void DrawAndSheathShield_Implementation(bool pressed) override;
	 virtual void StartPrimaryAttack_Implementation(bool pressed) override;
	 virtual void StartPrimaryDefence_Implementation(bool pressed) override;


	/*UFUNCTION(Server, Reliable)
	void ServerEquipWeapon(bool pressed);*/
	UFUNCTION(NetMulticast, Reliable)
	void EquipeWeaponMulticast(bool pressed);

	void TestingEquipeCharacterWithNewWeapon();

	UFUNCTION(Server, Reliable)
	void Server_EquipeFist(bool pressed);
	UFUNCTION(Server, Reliable)
	void Server_EquipeWeapon(bool pressed);
	UFUNCTION(Server, Reliable)
	void Server_StartPrimaryAttack(bool pressed , FVector AttackLocation ,FVector AttackDirection);

	void TemporarySetAimingDriection();
	UFUNCTION(Server,Reliable)
	void Server_StartPrimaryDefence(bool pressed) ;
	UFUNCTION(Server,Reliable)
	void Server_DrawAndSheathWeapon(bool pressed) ;
	UFUNCTION(Server,Reliable)
	void Server_DrawAndSheathShield(bool pressed) ;

	FORCEINLINE AWeapons* GetReadyWeapon() {return  {(IsValid(EquippedWeapon) && EquippedWeapon->WeaponDrawState) ? EquippedWeapon : (IsValid(EquippeFist)) ? EquippeFist : nullptr };} 
	
	
	// Public Simple Functions
	/*UFUNCTION(Server, Reliable)
	void SetWeaponEnableCollisions(bool bNewWeaponEnableCollision) ;*/

	/*
	UFUNCTION(Server,Reliable)
	void InitializeSocketBones();*/

	UPROPERTY()
	TMap<FName, FVector> PreviousSocketLocations;
	UPROPERTY(Replicated)
	TArray<FName> AllSocketName;
	UPROPERTY()
	TArray<AActor*> ActorsToIgnore;
	FName SocketName ;
	FVector PreviousSocketLocation;
	FVector StartLocation, EndLocation;
	/*UFUNCTION()
	void InteractAttackFunctionality(FHitResult& HitResult , ACombatPlayerCharacter* Character);
	*/

	UFUNCTION()
	void ApplyAttackMechanics(const FHitAndBoneInfo HitAndBoneInfo , AWeapons* AttackerWeapon);
	UFUNCTION()
	void EndAttackMechanics(AWeapons* Weapons) ;

	UFUNCTION()
	float GetCalculateMaxBoneDamage(TArray<FName> HittedBoneNames);
	UFUNCTION()
	float GetCalculateFinalDefenseDamage(AWeapons* AttackerWeapon);
	
private:
	
	    void equipCharacterWithNewWeapon();
	    void drawAndSheathWeapon();
	    void equipCharacterWithNewShield();
	    void equipeCharacterWithFists();

	
	
	    
};
