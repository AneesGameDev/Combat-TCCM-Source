// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "CombatTCCM/CombatPlayerCharacter.h"
#include "Components/ActorComponent.h"
#include "UMG/WorldWidget.h"
#include "UMG/ScreenWidget.h"
#include "StatsWidgetComponent.generated.h"


DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnPlayerHealthChange, float, Value);
UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class COMBATTCCM_API UStatsWidgetComponent : public UActorComponent
{
	GENERATED_BODY()


public:


	UStatsWidgetComponent();
	

	ACombatPlayerCharacter* OwnerPlayerCharacter;
	

	UPROPERTY(EditAnywhere,BlueprintReadWrite , ReplicatedUsing=OnRep_UpdateHealthWidget )
	float CharacterBaseHealth = 100;
	UPROPERTY(EditAnywhere,BlueprintReadWrite)
	float CharacterMaxHealth = 100;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, ReplicatedUsing= OnRep_UpdateStaminaWidget)
	float CurrentStamina =100.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float MaxStamina =100.f;
	// Widget Component on the top of character
	UPROPERTY(VisibleAnywhere )
	UWidgetComponent* CharacterWidgetComponent;
	
	UPROPERTY(EditAnywhere , BlueprintReadWrite , Category= "HealthWidgetReferences")
	TSubclassOf<UWorldWidget> WorldWidgetClass;
	UPROPERTY(EditAnywhere , BlueprintReadWrite , Category= "StaminaWidgetReferences")
	TSubclassOf<UScreenWidget> ScreenWidgetClass;

	UPROPERTY(BlueprintAssignable )
	FOnPlayerHealthChange PlayerHealthChangeDelegate;

	UPROPERTY()
	UScreenWidget* ScreenWidget;


	UPROPERTY()
	ACombatPlayerController* PlayerControllerRef;
	UPROPERTY()
	ACombatPlayerCharacter* OwnerPlayerCharacterRef;
protected:
	// Called when the game starts
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	UFUNCTION()
    void CreateWorldWidget(UWidgetComponent* WidgetComponent);

	UFUNCTION()
	void CreateScreenWidgets( );

	
	UFUNCTION()
    void SetHealthDamage(float Damage);
	UFUNCTION()
    bool SetStaminaDamage(float Damage);

	UFUNCTION()
	void IncreaseStaminaOverTime(float DeltaTime);
	
	
	UFUNCTION()
	void OnRep_UpdateHealthWidget() const;

	UFUNCTION()
	void OnRep_UpdateStaminaWidget() const;
	// UFUNCTION()
	// void CreateWorldWidgets()

	virtual void PostInitProperties() override;
	
		
};
