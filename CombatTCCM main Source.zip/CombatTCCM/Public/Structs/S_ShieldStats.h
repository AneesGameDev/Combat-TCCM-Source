﻿
#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "S_ShieldStats.generated.h"

USTRUCT(BlueprintType)
struct FS_ShieldStats
{
	FS_ShieldStats()
		: EquippedShieldObject(nullptr),
		  EquippedShieldClass(nullptr),
		  ShieldAmimationSequence(nullptr),
		  ShieldBaseDefenceMultiplier(0),
		  ShieldDefenceAngle(0)
	{
	}

	GENERATED_BODY()
	;
public:
	UPROPERTY(EditAnywhere , BlueprintReadWrite)
	AActor* EquippedShieldObject;
	UPROPERTY(EditAnywhere , BlueprintReadWrite)
	TSubclassOf<AActor> EquippedShieldClass;
	UPROPERTY(EditAnywhere , BlueprintReadWrite)
	UAnimSequenceBase* ShieldAmimationSequence; 
	UPROPERTY(EditAnywhere , BlueprintReadWrite)
	TMap<FString , UAnimMontage*> maSheathAnimations;
	UPROPERTY(EditAnywhere , BlueprintReadWrite)
	float ShieldBaseDefenceMultiplier;
	UPROPERTY(EditAnywhere , BlueprintReadWrite)
	int ShieldDefenceAngle;


};