// Fill out your copyright notice in the Description page of Project Settings.

#pragma once
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "../Enums/E_WeaponEquipped.h"
#include "S_WeaponStats.generated.h"

USTRUCT(BlueprintType)
struct FS_WeaponStats
{
	FS_WeaponStats()
		: EquippedWeaponObject(nullptr),
		  EquippedWeaponClass(nullptr),
		  WeaponType(EE_WeaponEquipped::None),
		  WeaponBaseDamage(0),
		  TakeStaminaPerAttack(0),
		  ShieldAmimationSequence(nullptr)
	{
	}

	GENERATED_BODY()
	;
	UPROPERTY(EditAnywhere , BlueprintReadWrite)
	AActor* EquippedWeaponObject;
	UPROPERTY(EditAnywhere , BlueprintReadWrite)
	TSubclassOf<AActor> EquippedWeaponClass;
	UPROPERTY(EditAnywhere , BlueprintReadWrite)
	EE_WeaponEquipped WeaponType;
	UPROPERTY(EditAnywhere , BlueprintReadWrite)
	float WeaponBaseDamage;
	UPROPERTY(EditAnywhere , BlueprintReadWrite)
	float TakeStaminaPerAttack;
	UPROPERTY(EditAnywhere , BlueprintReadWrite)
	TMap<FString , UAnimMontage*> maAttackAnimatios;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	int32 ComboAnimationCount;
	UPROPERTY(EditAnywhere , BlueprintReadWrite)
	TMap<FString , UAnimMontage*> SheathAnimations;
	UPROPERTY(EditAnywhere , BlueprintReadWrite)
	UAnimSequenceBase* ShieldAmimationSequence;

	/*UPROPERTY(EditAnywhere , BlueprintReadWrite)
	float BaseDmage;*/
	
	//TArray<UAnimMontage*> aAttackAnimations; 
	//TArray<UAnimMontage*> aSheathAnimations;

};



//#pragma once
//
//#include "CoreMinimal.h"
//#include "S_CharacterStats.generated.h"
//
//USTRUCT(BlueprintType)
//struct FS_CharacterStats
//{
//	GENERATED_BODY()
//
//}; 

