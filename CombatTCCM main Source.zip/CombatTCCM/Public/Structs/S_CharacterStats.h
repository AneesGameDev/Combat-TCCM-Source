// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "S_CharacterStats.generated.h"

USTRUCT(BlueprintType)
struct FS_CharacterStats
{
	GENERATED_BODY()
    FName CharacterName;
	int32 CharacterTeamId;
}; 

