// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "StatesManagerComponent.generated.h"

UENUM()
enum class E_MoveAxisStats :uint8 {
	
	None,
	Idle,
	Walk,
	Run
};

UENUM()
enum class E_MoveActionStats: uint8
{
	None,
	Crouch,
	Roll,
	Jump
	
};

/*enum class E_AttackStats: uint8
{
	None,
	Attacking,
	Shielding,
	
};*/

UENUM()
enum class E_AbilityStats: uint8
{
	None
};

UENUM()
enum class E_AttackStats: uint8
{
	None,
	StartAttack,
	EndAttack
};
UENUM()
enum class E_DefenceAssaultStats: uint8
{
	None,
	StartDefenceAssault,
	EndDefenceAssault
};
UENUM()
enum class E_Aiming: uint8
{
	None,
	StartAiming,
	EndAiming
};
UENUM()
enum class E_AttackingAndShielding :uint8
{
	None,
	Attacking,
	Shielding
};

UENUM()
enum class E_CharacterLockStats :uint8 {
	
  Unlocked,
	Locked
};


UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class COMBATTCCM_API UStatesManagerComponent : public UActorComponent
{
	
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	UStatesManagerComponent();
	
    UPROPERTY(Replicated)
	E_MoveAxisStats MoveAxisStats;
	UPROPERTY(Replicated)
	E_MoveActionStats MoveActionStats;
	UPROPERTY(Replicated)
	E_AttackStats AttackStates;
	UPROPERTY(Replicated)
	E_DefenceAssaultStats DefenceAssaultStats;
	UPROPERTY(Replicated)
	E_Aiming AimingStats;
	UPROPERTY(Replicated)
	E_AttackingAndShielding AttackingAndShielding;
    UPROPERTY(Replicated)
	E_CharacterLockStats CharacterLockStats;
	

protected:
	// Called when the game starts
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	bool CanMoveCharacter();
	bool CanRunCharacter();
	bool CanJumpCharacter();
	bool CanCrouchCharacter();
	bool CanRollCharacter();
	bool CanAttackCharacter();
	bool CanShieldAssaultCharacter();
	
		
};
