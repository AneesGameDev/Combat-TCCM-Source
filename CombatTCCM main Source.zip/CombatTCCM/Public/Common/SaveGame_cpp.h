// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/SaveGame.h"
#include "SaveGame_cpp.generated.h"

/**
 * 
 */
UCLASS()
class COMBATTCCM_API USaveGame_cpp : public USaveGame
{
	GENERATED_BODY()
	
};
