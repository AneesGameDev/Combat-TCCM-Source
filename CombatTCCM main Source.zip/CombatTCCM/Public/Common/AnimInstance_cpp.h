// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimInstance.h"
#include "../CombatPlayerCharacter.h"
#include "AnimInstance_cpp.generated.h"

/**
 * 
 */
UCLASS()
class COMBATTCCM_API UAnimInstance_cpp : public UAnimInstance
{
	GENERATED_BODY()


	virtual void NativeBeginPlay() override;
	virtual void NativeUpdateAnimation(float DeltaSeconds) override;


public:

	//UFUNCTION(BlueprintCallable);
	ACombatPlayerCharacter* GetCombatPlayerRef() const;
	UInteractComponent* GetInteractComponentRef() const;



public: 

	UPROPERTY(EditAnywhere, BlueprintReadWrite , Category="CharacterData")
	ACombatPlayerCharacter* PlayerCharacterRef;
	UPROPERTY(EditAnywhere, BlueprintReadWrite , Category="CharacterData")
	UInteractComponent* InteractComponentRef;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="CharacterData")
	float Speed;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="CharacterData")
	float Direction;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="CharacterData")
	bool binAir;
	UPROPERTY(EditAnywhere, BlueprintReadWrite,Category="CharacterData")
	float WalkRunAnimationRate;
	UPROPERTY(EditAnywhere, BlueprintReadWrite,Category="CharacterData")
	bool bIsCrouching;
	UPROPERTY(EditAnywhere, BlueprintReadWrite,Category="CharacterData")
	bool bIsIdle;
	UPROPERTY(EditAnywhere, BlueprintReadWrite,Category="CharacterData")
	bool bIsAiming;

	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="CharacterAnimationStates")
	UAnimSequenceBase* ShieldAnimationSequence;
	
   UPROPERTY(EditAnywhere,BlueprintReadWrite)
	bool bIsShieldActive;

	UPROPERTY(EditAnywhere,BlueprintReadWrite)
	bool bIsAttackActive;



};
