// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Shields/Shields.h"
#include "BucklerShield.generated.h"

/**
 * 
 */
UCLASS()
class COMBATTCCM_API ABucklerShield : public AShields
{
	GENERATED_BODY()
	
};
