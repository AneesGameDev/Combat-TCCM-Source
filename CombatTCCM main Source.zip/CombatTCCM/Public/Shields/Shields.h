// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "CombatTCCM/CombatPlayerCharacter.h"
#include "..\Interfaces\CharacterInputInterface.h"
#include "Structs/S_ShieldStats.h"
#include "Shields.generated.h"

UCLASS()
class COMBATTCCM_API AShields : public AActor ,public ICharacterInputInterface
{
	GENERATED_BODY()


public:	
	// Sets default values for this actor's properties
	AShields();
	bool ShieldDrawState;

	UPROPERTY(EditAnywhere,BlueprintReadWrite)
	FS_ShieldStats ShieldStats;
    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    ACombatPlayerCharacter* PlayerCharacter;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	UInteractComponent* InteractComponent;

	UPROPERTY(EditAnywhere,BlueprintReadWrite , Replicated)
	class UPhysicsConstraintComponent* LeftHandPhysicsConstraintComponent;

	

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	virtual void equippeShield(ACombatPlayerCharacter* instigator);
	virtual bool hostlerAndDrawShield(ACombatPlayerCharacter* instigator);
	virtual void StartShieldDefence(ACombatPlayerCharacter* instigator,bool Pressed);


	void InitializePhysicsConstraints();

};
