// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Shields/Shields.h"
#include "CombatTCCM/CombatPlayerCharacter.h"
#include "KiteShield.generated.h"

/**
 * 
 */
UCLASS()
class COMBATTCCM_API AKiteShield : public AShields
{
	GENERATED_BODY()
public:

	bool DefenceAnimIsPlaying=false;
	AKiteShield();
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	class UStaticMeshComponent* ShieldMesh;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	class USceneComponent* RootSceneComponent;
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FName LeftShieldHandSocket;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FName HostlerShieldSocket;
	FTimerHandle TimerHandle;
	
protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;
	
	  void equippeShield(ACombatPlayerCharacter* instigator) override;
	  bool hostlerAndDrawShield(ACombatPlayerCharacter* instigator) override;
	  void StartShieldDefence(ACombatPlayerCharacter* instigator , bool Pressed) override;
	
};
