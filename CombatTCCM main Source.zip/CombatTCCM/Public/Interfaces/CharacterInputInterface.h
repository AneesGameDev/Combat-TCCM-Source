// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UObject/Interface.h"
#include "CharacterInputInterface.generated.h"

// This class does not need to be modified.UINTERFACE()
UINTERFACE(MinimalAPI, BlueprintType, Blueprintable)
class UCharacterInputInterface : public UInterface
{
	GENERATED_BODY()
};

/**
 * 
 */

class COMBATTCCM_API ICharacterInputInterface
{
	GENERATED_BODY()


	// Add interface functions to this class. This is the class that will be inherited to implement this interface.
public:

	//Character Movement Controller Functions
	
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "InputsFunction")
	void MoveCharacter(const FVector2D MoveInput);
	
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "InputsFunction")
	void JumpCharacter(bool pressed);
	
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "InputsFunction")
	void LookCharacter(const FVector2D MoveInput);

	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "InputsFunction")
	void RollCharacter(bool pressed);

	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "InputsFunction")
	void CrouchCharacter(bool pressed);

	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "InputsFunction")
	void RunCharacter(bool pressed);




	// Functions From Where Interaction Component Interface Function Called ,
	//We Also Can Directly call Interface Function but Validation of Character is Here ////
	
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "InputsFunction")
	void Interaction(bool pressed);

	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "InputsFunction")
	void EquippeWeapon(bool pressed);

	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "InputsFunction")
	void DrawAndSheathWeapon(bool pressed);

	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "InputsFunction")
	void DrawAndSheathShield(bool pressed);

	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "InputsFunction")
	void StartPrimaryAttack(bool pressed);
	
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "InputsFunction")
	void StartPrimaryDefence(bool pressed);



	//Multiplayer Function
	

};
