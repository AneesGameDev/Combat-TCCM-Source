﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UObject/Interface.h"
#include "InteractionMechanicsInterface.generated.h"

// This class does not need to be modified.
UINTERFACE(MinimalAPI, BlueprintType, Blueprintable)
class UInteractionMechanicsInterface : public UInterface
{
	GENERATED_BODY()
};

/**
 * 
 */
class COMBATTCCM_API IInteractionMechanicsInterface
{
	GENERATED_BODY()
public:
	
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "InteractionMechanics")
	void EquippeWeapon(bool pressed);
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "InteractionMechanics")
	void DrawAndSheathWeapon(bool pressed);
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "InteractionMechanics")
	void DrawAndSheathShield(bool pressed);
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "InteractionMechanics")
	void StartPrimaryAttack(bool pressed);
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "InteractionMechanics")
	void StartPrimaryDefence(bool pressed);
	
	// Add interface functions to this class. This is the class that will be inherited to implement this interface.
	public:
};
