// Copyright Epic Games, Inc. All Rights Reserved.

#include "CombatTCCM.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, CombatTCCM, "CombatTCCM" );
 