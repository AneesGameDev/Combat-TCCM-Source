// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "CombatPlayerCharacter.h"
#include "GameFramework/GameModeBase.h"
#include "CombatGameMode.generated.h"

UCLASS(minimalapi)
class ACombatGameMode : public AGameModeBase
{
	GENERATED_BODY()

	virtual void BeginPlay() override;
	
public:
	ACombatGameMode();
    UPROPERTY(EditAnywhere ,BlueprintReadWrite)
	TSubclassOf<ACombatPlayerCharacter> CharcterRef;
	UPROPERTY(EditAnywhere ,BlueprintReadWrite)
	class ACombatGameState* CombatGameState;
};



