// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "CombatPlayerState.h"
#include "GameFramework/Character.h"
#include "InputActionValue.h"
#include "Interfaces/CharacterInputInterface.h"
#include "CombatPlayerCharacter.generated.h"


UCLASS(config=Game, BlueprintType, Blueprintable)
class ACombatPlayerCharacter :  public  ACharacter , public ICharacterInputInterface
{
	GENERATED_BODY()
	
private:
	
	/** Camera boom positioning the camera behind the character */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Camera, meta = (AllowPrivateAccess = "true"))
	class USpringArmComponent* CameraBoom;

	/** Follow camera */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Camera, meta = (AllowPrivateAccess = "true"))
	class UCameraComponent* FollowCamera;
	
	
	/** MappingContext */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Input, meta = (AllowPrivateAccess = "true"))
	class UInputMappingContext* DefaultMappingContext;

	/** Jump Input Action */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Input, meta = (AllowPrivateAccess = "true"))
	class UInputAction* JumpAction;

	/** Move Input Action */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Input, meta = (AllowPrivateAccess = "true"))
	class UInputAction* MoveAction;

	/** Look Input Action */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Input, meta = (AllowPrivateAccess = "true"))
	class UInputAction* LookAction;
 

	// Aiming ZoomedIn and ZoomedOut Attributes Default to reset 

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = AimingWeaponAttributes, meta = (AllowPrivateAccess = "true"))
	float  DefaultFOV =90.0f;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = AimingWeaponAttributes, meta = (AllowPrivateAccess = "true"))
	float  DefaultArmLength =450.0f;

	// ReSharper disable once UnrealHeaderToolError
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AimingWeaponAttributes" ,meta = (AllowPrivateAccess = "true"))
	FVector DefaultSocketOffset = FVector(0.f,0.f,30.f);
	// ReSharper disable once UnrealHeaderToolError
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AimingWeaponAttributes" , meta = (AllowPrivateAccess = "true"))
	FVector DefaultTargetOffset = FVector(0.f,50.f,0.f);
	UPROPERTY(EditAnywhere, BlueprintReadWrite , Category="CharcterMovementSpeed" , meta = (AllowPrivateAccess = "true"))
	float DefaultCharacterWalkSpeed = 500.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite , Category="CharcterMovementSpeed" , meta = (AllowPrivateAccess = "true"))
	float DefaultCharacterRunSpeed =800.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite , Category="CharcterMovementSpeed" , meta = (AllowPrivateAccess = "true"))
	float DefaultCharacterCrouchSpeed =300.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite , Category="CharcterMovementSpeed" , meta = (AllowPrivateAccess = "true"))
	float DefaultCameraMinPitch = -90.0f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite , Category="CharcterMovementSpeed" , meta = (AllowPrivateAccess = "true"))
	float DefaultCameraMaxPitch = 90.0f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite , Category="CharcterMovementSpeed" , meta = (AllowPrivateAccess = "true"))
	float DefaultCameraSensitivity = 90.0f;
	
	//
	// UPROPERTY(EditAnywhere, BlueprintReadWrite , Replicated)
	// bool bIsPlayerCrouching =false;

public:
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite , Replicated)
	UAnimSequenceBase* ShieldAnimationSequence;
	UPROPERTY(EditAnywhere, BlueprintReadWrite , Replicated)
	bool bIsAiming;

   //Player States reference For Multiplayer
	
	UPROPERTY()
	ACombatPlayerState* PlayerStateRef;
	UPROPERTY()
	class ACombatPlayerController* PlayerControllerRef;
	UPROPERTY()
	class ACombatHUD* PlayerHUDRef;

	//Component Attached To Character
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Replicated)
	class UInteractComponent* InteractComponent;
	UPROPERTY(EditAnywhere, BlueprintReadWrite ,Replicated)
	class UStatsWidgetComponent* StatsWidgetComponent;
	UPROPERTY(EditAnywhere, BlueprintReadWrite , Replicated)
	class UWidgetComponent* CharacterWorldWidgetComponent;

public:
	ACombatPlayerCharacter();

	virtual void MoveCharacter_Implementation(const FVector2D MoveInput) override;
	virtual void JumpCharacter_Implementation(bool pressed) override;
	virtual void LookCharacter_Implementation(const FVector2D MoveInput) override;
	virtual void RunCharacter_Implementation(bool pressed) override;
	virtual void CrouchCharacter_Implementation(bool pressed) override;
	virtual void RollCharacter_Implementation(bool pressed) override;


	UFUNCTION(Server, Reliable , BlueprintCallable)
	void Server_SetCrouch(bool pressed);
	
	UFUNCTION(Server, Reliable , BlueprintCallable)
	void Server_SetRun(bool pressed);
	
	

	// Interaction Mainly used to Interact Character with Environment like Pick some Weapons or to Open Door
	// For now Interaction Component is used to equipped the weapon when Button is Pressed
	virtual void Interaction_Implementation(bool pressed) override;

	virtual void EquippeWeapon_Implementation(bool pressed) override;
	
	//this function is used to Draw and Sheath Weapon 
	virtual void DrawAndSheathWeapon_Implementation(bool pressed) override;

	virtual void DrawAndSheathShield_Implementation(bool pressed) override;
	
	virtual void StartPrimaryAttack_Implementation(bool pressed) override;
	virtual void StartPrimaryDefence_Implementation(bool pressed) override;
	
	TSet<FName> HitBoneNamesSet;

	TArray<FName> GetHitBoneNamesArray() const ;
	
		
private:
	void CreateWidgetComponent();

protected:

	/** Called for movement input */
	void Move(const FInputActionValue& Value);

	/** Called for looking input */
	void Look(const FInputActionValue& Value);
	
	// APawn interface
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;
	
	// To add mapping context
	virtual void BeginPlay();
	
    virtual void Tick(float DeltaSeconds) override;

	virtual void PostInitializeComponents() override;

	virtual void PreInitializeComponents() override;



	//Getter Functions is Given Below
public:
	/** Returns CameraBoom subobject **/
	FORCEINLINE class USpringArmComponent* GetCameraBoom() const { return CameraBoom; }
	/** Returns FollowCamera subobject **/
	FORCEINLINE class UCameraComponent* GetFollowCamera() const { return FollowCamera; }

	FORCEINLINE float GetDefaultArmLength() const { return DefaultArmLength ;}

	FORCEINLINE float GetDefaultFOV() const { return DefaultFOV ;}
	
	FORCEINLINE FVector GetDefaultSocketOffset() const { return  DefaultSocketOffset ;}
	FORCEINLINE FVector GetDefaultTargetOffset() const { return  DefaultTargetOffset ;}
	FORCEINLINE float GetDefaultCameraMinPitch() const { return  DefaultCameraMinPitch ;}
	FORCEINLINE float GetDefaultCameraMaxPitch() const { return  DefaultCameraMaxPitch ;}





	
};

