// Fill out your copyright notice in the Description page of Project Settings.


#include "CombatGameState.h"

#include "CombatTCCM/CombatPlayerState.h"


void ACombatGameState::SpawnCharacterWithStateData(TSubclassOf<ACharacter> Character)
{
	// Spawn the character
	FActorSpawnParameters SpawnParams;
	ACombatPlayerCharacter* SpawnedCharacter = GetWorld()->SpawnActor<ACombatPlayerCharacter>(Character, FVector::ZeroVector,
	                                                                  FRotator::ZeroRotator, SpawnParams);

	// Set player state data
	ACombatPlayerState* PlayerState = Cast<ACombatPlayerState>(SpawnedCharacter->GetPlayerState());
	if (PlayerState)
	{
		PlayerState->CharacterStats.CharacterTeamId = ++CharacterIdIncrementer;
		SpawnedCharacter->PlayerStateRef = PlayerState;
	}
	
}
