// Fill out your copyright notice in the Description page of Project Settings.


#include "Common/AnimInstance_cpp.h"

#include "KismetAnimationLibrary.h"
#include "Components/InteractComponent.h"
#include "GameFrameWork/CharacterMovementComponent.h"

void UAnimInstance_cpp::NativeBeginPlay()
{
	Super::NativeBeginPlay();
	PlayerCharacterRef = GetCombatPlayerRef();
	InteractComponentRef = GetInteractComponentRef();
}

void UAnimInstance_cpp::NativeUpdateAnimation(float DeltaSeconds)
{
	Super::NativeUpdateAnimation(DeltaSeconds);
	
	if (IsValid(PlayerCharacterRef) && IsValid(InteractComponentRef)) {
		
		Speed = PlayerCharacterRef->GetVelocity().Length();
		
		Direction =  UKismetAnimationLibrary::CalculateDirection(PlayerCharacterRef->GetVelocity(), PlayerCharacterRef->GetControlRotation());
		
		binAir = PlayerCharacterRef->GetCharacterMovement()->IsFalling();
		
		bIsShieldActive = (InteractComponentRef->DefenceAssaultStats == E_DefenceAssaultStats::StartDefenceAssault); // InteractComponentRef->bIsStartSheildActivate;

		bIsAttackActive = (InteractComponentRef->AttackStates == E_AttackStats::StartAttack) ; // bIsAttackActive;
		
		ShieldAnimationSequence = PlayerCharacterRef->ShieldAnimationSequence;
		
		WalkRunAnimationRate = (PlayerCharacterRef->GetCharacterMovement()->GetMaxSpeed()/500.f);
		
		bIsCrouching = (PlayerCharacterRef->InteractComponent->MoveActionStats == E_MoveActionStats::Crouch); //bIsPlayerCrouching;
		
		bIsIdle = (Speed<20.f);

		bIsAiming = PlayerCharacterRef->bIsAiming;
		
	}
	else
	{
		PlayerCharacterRef = GetCombatPlayerRef();
		InteractComponentRef = GetInteractComponentRef();
	}
	
}

ACombatPlayerCharacter* UAnimInstance_cpp::GetCombatPlayerRef() const
{
	return IsValid(TryGetPawnOwner()) ? Cast<ACombatPlayerCharacter>(TryGetPawnOwner()) : nullptr;
}

UInteractComponent* UAnimInstance_cpp::GetInteractComponentRef() const
{
	return  IsValid(PlayerCharacterRef) ? PlayerCharacterRef->InteractComponent : nullptr;
}
