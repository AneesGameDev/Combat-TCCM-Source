// Fill out your copyright notice in the Description page of Project Settings.


#include "Weapons/Weapon2H.h"
#include "Components/InteractComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Net/UnrealNetwork.h"

// Sets default values
AWeapon2H::AWeapon2H()
{
	PrimaryActorTick.bCanEverTick = true;

	WeaponRootSceneComponent = CreateDefaultSubobject<USceneComponent>("WeaponRootSceneComponent");
	SetRootComponent(WeaponRootSceneComponent);
	WeaponMesh = CreateDefaultSubobject<USkeletalMeshComponent>("WeaponMesh");
	WeaponMesh->SetupAttachment(GetRootComponent());

	
}


// Called when the game starts or when spawned
void AWeapon2H::BeginPlay()
{
	Super::BeginPlay();
	SetSingleHandWeaponSocketNames(TArray{WeaponMesh});
}


// Called every frame
void AWeapon2H::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}


void AWeapon2H::EquippeWeapon(ACombatPlayerCharacter* _instigator)
{
	Super::EquippeWeapon(_instigator);
	if (!IsValid(WeaponMesh)) return;
	FAttachmentTransformRules Rules = FAttachmentTransformRules::SnapToTargetNotIncludingScale;
	WeaponDrawState = true;
	float DelayTime = 0.1f;
	//Call the function with the specified delay using a lambda function
	GetWorldTimerManager().SetTimer(TimerHandle, [this ,_instigator ,Rules]()
	{
		WeaponMesh->AttachToComponent(_instigator->GetMesh(), Rules, EquipeHandSocketName);
	}, DelayTime, false);

	Multicast_PlayAnimationMontage(_instigator,DrawWeaponAnimMontageName);
	//Multicast_EquippeWeapon(_instigator);
}


void AWeapon2H::DrawAndSheathWeapon()
{
	Super::DrawAndSheathWeapon();
	
	if (WeaponDrawState)
	{
		WeaponDrawState = false;

		float DelayTime = 0.3f;
		Multicast_PlayAnimationMontage(OwnerPlayerCharacter,DrawWeaponAnimMontageName);
		//Multicast_DrawAndSheathWeapon(OwnerPlayerCharacter, "HostlerWeaponMontag", false , WeaponMesh ,HostlerSocketName);
		// Call the function with the specified delay using a lambda function
		GetWorldTimerManager().SetTimer(TimerHandle, [this ]()
		{
			Multicast_DrawandSheathWeapon(OwnerPlayerCharacter,HostlerWeaponAnimMontageName , WeaponMesh, HostlerSocketName);
			//Multicast_DrawAndSheathWeapon(OwnerPlayerCharacter, "HostlerWeaponMontag", true);
		}, DelayTime, false);
	}
	else
	{
		EquippeWeapon(OwnerPlayerCharacter);
	}
}

void AWeapon2H::StartAttackVisuals()
{
	Super::StartAttackVisuals();

	if (WeaponDrawState && IsValid(OwnerPlayerCharacter) && IsValid(OwnerInteractComponent) && 	OwnerInteractComponent->AttackStates != E_AttackStats::StartAttack)
	{

		OwnerInteractComponent->DefenceAssaultStats = E_DefenceAssaultStats::EndDefenceAssault;
		OwnerInteractComponent->AttackStates = E_AttackStats::StartAttack;
		
		
		AttackComboAnimCount = AttackComboAnimCount % WeaponStats.ComboAnimationCount;
		AttackComboAnimCount++;
		
		float DelayTime = 1.5f;

		GetWorldTimerManager().SetTimer(TimerHandle, [this]()
		{
			AttackComboAnimCount = 0;
		}, DelayTime, false);
		const FName AnimationNAme= *FString::FromInt(AttackComboAnimCount);
		Multicast_PlayAnimationMontage(OwnerPlayerCharacter, AnimationNAme);
		
	
	}
}


void AWeapon2H::EndAttackVisuals()
{
	Super::EndAttackVisuals();
}

void AWeapon2H::StartAttackMechanics(int32 DualWeildIndex)
{
	Super::StartAttackMechanics(DualWeildIndex);

	// Check if this code is running on the server
	if (UKismetSystemLibrary::IsServer(this))
	{
		for (auto& SocketEntry : PreviousSocketLocations)
		{
			FName SocketName;
			FVector PreviousSocketLocation;
			FVector CurrentSocketLocation;
			FHitResult HitResults;
			FVector TraceStart;
			FVector TraceEnd;

			SocketName = SocketEntry.Key;
			PreviousSocketLocation = SocketEntry.Value;

			CurrentSocketLocation = WeaponMesh->GetSocketLocation(SocketName);

			TraceStart = PreviousSocketLocation;
			TraceEnd = CurrentSocketLocation;


			if (auto bHit = UKismetSystemLibrary::LineTraceSingleByProfile(
				GetWorld(), TraceStart, TraceEnd, AttackTraceMeshProfileName, true, ActorsToIgnore,
				EDrawDebugTrace::ForDuration, HitResults, true, FColor::Red, FLinearColor::Black, 10.0f))
			{
				ACombatPlayerCharacter* Player = Cast<ACombatPlayerCharacter>(HitResults.GetActor());
				GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Green, HitResults.BoneName.ToString());
				AddHittedCharacterInfo(Player, HitResults);
			}
			SocketEntry.Value = CurrentSocketLocation;
		}
	}
}


void AWeapon2H::EndAttackMechanics()
{
	Super::EndAttackMechanics();
}


void AWeapon2H::SetStartAttackSocketLocation()
{
	Super::SetStartAttackSocketLocation();
	SetStartMeshSocketLocations(WeaponMesh);
}


/*void AWeapon2H::Multicast_DrawAndSheathWeapon_Implementation(ACombatPlayerCharacter* _instigator, FName MontageName,
                                                             bool AttachWeapon , USkeletalMeshComponent* WeaponMesh , FName HostlerSocketName)
{
	if (AttachWeapon)
	{
		const FAttachmentTransformRules Rules = FAttachmentTransformRules::SnapToTargetNotIncludingScale;
		WeaponMesh->AttachToComponent(_instigator->GetMesh(), Rules, HostlerSocketName);
	}
	else
	{
		UAnimMontage* MontageToPlay = WeaponStats.maSheathAnimations.FindRef(MontageName.ToString());
		_instigator->PlayAnimMontage(MontageToPlay);
	}
}*/

/*
void AWeapon2H::Multicast_StartAttackVisuals_Implementation(ACombatPlayerCharacter* _instigator, int32 MontageId)
{
	UAnimMontage* MontageToPlay = WeaponStats.maAttackAnimatios.FindRef(FString::FromInt(MontageId));
	_instigator->PlayAnimMontage(MontageToPlay);
}
*/


/*void AWeapon2H::Multicast_EquippeWeapon_Implementation(ACombatPlayerCharacter* _instigator)
{
	UAnimMontage* MontageToPlay = WeaponStats.maSheathAnimations.FindRef("DrawWeaponMontag");
	_instigator->PlayAnimMontage(MontageToPlay);
}*/

void AWeapon2H::DrawAndSheathShieldAssaults(bool Pressed)
{
	Super::DrawAndSheathShieldAssaults(Pressed);
	if (WeaponDrawState && IsValid(OwnerPlayerCharacter) && IsValid(OwnerInteractComponent))
	{
		if (Pressed)
		{
			if (OwnerInteractComponent->CanShieldAssaultCharacter())
			{
				OwnerInteractComponent->DefenceAssaultStats = E_DefenceAssaultStats::StartDefenceAssault;
				OwnerPlayerCharacter->ShieldAnimationSequence = WeaponStats.ShieldAmimationSequence;

				// Call the function with the specified delay using a lambda function
			}
		}
		else
		{
			OwnerInteractComponent->DefenceAssaultStats = E_DefenceAssaultStats::EndDefenceAssault;

		}
	}
}

void AWeapon2H::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	DOREPLIFETIME(AWeapon2H, WeaponMesh);
}
