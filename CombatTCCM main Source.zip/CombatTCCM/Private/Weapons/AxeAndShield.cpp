// Fill out your copyright notice in the Description page of Project Settings.


#include "Weapons/AxeAndShield.h"
#include "Components/InteractComponent.h"
#include "Engine/RendererSettings.h"
#include "FiniteStateMachine/StatesManagerComponent.h"
#include "Kismet/KismetSystemLibrary.h"


// Sets default values
AAxeAndShield::AAxeAndShield()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	WeaponRootSceneComponent = CreateDefaultSubobject<USceneComponent>("RootSceneComponent");
    SetRootComponent(WeaponRootSceneComponent);
	
	WeaponMesh = CreateDefaultSubobject<USkeletalMeshComponent>("WeaponMesh");
	WeaponMesh->SetupAttachment(GetRootComponent());

}

// Called when the game starts or when spawned
void AAxeAndShield::BeginPlay()
{
	Super::BeginPlay();
	SetSingleHandWeaponSocketNames(TArray{WeaponMesh});
}

// Called every frame
void AAxeAndShield::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void AAxeAndShield::EquippeWeapon(ACombatPlayerCharacter* _instigator)
{
	Super::EquippeWeapon(_instigator);

	FAttachmentTransformRules Rules = FAttachmentTransformRules::SnapToTargetNotIncludingScale;
	WeaponDrawState = true;
	//Multicast_EquippeWeapon(_instigator);
	//bool Attached =  WeaponMesh->AttachToComponent(instigator->GetMesh(), Rules,EquipeHandSocketName);
	float DelayTime = 0.5f;
	//Call the function with the specified delay using a lambda function
	GetWorldTimerManager().SetTimer(TimerHandle, [this ,_instigator ,Rules]()
{
		WeaponMesh->AttachToComponent(_instigator->GetMesh(),Rules,EquipeRighttHandSocketName);
		
	}, DelayTime, false);
	
	Multicast_PlayAnimationMontage(_instigator,"DrawWeaponMontag");
	
	
}

/*
void AAxeAndShield::Multicast_EquippeWeapon_Implementation(ACombatPlayerCharacter* _instigator)
{
	UAnimMontage* MontageToPlay = WeaponStats.SheathAnimations.FindRef("DrawWeaponMontag");
	_instigator->PlayAnimMontage(MontageToPlay);
}*/

void AAxeAndShield::DrawAndSheathWeapon()
{
	Super::DrawAndSheathWeapon();
	
	if (WeaponDrawState)
	{
		WeaponDrawState = false;
		

		float DelayTime = 0.5f;

		//Multicast_DrawAndSheathWeapon(OwnerPlayerCharacter,"HostlerWeaponMontag" ,false);
		Multicast_PlayAnimationMontage(OwnerPlayerCharacter,"HostlerWeaponMontag");
		// Call the function with the specified delay using a lambda function
		GetWorldTimerManager().SetTimer(TimerHandle, [this ]()
		{
			// Code to execute after the delay
			// Place your desired code here directly, without creating a new function
			// For example
			
			//Multicast_DrawAndSheathWeapon(OwnerPlayerCharacter,"HostlerWeaponMontag" ,true);
			Multicast_DrawandSheathWeapon(OwnerPlayerCharacter,"" , WeaponMesh, HostlerRightSocketName);
			//bool Attached =  WeaponMesh->AttachToComponent(instigator->GetMesh(), Rules,HostlerSocketName);
		}, DelayTime, false);
	}
	else
	{
		EquippeWeapon(OwnerPlayerCharacter);
	}
}

/*void AAxeAndShield::Multicast_DrawAndSheathWeapon_Implementation(ACombatPlayerCharacter* _instigator, FName MontageName,
	bool AttachWeapon)
{
	if(AttachWeapon)
	{
			FAttachmentTransformRules Rules = FAttachmentTransformRules::SnapToTargetNotIncludingScale;
			WeaponMesh->AttachToComponent(_instigator->GetMesh(),Rules, HostlerRightSocketName);
		
	}
	else
	{
		UAnimMontage* MontageToPlay = WeaponStats.SheathAnimations.FindRef("HostlerWeaponMontag");
		_instigator->PlayAnimMontage(MontageToPlay);
	}
	
}*/

void AAxeAndShield::StartAttackVisuals()
{
	Super::StartAttackVisuals();

	if (WeaponDrawState && IsValid(OwnerPlayerCharacter) && IsValid(OwnerInteractComponent))
	{
			
		OwnerInteractComponent->DefenceAssaultStats = E_DefenceAssaultStats::EndDefenceAssault;
		OwnerInteractComponent->AttackStates = E_AttackStats::StartAttack;


		AttackComboAnimCount = AttackComboAnimCount %  WeaponStats.ComboAnimationCount;
		AttackComboAnimCount++;
		FAttachmentTransformRules Rules = FAttachmentTransformRules::SnapToTargetNotIncludingScale;
		//bool Attached =  WeaponMesh->AttachToComponent(instigator->GetMesh(), Rules,EquipeHandSocketName);
			

		float DelayTime = 1.5f;

		// Call the function with the specified delay using a lambda function
		GetWorldTimerManager().SetTimer(TimerHandle, [this]()
		{
			AttackComboAnimCount = 0;
		}, DelayTime, false);

		const FName AnimationNAme= *FString::FromInt(AttackComboAnimCount);
		Multicast_PlayAnimationMontage(OwnerPlayerCharacter, AnimationNAme);
		//Multicast_StartAttackVisuals(OwnerPlayerCharacter,AttackComboAnimCount);
	}



	/*
	float DelayTime = 2.0f;

	// Call the function with the specified delay using a lambda function
	GetWorldTimerManager().SetTimer(TimerHandle, [this]() {

		AttackComboAnimCount = 0;


	}, DelayTime, false);*/
}


/*
void AAxeAndShield::Multicast_StartAttackVisuals_Implementation(ACombatPlayerCharacter* _instigator, int32 MontageId)
{

	UAnimMontage* MontageToPlay = WeaponStats.maAttackAnimatios.FindRef(FString::FromInt(MontageId));

	_instigator->PlayAnimMontage(MontageToPlay);
}
*/

/*void AWeapon2H::StartAttackMechanics(FHitResult& HitResult, ACombatPlayerCharacter* HitCharacter)
{
	Super::StartAttackMechanics(HitResult, HitCharacter);
}*/


void AAxeAndShield::EndAttackVisuals()
{
	Super::EndAttackVisuals();
}

void AAxeAndShield::SetStartAttackSocketLocation()
{
	Super::SetStartAttackSocketLocation();

	SetStartMeshSocketLocations(WeaponMesh);
}

void AAxeAndShield::StartAttackMechanics(int32 DualWeildIndex)
{
	Super::StartAttackMechanics(DualWeildIndex);
	// Check if this code is running on the server
	if (UKismetSystemLibrary::IsServer(this))
	{
		for (auto& SocketEntry : PreviousSocketLocations)
		{
			FName SocketName;
			FVector PreviousSocketLocation;
			FVector CurrentSocketLocation;
			FHitResult HitResults;
			FVector TraceStart;
			FVector TraceEnd;

			SocketName = SocketEntry.Key;
			PreviousSocketLocation = SocketEntry.Value;

			CurrentSocketLocation = WeaponMesh->GetSocketLocation(SocketName);

			TraceStart = PreviousSocketLocation;
			TraceEnd = CurrentSocketLocation;


			if (auto bHit = UKismetSystemLibrary::LineTraceSingleByProfile(
				GetWorld(), TraceStart, TraceEnd, "PlayerMeshProfile", true, ActorsToIgnore,
				EDrawDebugTrace::ForDuration, HitResults, true, FColor::Red, FLinearColor::Black, 10.0f))
			{
				ACombatPlayerCharacter* Player = Cast<ACombatPlayerCharacter>(HitResults.GetActor());
				GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Green, HitResults.BoneName.ToString());
				AddHittedCharacterInfo(Player, HitResults);
			}
			SocketEntry.Value = CurrentSocketLocation;
		}
	}
	
}

void AAxeAndShield::EndAttackMechanics()
{
	Super::EndAttackMechanics();
}

/*
void AWeapon2H::EndAttackMechanics()
{
	Super::EndAttackMechanics();
}
*/

void AAxeAndShield::DrawAndSheathShieldAssaults(bool Pressed)
{
	Super::DrawAndSheathShieldAssaults(Pressed);
	if (WeaponDrawState && IsValid(OwnerPlayerCharacter) && IsValid(OwnerInteractComponent))
	{
		if (Pressed)
		{
			if (OwnerInteractComponent->CanShieldAssaultCharacter())
			{
				OwnerPlayerCharacter->ShieldAnimationSequence = WeaponStats.ShieldAmimationSequence;
				OwnerInteractComponent->DefenceAssaultStats = E_DefenceAssaultStats::StartDefenceAssault;

				// Call the function with the specified delay using a lambda function
			}
		}
		else
		{
			OwnerInteractComponent->DefenceAssaultStats = E_DefenceAssaultStats::EndDefenceAssault;
		}
	}
}


/*
// Sets default values
AAxeAndShield::AAxeAndShield()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	WeaponMesh = CreateDefaultSubobject<UStaticMeshComponent>("WeaponMesh");
	RootSceneComponent = CreateDefaultSubobject<USceneComponent>("RootSceneComponent");

	RootSceneComponent->SetupAttachment(GetRootComponent());
	//RootComponent = RootSceneComponent;
	WeaponMesh->SetupAttachment(RootSceneComponent);
	HandPhysicsConstraintComponent = CreateDefaultSubobject<UPhysicsConstraintComponent>(TEXT("HandPhysicsConstraint"));
	HandPhysicsConstraintComponent->SetupAttachment(RootComponent);
	
}

// Called when the game starts or when spawned
void AAxeAndShield::BeginPlay()
{
	Super::BeginPlay();
}

// Called every frame
void AAxeAndShield::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void AAxeAndShield::EquippeWeapon(ACombatPlayerCharacter* instigator)
{
	Super::EquippeWeapon(instigator);

	WeaponMesh->SetSimulatePhysics(true);
	
	FAttachmentTransformRules Rules = FAttachmentTransformRules::SnapToTargetNotIncludingScale;
	WeaponDrawState = true;
	//bool Attached =  WeaponMesh->AttachToComponent(instigator->GetMesh(), Rules,EquipeLeftHandSocketName);

	UAnimMontage* MontageToPlay = WeaponStats.maSheathAnimations.FindRef("DrawWeaponMontag");

	instigator->PlayAnimMontage(MontageToPlay);
	float DelayTime = 0.5f;
	
	// Call the function with the specified delay using a lambda function
	GetWorldTimerManager().SetTimer(TimerHandle, [this ,instigator ,Rules]()
	{

		if (IsValid(HandPhysicsConstraintComponent) && IsValid(instigator))
		{

			FConstraintInstance& LeftConstraintInstance = HandPhysicsConstraintComponent->ConstraintInstance;
	LeftConstraintInstance.SetLinearXLimit(LCM_Locked, 0.0f);
	LeftConstraintInstance.SetLinearYLimit(LCM_Locked, 0.0f);
	LeftConstraintInstance.SetLinearZLimit(LCM_Locked, 0.0f);
	LeftConstraintInstance.SetAngularSwing1Limit(ACM_Locked, 0.0f);
	LeftConstraintInstance.SetAngularSwing2Limit(ACM_Locked, 0.0f);
	LeftConstraintInstance.SetAngularTwistLimit(ACM_Locked, 0.0f);
	HandPhysicsConstraintComponent->UpdateConstraintFrames();

			
			
			
			UPrimitiveComponent* CharacterMesh = instigator->GetMesh();
			// Set up the constraint instance and configure it
		bool Attached = WeaponMesh->K2_AttachToComponent(instigator->GetMesh(), EquipeLeftHandSocketName,
															 Rules.LocationRule, Rules.RotationRule, Rules.ScaleRule, true);
			
			HandPhysicsConstraintComponent->SetConstrainedComponents(WeaponMesh, NAME_None, CharacterMesh, "Hand_R");
	
		}
		
		
	}, DelayTime, false);
}

void AAxeAndShield::DrawAndSheathWeapon(ACombatPlayerCharacter* instigator)
{
	Super::DrawAndSheathWeapon(instigator);
	FAttachmentTransformRules Rules = FAttachmentTransformRules::SnapToTargetNotIncludingScale;
	if (WeaponDrawState)
	{
		WeaponDrawState = false;
		UAnimMontage* MontageToPlay = WeaponStats.maSheathAnimations.FindRef("HostlerWeaponMontag");
		instigator->PlayAnimMontage(MontageToPlay);

		float DelayTime = 0.3f;

		// Call the function with the specified delay using a lambda function
		GetWorldTimerManager().SetTimer(TimerHandle, [this ,instigator ,Rules]()
		{
		//	WeaponMesh->K2_AttachToComponent(instigator->GetMesh(), HostlerLeftSocketName ,Rules.LocationRule, Rules.RotationRule, Rules.ScaleRule ,  true);

			if (IsValid(RightHandPhysicsConstraintComponent))
			{
				WeaponMesh->SetSimulatePhysics(false);
				RightHandPhysicsConstraintComponent->SetConstrainedComponents(nullptr, NAME_None, nullptr, NAME_None);
				WeaponMesh->AttachToComponent(instigator->GetMesh(),Rules, HostlerLeftSocketName);
			}
			//	bool Attached = WeaponMesh->AttachToComponent(instigator->GetMesh(), Rules, HostlerLeftSocketName);
		}, DelayTime, false);
	}
	else
	{
		EquippeWeapon(instigator);
	}
}

void AAxeAndShield::StartAttackVisuals(ACombatPlayerCharacter* instigator)
{
	Super::StartAttackVisuals(instigator);
	if (WeaponDrawState && IsValid(OwnerPlayerCharacter) && IsValid(OwnerInteractComponent))
	{
		if (OwnerInteractComponent->CanAttackCharacter())
		{
			
			
			OwnerInteractComponent->bIsSheildActive = false;
			AttackComboAnimCount = AttackComboAnimCount % WeaponStats.maAttackAnimatios.Num();
			AttackComboAnimCount++;
			FAttachmentTransformRules Rules = FAttachmentTransformRules::SnapToTargetNotIncludingScale;
			WeaponDrawState = true;
			//bool Attached =  WeaponMesh->AttachToComponent(instigator->GetMesh(), Rules,EquipeHandSocketName);

			UAnimMontage* MontageToPlay = WeaponStats.maAttackAnimatios.FindRef(FString::FromInt(AttackComboAnimCount));

			instigator->PlayAnimMontage(MontageToPlay);

			OwnerInteractComponent->bIsAttackActive = true;

			float DelayTime = 1.5f;

			// Call the function with the specified delay using a lambda function
			GetWorldTimerManager().SetTimer(TimerHandle, [this ,instigator ,Rules]()
			{
				AttackComboAnimCount = 0;
			}, DelayTime, false);
		}
	}
}

void AAxeAndShield::DrawAndSheathShieldAssaults(ACombatPlayerCharacter* instigator, bool Pressed)
{
	/*if(WeaponDrawState)
	{
		Super::StartAttack(instigator);
		//AttackComboAnimCount = AttackComboAnimCount%WeaponStats.maAttackAnimatios.Num();
		//AttackComboAnimCount++;
		FAttachmentTransformRules Rules = FAttachmentTransformRules::SnapToTargetNotIncludingScale ;
		//WeaponDrawState = true;
		//bool Attached =  WeaponMesh->AttachToComponent(instigator->GetMesh(), Rules,EquipeHandSocketName);
	
		UAnimMontage* MontageToPlay = WeaponStats.maShieldAmimations.FindRef(FString::FromInt(1));
		
		instigator->PlayAnimMontage(MontageToPlay);
		float DelayTime = 2.0f;

		// Call the function with the specified delay using a lambda function
		GetWorldTimerManager().SetTimer(TimerHandle, [this ,instigator ,Rules]() {

			AttackComboAnimCount = 0;
	
		
		}, DelayTime, false);
	}#1#
}
*/
