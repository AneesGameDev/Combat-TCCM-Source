// Fill out your copyright notice in the Description page of Project Settings.


#include "Weapons/Fists.h"

#include "Components/InteractComponent.h"

// Sets default values
AFists::AFists()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	RootSceneComponent = CreateDefaultSubobject<USceneComponent>("RootSceneComponent");
	RootComponent = RootSceneComponent;
	
	LeftHandBox = CreateDefaultSubobject<UBoxComponent>("LeftHandBox");
	RightHandBox = CreateDefaultSubobject<UBoxComponent>("RightHandBox");
	LeftHandBox->SetupAttachment(GetRootComponent());
	RightHandBox->SetupAttachment(GetRootComponent());
	//LeftHandBox->SetVisibility(true);
	
}

// Called when the game starts or when spawned
void AFists::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void AFists::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void AFists::EquippeWeapon(ACombatPlayerCharacter* instigator)
{
	Super::EquippeWeapon(instigator);
	if(!IsValid(instigator))
	{
		return;
	}

	

	
	OwnerPlayerCharacter = instigator;
	OwnerInteractComponent = Cast<UInteractComponent>(OwnerPlayerCharacter->GetComponentByClass(UInteractComponent::StaticClass()));
	FAttachmentTransformRules Rules = FAttachmentTransformRules::SnapToTargetNotIncludingScale ;
	WeaponDrawState = true;
	

	//bool Attached =  WeaponMesh->AttachToComponent(instigator->GetMesh(), Rules,EquipeHandSocketName);

	float DelayTime = 0.2f;
	// Call the function with the specified delay using a lambda function
	GetWorldTimerManager().SetTimer(TimerHandle, [this ,instigator ,Rules]() {

		bool LeftBoxAttached = LeftHandBox->K2_AttachToComponent(instigator->GetMesh(),LeftHandFistsSocket,Rules.LocationRule, Rules.RotationRule, Rules.ScaleRule ,  true);

		bool RightBoxAttached = RightHandBox->K2_AttachToComponent(instigator->GetMesh(),RightHandFistsSocket,Rules.LocationRule, Rules.RotationRule, Rules.ScaleRule ,  true);
	}, DelayTime, false);


	
}

void AFists::DrawAndSheathWeapon()
{
	Super::DrawAndSheathWeapon();
	
}

void AFists::StartAttackVisuals()
{
	Super::StartAttackVisuals();
	if(!ActiveAbility)
	{
		if( IsValid(OwnerPlayerCharacter) && IsValid(OwnerInteractComponent))
		{
			OwnerInteractComponent->DefenceAssaultStats = E_DefenceAssaultStats::EndDefenceAssault;
			OwnerInteractComponent->AttackStates = E_AttackStats::StartAttack;
			WeaponDrawState = true;

				
				
			AttackComboAnimCount = AttackComboAnimCount%WeaponStats.maAttackAnimatios.Num();
			AttackComboAnimCount++;
			FAttachmentTransformRules Rules = FAttachmentTransformRules::SnapToTargetNotIncludingScale ;
			
			//bool Attached =  WeaponMesh->AttachToComponent(instigator->GetMesh(), Rules,EquipeHandSocketName);
	
			UAnimMontage* MontageToPlay = WeaponStats.maAttackAnimatios.FindRef(FString::FromInt(AttackComboAnimCount));
		    
			OwnerPlayerCharacter->PlayAnimMontage(MontageToPlay);
			float DelayTime = 2.0f;

			// Call the function with the specified delay using a lambda function
			GetWorldTimerManager().SetTimer(TimerHandle, [this ]() {

				AttackComboAnimCount = 0;
	
		
			}, DelayTime, false);

		}

	}
}


void AFists::DrawAndSheathShieldAssaults( bool Pressed)
{
	Super::DrawAndSheathShieldAssaults( Pressed);

	if(IsValid(OwnerPlayerCharacter) && IsValid(OwnerInteractComponent))
	{
		if(Pressed){
			if(OwnerInteractComponent->CanShieldAssaultCharacter())
			{
				OwnerPlayerCharacter->ShieldAnimationSequence = WeaponStats.ShieldAmimationSequence;
				OwnerInteractComponent->DefenceAssaultStats = E_DefenceAssaultStats::StartDefenceAssault;

				// Call the function with the specified delay using a lambda function
		
			}
		}else
		{
			OwnerInteractComponent->DefenceAssaultStats = E_DefenceAssaultStats::EndDefenceAssault;
		}
		/*if(Pressed)
		{
			InteractComponent->bIsSheildActive =true;
			instigator->ShieldAnimationSequence = FistsStats.ShieldAmimationSequence;
			
		}
		else
		{
			InteractComponent->bIsSheildActive=false;
			
		}*/
	
	}
}

/*
void AFists::equippeFists(ACombatPlayerCharacter* instigator)
{
	if(!IsValid(instigator))
	{
		return;
	}
	PlayerCharacter = instigator;
	InteractComponent = Cast<UInteractComponent>(PlayerCharacter->GetComponentByClass(UInteractComponent::StaticClass()));
	FAttachmentTransformRules Rules = FAttachmentTransformRules::SnapToTargetNotIncludingScale ;
	bool LeftBoxAttached =  LeftHandBox->AttachToComponent(instigator->GetMesh(), Rules,LeftHandFistsSocket);
	bool RightBoxAttached =  RightHandBox->AttachToComponent(instigator->GetMesh(), Rules,RightHandFistsSocket);
	
	//UAnimMontage* MontageToPlay = WeaponStats.maSheathAnimations.FindRef("DrawWeaponMontag");
		
	//instigator->PlayAnimMontage(MontageToPlay);
	/*float DelayTime = 0.1f;

	// Call the function with the specified delay using a lambda function
	GetWorldTimerManager().SetTimer(TimerHandle, [this ,instigator ,Rules]() {

		bool Attached =  WeaponMesh->AttachToComponent(instigator->GetMesh(), Rules,EquipeHandSocketName);
		
	}, DelayTime, false);#1#
	
}*/

/*
void AFists::ApplyFistAttack(ACombatPlayerCharacter* instigator)
{
	if(!ActiveAbility)
	{
		if( IsValid(PlayerCharacter) && IsValid(InteractComponent))
		{
			if(InteractComponent->CanAttackCharacter())
			{
				
				InteractComponent->bIsSheildActive=false;
				
				AttackComboAnimCount = AttackComboAnimCount%FistsStats.maAttackAnimatios.Num();
				AttackComboAnimCount++;
				FAttachmentTransformRules Rules = FAttachmentTransformRules::SnapToTargetNotIncludingScale ;
			
				//bool Attached =  WeaponMesh->AttachToComponent(instigator->GetMesh(), Rules,EquipeHandSocketName);
	
				UAnimMontage* MontageToPlay = FistsStats.maAttackAnimatios.FindRef(FString::FromInt(AttackComboAnimCount));
		    
				instigator->PlayAnimMontage(MontageToPlay);
				float DelayTime = 2.0f;

				// Call the function with the specified delay using a lambda function
				GetWorldTimerManager().SetTimer(TimerHandle, [this ,instigator ,Rules]() {

					AttackComboAnimCount = 0;
	
		
				}, DelayTime, false);

			}

		}
	}
}
*/


/*
void AFists::ApplyFistsSheild(ACombatPlayerCharacter* instigator,bool Pressed)
{
	if(IsValid(PlayerCharacter) && IsValid(InteractComponent))
	{
		if(Pressed){
			if(InteractComponent->CanShieldAssaultCharacter())
			{
				InteractComponent->bIsSheildActive =true;
				instigator->ShieldAnimationSequence = FistsStats.ShieldAmimationSequence;
	
				// Call the function with the specified delay using a lambda function
		
			}
		}else
		{
			InteractComponent->DefenceAssaultStats = E_DefenceAssaultStats::EndDefenceAssault;
			InteractComponent->bIsSheildActive=false;
		}
		/*if(Pressed)
		{
			InteractComponent->bIsSheildActive =true;
			instigator->ShieldAnimationSequence = FistsStats.ShieldAmimationSequence;
			
		}
		else
		{
			InteractComponent->bIsSheildActive=false;
			
		}#1#
	
	}
}*/

