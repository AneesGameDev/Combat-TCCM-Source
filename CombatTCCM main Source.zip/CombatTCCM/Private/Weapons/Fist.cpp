// Fill out your copyright notice in the Description page of Project Settings.


#include "Weapons/Fist.h"
#include "Components/InteractComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "Kismet/KismetSystemLibrary.h"
#include "PhysicsEngine/PhysicsConstraintComponent.h"


// Sets default values
AFist::AFist()
{
	PrimaryActorTick.bCanEverTick = true;

	RootSceneComponent = CreateDefaultSubobject<USceneComponent>("RootSceneComponent");
	RootComponent = RootSceneComponent;
	
}

// Called when the game starts or when spawned
void AFist::BeginPlay()
{
	Super::BeginPlay();
}

// Called every frame
void AFist::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void AFist::EquippeWeapon(ACombatPlayerCharacter* _instigator)
{
	Super::EquippeWeapon(_instigator);
	if(!IsValid(_instigator)) return;
	WeaponDrawState = true;

}

void AFist::DrawAndSheathWeapon()
{
	Super::DrawAndSheathWeapon();
}

void AFist::DrawAndSheathShieldAssaults( bool Pressed)
{
	Super::DrawAndSheathShieldAssaults( Pressed);
	if (IsValid(OwnerPlayerCharacter) && IsValid(OwnerInteractComponent))
	{
		if (Pressed)
		{
			if (OwnerInteractComponent->CanShieldAssaultCharacter())
			{
				OwnerPlayerCharacter->ShieldAnimationSequence = WeaponStats.ShieldAmimationSequence;
				OwnerInteractComponent->DefenceAssaultStats = E_DefenceAssaultStats::StartDefenceAssault;
				// Call the function with the specified delay using a lambda function
			}
		}
		else
		{
			OwnerInteractComponent->DefenceAssaultStats = E_DefenceAssaultStats::EndDefenceAssault;
		}
	}
}

void AFist::StartAttackVisuals()
{
	Super::StartAttackVisuals();

	if (WeaponDrawState && IsValid(OwnerPlayerCharacter) && IsValid(OwnerInteractComponent))
	{

		OwnerInteractComponent->DefenceAssaultStats = E_DefenceAssaultStats::EndDefenceAssault;
		OwnerInteractComponent->AttackStates = E_AttackStats::StartAttack;

		AttackComboAnimCount = AttackComboAnimCount % WeaponStats.ComboAnimationCount;
		AttackComboAnimCount++;

		
			
		float DelayTime = 1.5f;

			
			
		// Call the function with the specified delay using a lambda function
		GetWorldTimerManager().SetTimer(TimerHandle, [this]()
		{
			AttackComboAnimCount = 0;
		}, DelayTime, false);

		const FName AnimationName= *FString::FromInt(AttackComboAnimCount);
		Multicast_PlayAnimationMontage(OwnerPlayerCharacter,AnimationName);
		//Multicast_StartAttackVisuals(OwnerPlayerCharacter , AttackComboAnimCount);
	}
}

void AFist::EndAttackVisuals()
{
	Super::EndAttackVisuals();
}

void AFist::SetStartAttackSocketLocation()
{
	Super::SetStartAttackSocketLocation();

	if(IsValid(OwnerPlayerCharacter))
	{
		ActorsToIgnore.Add(OwnerPlayerCharacter);

		const FVector LeftHansSocketLocation = OwnerPlayerCharacter->GetMesh()->GetSocketLocation(LeftHandSocketName);
		const FVector RighttHansSocketLocation = OwnerPlayerCharacter->GetMesh()->GetSocketLocation(RightHandSocketName);
		PreviousSocketLocations.Empty();
		/*for (auto SocketName : LeftHandSocketNameArray)
		{
			
			const FVector LeftHansSocketLocation = OwnerPlayerCharacter->GetMesh()->GetSocketLocation(SocketName);
			PreviousSocketLocations.Add(SocketName, LeftHansSocketLocation);
		}*/

		/*for (auto SocketName : RightHandSocketNameArray)
		{
			
			const FVector RighttHansSocketLocation = OwnerPlayerCharacter->GetMesh()->GetSocketLocation(SocketName);
			PreviousSocketLocations.Add(SocketName, RighttHansSocketLocation);
		}*/
		PreviousSocketLocations.Add(LeftHandSocketName, LeftHansSocketLocation);
		PreviousSocketLocations.Add(RightHandSocketName ,RighttHansSocketLocation);
		
	}
}

void AFist::StartAttackMechanics(int32 DualWeildIndex)
{
	Super::StartAttackMechanics(DualWeildIndex);

	// Check if this code is running on the server
	if (UKismetSystemLibrary::IsServer(this))
	{
		for (auto& SocketEntry : PreviousSocketLocations)

		{
			FName SocketName;
			FVector PreviousSocketLocation;
			FVector CurrentSocketLocation;
			FHitResult HitResults;
			FVector TraceStart;
			FVector TraceEnd;

			SocketName = SocketEntry.Key;
			PreviousSocketLocation = SocketEntry.Value;

			// Get the current socket location
			FRotator Rotation;
			CurrentSocketLocation = OwnerPlayerCharacter->GetMesh()->GetSocketLocation(SocketName);

			TraceStart = PreviousSocketLocation;
			TraceEnd = CurrentSocketLocation;
			 bool bHit = UKismetSystemLibrary::SphereTraceSingleByProfile(
							GetWorld(), TraceStart, TraceEnd, 30.f, "PlayerMeshProfile", true,
							ActorsToIgnore, EDrawDebugTrace::ForDuration, HitResults, true, FColor::Red, FLinearColor::Black,
							10.0f);
			if (bHit)
			{
				AActor* HitActor = HitResults.GetActor();
				ACombatPlayerCharacter* Player = Cast<ACombatPlayerCharacter>(HitResults.GetActor());
				//GEngine->AddOnScreenDebugMessage(-1,1.0f,FColor::Green,HitResults.BoneName.ToString());
				AddHittedCharacterInfo(Player, HitResults);
			}
			SocketEntry.Value = CurrentSocketLocation;
			//SetStartSocketLocations();
		}
	}
}

void AFist::EndAttackMechanics()
{
	Super::EndAttackMechanics();
	
}



/*void AFist::Multicast_StartAttackVisuals_Implementation(ACombatPlayerCharacter* _instigator, int32 MontageId)
{

	UAnimMontage* MontageToPlay = WeaponStats.maAttackAnimatios.FindRef(FString::FromInt(MontageId));
	_instigator->PlayAnimMontage(MontageToPlay);
	
}*/
