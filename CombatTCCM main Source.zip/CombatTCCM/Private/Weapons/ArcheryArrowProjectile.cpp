// Fill out your copyright notice in the Description page of Project Settings.


#include "Weapons/ArcheryArrowProjectile.h"

// Sets default values
AArcheryArrowProjectile::AArcheryArrowProjectile()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	ArrowRootSceneCompoent = CreateDefaultSubobject<USceneComponent>("ArrowRoot");
	SetRootComponent(ArrowRootSceneCompoent);
	ArrowMesh = CreateDefaultSubobject<UStaticMeshComponent>("ArrowMesh");
	ArrowMesh->SetupAttachment(GetRootComponent());

	ArrowProjectileMovementComponent = CreateDefaultSubobject<UProjectileMovementComponent>("ProjectileMovementComponent");


}

// Called when the game starts or when spawned
void AArcheryArrowProjectile::BeginPlay()
{
	Super::BeginPlay();

	ArrowProjectileMovementComponent->InitialSpeed = ProjectileInitialSpeed;
	ArrowProjectileMovementComponent->MaxSpeed = ProjectileMaxpeed;
	ArrowProjectileMovementComponent->SetAutoActivate(false);
	
}

// Called every frame
void AArcheryArrowProjectile::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

