// Fill out your copyright notice in the Description page of Project Settings.


#include "Weapons/Weapons.h"
#include "Components/InteractComponent.h"
#include "Components/StatsWidgetComponent.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Net/UnrealNetwork.h"

// Sets default values
AWeapons::AWeapons()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	//LeftHandPhysicsConstraintComponent = CreateDefaultSubobject<UPhysicsConstraintComponent>(TEXT("LeftHandPhysicsConstraint"));
	//LeftHandPhysicsConstraintComponent->SetupAttachment(GetRootComponent());
	//RightHandPhysicsConstraintComponent = CreateDefaultSubobject<UPhysicsConstraintComponent>(TEXT("RightHandPhysicsConstraint"));
	//RightHandPhysicsConstraintComponent->SetupAttachment(GetRootComponent());
	
}

// Called when the game starts or when spawned
void AWeapons::BeginPlay()
{
	Super::BeginPlay();
	PreviousSocketLocations.Empty();

}

// Called every frame
void AWeapons::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void AWeapons::Interaction(bool pressed)
{
}

void AWeapons::DrawAndSheathWeapon()
{
}

void AWeapons::StartAttackVisuals()
{
	
}

void AWeapons::SetAimingWeaponDirection()
{
}

void AWeapons::EndAttackVisuals()
{
}



void AWeapons::StartAttackMechanics(int32 DualWeildIndex)
{
	//GEngine->AddOnScreenDebugMessage(-1,2.0,FColor::Black, FString::Printf(TEXT("StartAttack Mechanincs")));
}


void AWeapons::EndAttackMechanics()
{
	//GEngine->AddOnScreenDebugMessage(-1,2.0,FColor::Black, FString::Printf(TEXT("EndtAttack Mechanincs")));
	if (UKismetSystemLibrary::IsServer(this))
	{
		TArray<ACombatPlayerCharacter*> KeysToRemove;
		
		for (auto HittedCharacters : HittedCharacterInfo)
		{

			if(auto Player = Cast<ACombatPlayerCharacter>(HittedCharacters.Key) )
			{
				if(IsValid(Player->InteractComponent))
				{
					UInteractComponent* PlayerInteractComponent = Player->InteractComponent;
					if(IsValid(PlayerInteractComponent))
					{
						PlayerInteractComponent->ApplyAttackMechanics(HittedCharacters.Value , this);
						//HittedCharacterInfo.Remove(HittedCharacters.Key);
						KeysToRemove.Add(HittedCharacters.Key);
					}
				}
			}
		
		}

		for (ACombatPlayerCharacter* Key : KeysToRemove)
		{
			HittedCharacterInfo.Remove(Key);
		}

		
	
	}
}




void AWeapons::SetSingleHandWeaponSocketNames(TArray<USkeletalMeshComponent*> MeshComponent)
{
	for (const auto Mesh : MeshComponent)
	{
		if(IsValid(Mesh))
		{
			AllSocketName = (Mesh->GetAllSocketNames());

			for (FName Socket : AllSocketName)
			{
				PreviousSocketLocations.Add(Socket, FVector::ZeroVector);
			}
		
		}
	}

}

void AWeapons::SetDualHandWeaponSocketNames(TArray<USkeletalMeshComponent*> MeshComponent)
{
	const USkeletalMeshComponent* MeshRight = MeshComponent[0];

		if(IsValid(MeshRight))
		{
			AllSocketName = (MeshRight->GetAllSocketNames());

			for (FName Socket : AllSocketName)
			{
				FString RihgtString = Socket.ToString();
				RihgtString+=TEXT("Right");
				FName SocketName = FName(*RihgtString);
				PreviousSocketLocations.Add(SocketName, FVector::ZeroVector);
			}
		
		}
	

    const USkeletalMeshComponent* MeshLeft = MeshComponent[1];
	{
		if(IsValid(MeshLeft))
		{
			AllSocketName = (MeshLeft->GetAllSocketNames());

			for (FName Socket : AllSocketName)
			{
				FString LeftString = Socket.ToString();
				LeftString+=TEXT("Left");
				FName SocketName = FName(*LeftString);
				PreviousSocketLocations.Add(SocketName, FVector::ZeroVector);
			}
		
		}
	}
}


void AWeapons::SetStartMeshSocketLocations(USkeletalMeshComponent* MeshComponent)
{
	
	for (auto& SocketEntry : PreviousSocketLocations)
	{
		const FName SocketName = SocketEntry.Key;

		// Get the current socket location
		const FVector CurrentSocketLocation = MeshComponent->GetSocketLocation(SocketName);

		// Update the entry in PreviousSocketLocations with the current location
		SocketEntry.Value = CurrentSocketLocation;
	}
}


/*
void AWeapons::AddHittedCharacterinArray(ACombatPlayerCharacter* PlayerCharacter)
{
   if(IsValid(PlayerCharacter)) HittedCharactersArray.AddUnique(PlayerCharacter); 
}*/

void AWeapons::Multicast_DrawandSheathWeapon_Implementation(ACombatPlayerCharacter* _instigator, FName MontageName,
															USkeletalMeshComponent* WeaponMesh, FName HostlerSocketName)
{
	if (IsValid(WeaponMesh) && IsValid(_instigator))
	{
		const FAttachmentTransformRules Rules = FAttachmentTransformRules::SnapToTargetNotIncludingScale;
		WeaponMesh->AttachToComponent(_instigator->GetMesh(), Rules, HostlerSocketName);
	}
}

void AWeapons::Multicast_PlayAnimationMontage_Implementation(ACombatPlayerCharacter* _instigator, FName AnimationName)
{
	FName Name = AnimationName;
	UAnimMontage* MontageToPlay = WeaponStats.maAttackAnimatios.FindRef(Name.ToString());
	//GEngine->AddOnScreenDebugMessage(-1,1.f,FColor::Blue,AnimationName.ToString());
	_instigator->PlayAnimMontage(MontageToPlay);
}

void AWeapons::SetStartAttackSocketLocation()
{
	
}


void AWeapons::AddHittedCharacterInfo(ACombatPlayerCharacter* Player, FHitResult HitResult)
{
		if (!HittedCharacterInfo.Contains(Player))
		{
			FHitAndBoneInfo HitResultInfo;
			TArray<FName> tempBoneNames;
			tempBoneNames.Add(HitResult.BoneName); // Add the first bone name to the array
			HitResultInfo.HitResult = HitResult;
			HitResultInfo.BoneNames = tempBoneNames;
			//HittedActorsArray.Add(HitCharacter);
			HittedCharacterInfo.Add(Player, HitResultInfo);
		}
		else
		{
			FHitAndBoneInfo& ExistingHitInfo = HittedCharacterInfo[Player];
			ExistingHitInfo.BoneNames.AddUnique(HitResult.BoneName); // Add unique bone names to the array
		}
	}
	



void AWeapons::DrawAndSheathShieldAssaults(bool Pressed)
{
}

void AWeapons::EquippeWeapon(ACombatPlayerCharacter* _instigator)
{
	if (IsValid(_instigator))
	{
		OwnerPlayerCharacter = _instigator;
		OwnerInteractComponent = Cast<UInteractComponent>(
			OwnerPlayerCharacter->GetComponentByClass(UInteractComponent::StaticClass()));
		OwnerHealthComponent = Cast<UStatsWidgetComponent>(
			OwnerPlayerCharacter->GetComponentByClass(UStatsWidgetComponent::StaticClass()));
		ActorsToIgnore.AddUnique(OwnerPlayerCharacter);
	}
}



void AWeapons::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	DOREPLIFETIME(AWeapons,LeftHandPhysicsConstraintComponent);
	DOREPLIFETIME(AWeapons, RightHandPhysicsConstraintComponent);
//	DOREPLIFETIME(AWeapons, AttackComboAnimCount);
	//DOREPLIFETIME(AWeapons, WeaponDrawState);
	//DOREPLIFETIME(AWeapons, OwnerInteractComponent);
	//DOREPLIFETIME(AWeapons, OwnerPlayerCharacter);
}


