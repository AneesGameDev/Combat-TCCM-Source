// Fill out your copyright notice in the Description page of Project Settings.


#include "Weapons/ArcheryAssaults.h"
#include "Camera/CameraComponent.h"
#include "Components/InteractComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetMathLibrary.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Net/UnrealNetwork.h"


AArcheryAssaults::AArcheryAssaults() : Super()
{

	PrimaryActorTick.bCanEverTick = true;
	ArcheryMesh = CreateDefaultSubobject<UStaticMeshComponent>("ArcheryMeshMesh");
	QuiverMesh = CreateDefaultSubobject<UStaticMeshComponent>("QuiverMeshMesh");
	//ArrowMesh = CreateDefaultSubobject<UStaticMeshComponent>("ArrowMesh");
	RootSceneComponent = CreateDefaultSubobject<USceneComponent>("RootSceneComponent");

	RootSceneComponent->SetupAttachment(GetRootComponent());
	//	RootComponent = RootSceneComponent;
	ArcheryMesh->SetupAttachment(RootSceneComponent);
	QuiverMesh->SetupAttachment(RootSceneComponent);
	//ArrowMesh->SetupAttachment(RootSceneComponent);

	CameraZoomComponent= CreateDefaultSubobject<UCameraZoomComponent>("CameraZoomComponent");
	
}

void AArcheryAssaults::BeginPlay()
{
	Super::BeginPlay();
}

void AArcheryAssaults::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	if(IsValid(OwnerPlayerCharacter))
	{
		if(OwnerPlayerCharacter->bIsAiming){
			AimingActorUpdateLocation();
		}
	}
}


void AArcheryAssaults::EquippeWeapon(ACombatPlayerCharacter* _instigator)
{
	Super::EquippeWeapon(_instigator);
	Multicast_EquippeWeapon(_instigator);
}

void AArcheryAssaults::Multicast_EquippeWeapon_Implementation(ACombatPlayerCharacter* _instigator)
{
	OwnerPlayerCharacter = _instigator;
	
	OwnerInteractComponent = Cast<UInteractComponent>(OwnerPlayerCharacter->GetComponentByClass(UInteractComponent::StaticClass()));
	
	FAttachmentTransformRules Rules = FAttachmentTransformRules::SnapToTargetNotIncludingScale ;
	WeaponDrawState = true;
	//bool Attached =  WeaponMesh->AttachToComponent(instigator->GetMesh(), Rules,EquipeHandSocketName);
	
	UAnimMontage* MontageToPlay = WeaponStats.SheathAnimations.FindRef("DrawWeaponMontag");
		
	_instigator->PlayAnimMontage(MontageToPlay);
	
	float DelayTime = 0.1f;

	// Call the function with the specified delay using a lambda function
	GetWorldTimerManager().SetTimer(TimerHandle, [this ,_instigator ,Rules]() {

		ArcheryMesh->AttachToComponent(_instigator->GetMesh(), Rules,EquipeLeftHandSocketName);
		QuiverMesh->AttachToComponent(_instigator->GetMesh(), Rules,HostlerRightSocketName);
		//ArrowMesh->AttachToComponent(_instigator->GetMesh(),Rules , EquipeRightHandSocketName);
		//ArrowMesh->SetVisibility(false);
		
	}, DelayTime, false);
}

void AArcheryAssaults::DrawAndSheathWeapon()
{
	Super::DrawAndSheathWeapon();


	if (WeaponDrawState)
	{
		WeaponDrawState = false;

		Multicast_DrawAndSheathWeapon(OwnerPlayerCharacter, "HostlerWeaponMontag", false);
		float DelayTime = 0.3f;

		//GetWorldTimerManager().SetTimer(TimerHandle, [this, instigator]{} ,DelayTime ,false);
		
		// Call the function with the specified delay using a lambda function
		GetWorldTimerManager().SetTimer(TimerHandle, [this  ]()
		{
			// Code to execute after the delay
			// Place your desired code here directly, without creating a new function
			// For example:
			Multicast_DrawAndSheathWeapon(OwnerPlayerCharacter, "HostlerWeaponMontag", true);
		}, DelayTime, false);
	}
	else
	{
		EquippeWeapon(OwnerPlayerCharacter);
	}
}

void AArcheryAssaults::Multicast_DrawAndSheathWeapon_Implementation(ACombatPlayerCharacter* _instigator,
	FName MontageName, bool AttachWeapon)
{

	if(AttachWeapon)
	{
		FAttachmentTransformRules Rules = FAttachmentTransformRules::SnapToTargetNotIncludingScale ;
		
		bool Attached =  ArcheryMesh->AttachToComponent(_instigator->GetMesh(), Rules,HostlerLeftSocketName);
	}
	else
	{
		UAnimMontage* MontageToPlay = WeaponStats.SheathAnimations.FindRef(MontageName.ToString());
		_instigator->PlayAnimMontage(MontageToPlay);
	}
	
}

void AArcheryAssaults::StartAttackVisuals()
{
	Super::StartAttackVisuals();
	if(UKismetSystemLibrary::IsServer(this))
	{
		Multicast_StartAttackVisuals(OwnerPlayerCharacter ,1);
	}
	/*if(WeaponDrawState && IsValid(OwnerPlayerCharacter) && IsValid(OwnerInteractComponent) && IsValid(CameraZoomComponent) && OwnerInteractComponent->AimingStats == E_Aiming::EndAiming)
	{
		OwnerInteractComponent->DefenceAssaultStats = E_DefenceAssaultStats::EndDefenceAssault;
		OwnerInteractComponent->AimingStats = E_Aiming::None;
		//OwnerInteractComponent->AttackStates = E_AttackStats::StartAttack;
			
		//AttackComboAnimCount = AttackComboAnimCount%WeaponStats.maAttackAnimatios.Num();
		//AttackComboAnimCount++;
		FAttachmentTransformRules Rules = FAttachmentTransformRules::SnapToTargetNotIncludingScale ;
		//bool Attached =  WeaponMesh->AttachToComponent(instigator->GetMesh(), Rules,EquipeHandSocketName);
	
		UAnimMontage* MontageToPlay = WeaponStats.maAttackAnimatios.FindRef(FString::FromInt(1));
		
		OwnerPlayerCharacter->PlayAnimMontage(MontageToPlay);
			
		float DelayTime = 1.5f;

		// Call the function with the specified delay using a lambda function
		GetWorldTimerManager().SetTimer(TimerHandle, [this]() {

			//AttackComboAnimCount = 0;
	
		
		}, DelayTime, false);
			
	}*/
}


void AArcheryAssaults::Multicast_StartAttackVisuals_Implementation(ACombatPlayerCharacter* _instigator, int32 MontageId)
{
	if(WeaponDrawState && IsValid(OwnerPlayerCharacter) && IsValid(OwnerInteractComponent) && IsValid(CameraZoomComponent) && OwnerInteractComponent->AimingStats == E_Aiming::EndAiming)
	{
		OwnerInteractComponent->DefenceAssaultStats = E_DefenceAssaultStats::EndDefenceAssault;
		OwnerInteractComponent->AimingStats = E_Aiming::None;
		//OwnerInteractComponent->AttackStates = E_AttackStats::StartAttack;
			
		//AttackComboAnimCount = AttackComboAnimCount%WeaponStats.maAttackAnimatios.Num();
		//AttackComboAnimCount++;
		FAttachmentTransformRules Rules = FAttachmentTransformRules::SnapToTargetNotIncludingScale ;
		//bool Attached =  WeaponMesh->AttachToComponent(instigator->GetMesh(), Rules,EquipeHandSocketName);
	
		UAnimMontage* MontageToPlay = WeaponStats.maAttackAnimatios.FindRef(FString::FromInt(1));
		
		OwnerPlayerCharacter->PlayAnimMontage(MontageToPlay);
			
		float DelayTime = 1.5f;

		// Call the function with the specified delay using a lambda function
		GetWorldTimerManager().SetTimer(TimerHandle, [this]() {

			//AttackComboAnimCount = 0;
	
		
		}, DelayTime, false);
			
	}
}

void AArcheryAssaults::DrawAndSheathShieldAssaults(bool Pressed)
{
	Super::DrawAndSheathShieldAssaults( Pressed);
	MulticastDrawAndSheathShieldAssaults(Pressed);
	
}

void AArcheryAssaults::CameraZoomeClientRPC(bool Pressed)
{
	if(!UKismetSystemLibrary::IsServer(OwnerPlayerCharacter) && OwnerPlayerCharacter->IsLocallyControlled())
	{
		CameraZoomComponent->ToggleCameraZoomed(Pressed , OwnerPlayerCharacter);
	}
	
}

void AArcheryAssaults::MulticastDrawAndSheathShieldAssaults_Implementation(bool Pressed)
{
	if(WeaponDrawState && IsValid(OwnerPlayerCharacter) && IsValid(OwnerInteractComponent))
	{
		if(Pressed){
			if(OwnerInteractComponent->CanShieldAssaultCharacter())
			{

				OwnerPlayerCharacter->ShieldAnimationSequence = WeaponStats.ShieldAmimationSequence;
				//OwnerInteractComponent->DefenceAssaultStats = E_DefenceAssaultStats::StartDefenceAssault;
				OwnerPlayerCharacter->bIsAiming=true;

				
				UAnimMontage* MontageToPlay = WeaponStats.maAttackAnimatios.FindRef("AimingAnimation");
		
				OwnerPlayerCharacter->PlayAnimMontage(MontageToPlay);
				
				const FVector ArrowSpawnLocation = OwnerPlayerCharacter->GetMesh()->GetSocketLocation(EquipeRightHandSocketName);
				const FRotator ArrowSpawnRotation = OwnerPlayerCharacter->GetMesh()->GetSocketRotation(EquipeRightHandSocketName);
				FActorSpawnParameters SpawnParam;
				FAttachmentTransformRules AttachTransformRules = FAttachmentTransformRules(EAttachmentRule::SnapToTarget,EAttachmentRule::SnapToTarget ,
				EAttachmentRule::SnapToTarget ,false);

				
				
				SpawnParam.Instigator = Cast<APawn>(GetOwner());
				
				ArcheryArrowProjectileObject =  GetWorld()->SpawnActor<AArcheryArrowProjectile>(ArcheryArrowProjectileClass , ArrowSpawnLocation ,ArrowSpawnRotation ,SpawnParam);
				ArcheryArrowProjectileObject->AttachToComponent(OwnerPlayerCharacter->GetMesh() , AttachTransformRules , EquipeRightHandSocketName);
				// Call the function with the specified delay using a lambda function
				//OwnerPlayerCharacter->GetActorRotation()+=GetActorRotation()+FRotator(0,0,90);
				//OwnerPlayerCharacter->GetCharacterMovement()->bOrientRotationToMovement =false;
				// Get the camera's forward vector.
				
					/*const APlayerController* PController = Cast<APlayerController>(OwnerPlayerCharacter->Controller);
					PController->PlayerCameraManager->ViewPitchMax = 30;
					PController->PlayerCameraManager->ViewPitchMin = -80;*/
					
				//	FRotator Rotation = new FRotator(0.f,NewRotation ,0.f);
				//	OwnerPlayerCharacter->SetActorRotation()
					
				}
			
		}else
		{
			if(IsValid(ArcheryArrowProjectileObject)) ArcheryArrowProjectileObject->Destroy();
			//OwnerInteractComponent->DefenceAssaultStats = E_DefenceAssaultStats::EndDefenceAssault;
			//OwnerPlayerCharacter->ShieldAnimationSequence = nullptr;
			OwnerPlayerCharacter->bIsAiming=false;
			
		//	OwnerPlayerCharacter->GetCharacterMovement()->bOrientRotationToMovement =true;
		}
		/*CameraZoomComponent->ToggleCameraZoomed(Pressed , OwnerPlayerCharacter);*/
		//Start Focus Strategy here
	}
}

void AArcheryAssaults::StartAttackMechanics(int32 DualWeildIndex)
{
	Super::StartAttackMechanics(DualWeildIndex);
	//ServerStartAtatckSocketLocation();
	CustomStartAttackEvent();
}

void AArcheryAssaults::SetAimingWeaponDirection()
{
	Super::SetAimingWeaponDirection();
	/*if(!UKismetSystemLibrary::IsServer(OwnerPlayerCharacter) && OwnerPlayerCharacter->IsLocallyControlled())
	{
		// Converting a class pointer to an integer !UKismetSystemLibrary::IsServer(OwnerPlayerCharacter) && OwnerPlayerCharacter->IsLocallyControlled()
		//	OwnerPlayerCharacter* MyObject = GetObject();
		//int64 MyInteger = reinterpret_cast<int64>(OwnerPlayerCharacter);

		//FVector* VectorCasting = reinterpret_cast<FVector*>(OwnerPlayerCharacter);
		// Converting the integer back to a pointer
		//AYourClass* MyObjectCopy = reinterpret_cast<AYourClass*>(MyInteger);

		//int32* Pointer = Cast<int32>(&OwnerPlayerCharacter);
		//	FVector StartLocation ;//= 	OwnerPlayerCharacter->GetFollowCamera()->GetComponentLocation();
		//	FVector EndLocation ;//= (OwnerPlayerCharacter->GetFollowCamera()->GetForwardVector()*ArcheryArrowProjectileObject->ArrowDistanceMultiplier) + StartLocation;


		APlayerController* PlayerController = Cast<APlayerController>(OwnerPlayerCharacter->GetController());

		if (PlayerController)
		{
			ULocalPlayer* LocalPlayer = Cast<ULocalPlayer>(PlayerController->Player);

			if (LocalPlayer)
			{
				// Get the player's viewport size
				
				int32 ViewportX, ViewportY;
				PlayerController->GetViewportSize(ViewportX, ViewportY);

				// Calculate the screen center
				FVector2D ScreenCenter(ViewportX / 2, ViewportY / 2);

				// Convert the screen center to a world-space location and direction
				//FVector WorldLocation, WorldDirection;
				PlayerController->DeprojectScreenPositionToWorld(ScreenCenter.X, ScreenCenter.Y, StartAttackLocation, AttackDirection);

				//StartAttackLocation = WorldLocation;
				
			}
		}
	}*/
}

void AArcheryAssaults::SetStartAttackSocketLocation()
{
	Super::SetStartAttackSocketLocation();

	ServerStartAtatckSocketLocation();
	
}

void AArcheryAssaults::ClientSetViewPortLocation_Implementation()
{
	if(!UKismetSystemLibrary::IsServer(OwnerPlayerCharacter) && OwnerPlayerCharacter->IsLocallyControlled())
	{
		// Converting a class pointer to an integer !UKismetSystemLibrary::IsServer(OwnerPlayerCharacter) && OwnerPlayerCharacter->IsLocallyControlled()
		//	OwnerPlayerCharacter* MyObject = GetObject();
		//int64 MyInteger = reinterpret_cast<int64>(OwnerPlayerCharacter);

		//FVector* VectorCasting = reinterpret_cast<FVector*>(OwnerPlayerCharacter);
		// Converting the integer back to a pointer
		//AYourClass* MyObjectCopy = reinterpret_cast<AYourClass*>(MyInteger);

		//int32* Pointer = Cast<int32>(&OwnerPlayerCharacter);
		FVector StartLocation ;//= 	OwnerPlayerCharacter->GetFollowCamera()->GetComponentLocation();
		FVector EndLocation ;//= (OwnerPlayerCharacter->GetFollowCamera()->GetForwardVector()*ArcheryArrowProjectileObject->ArrowDistanceMultiplier) + StartLocation;


		APlayerController* PlayerController = Cast<APlayerController>(OwnerPlayerCharacter->GetController());

		if (PlayerController)
		{
			ULocalPlayer* LocalPlayer = Cast<ULocalPlayer>(PlayerController->Player);

			if (LocalPlayer)
			{
				// Get the player's viewport size
				
				int32 ViewportX, ViewportY;
				PlayerController->GetViewportSize(ViewportX, ViewportY);

				// Calculate the screen center
				FVector2D ScreenCenter(ViewportX / 2, ViewportY / 2);

				// Convert the screen center to a world-space location and direction
				FVector WorldLocation, WorldDirection;
				PlayerController->DeprojectScreenPositionToWorld(ScreenCenter.X, ScreenCenter.Y, WorldLocation, WorldDirection);

				StartLocation = WorldLocation;
				EndLocation = (WorldDirection*ArcheryArrowProjectileObject->ArrowDistanceMultiplier) + StartLocation;
			}
		}
	
		ServerStartAtatckSocketLocation();
	}
}

/*if(IsValid(ArcheryArrowProjectileObject))
	{
		
		FVector StartLocation = 	OwnerPlayerCharacter->GetFollowCamera()->K2_GetComponentLocation();
		FVector EndLocation = (OwnerPlayerCharacter->GetFollowCamera()->GetForwardVector()*ArcheryArrowProjectileObject->ArrowDistanceMultiplier) + StartLocation;
		FVector ArrowThroughDirection;


		FName SocketName;
		FVector PreviousSocketLocation;
		FVector CurrentSocketLocation;
		FHitResult HitResults;
		FVector TraceStart;
		FVector TraceEnd;

		TraceStart = PreviousSocketLocation;
		TraceEnd = CurrentSocketLocation;
		
		
		if (UKismetSystemLibrary::LineTraceSingleByProfile(
			GetWorld(), StartLocation, EndLocation, AttackTraceMeshProfileName, true, ActorsToIgnore,
			EDrawDebugTrace::ForDuration, HitResults, true, FColor::Red, FLinearColor::Black, 10.0f))
		{
			ArrowThroughDirection = (HitResults.Location - ArcheryArrowProjectileObject->GetActorLocation()).GetSafeNormal();
			
			ACombatPlayerCharacter* Player = Cast<ACombatPlayerCharacter>(HitResults.GetActor());
			GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Green, HitResults.BoneName.ToString());
			AddHittedCharacterInfo(Player, HitResults);
		}
		else
		{
			ArrowThroughDirection = (HitResults.TraceEnd - ArcheryArrowProjectileObject->GetActorLocation()).GetSafeNormal();
		}
		ArcheryArrowProjectileObject->K2_DetachFromActor(EDetachmentRule::KeepWorld,EDetachmentRule::KeepWorld,EDetachmentRule::KeepWorld);
		ArcheryArrowProjectileObject->ArrowProjectileMovementComponent->Velocity =  ArrowThroughDirection * VelocityMultiplier;
		ArcheryArrowProjectileObject->ArrowProjectileMovementComponent->Activate();
		
	}*/

	


void AArcheryAssaults::ServerStartAtatckSocketLocation_Implementation()
{
	if(IsValid(ArcheryArrowProjectileObject))
	{
		FVector ArrowThroughDirection;
		
		
		//UE_LOG(LogTemp, Warning, TEXT("StartLocation :  %s"), *StartLocation.ToString());
		//UE_LOG(LogTemp, Warning, TEXT("EndLocation : %s"), *EndLocation.ToString());
       // UE_LOG(LogTemp,Warning, FString::Printf(TEXT("%s")) ,*EndLocation.ToString()));
		FName SocketName;
		FVector PreviousSocketLocation;
		FVector CurrentSocketLocation;
		FHitResult HitResults;
		//FVector TraceStart;
	//	FVector TraceEnd;
		
		
		//TraceStart = PreviousSocketLocation;
		//TraceEnd = CurrentSocketLocation;
		FVector EndAttackLocation = (AttackDirection*ArcheryArrowProjectileObject->ArrowDistanceMultiplier) + AttackLocation;
		
		bool bHit =UKismetSystemLibrary::LineTraceSingleByProfile(
			GetWorld(), AttackLocation, EndAttackLocation, AttackTraceMeshProfileName, true, ActorsToIgnore,
			EDrawDebugTrace::ForDuration, HitResults, true, FColor::Red, FLinearColor::Black, 10.0f);
		if (bHit)
		{//(HitResults.Location - ArcheryArrowProjectileObject->GetActorLocation())
			ArrowThroughDirection = EndAttackLocation - AttackLocation;
			
			ACombatPlayerCharacter* Player = Cast<ACombatPlayerCharacter>(HitResults.GetActor());
			GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Green, HitResults.BoneName.ToString());
			AddHittedCharacterInfo(Player, HitResults);
		}
		else
		{
			ArrowThroughDirection = EndAttackLocation - AttackLocation;
		}
		MulticastArrowMovingEffect(ArrowThroughDirection);
		//ArcheryArrowProjectileObject->K2_DetachFromActor(EDetachmentRule::KeepWorld,EDetachmentRule::KeepWorld,EDetachmentRule::KeepWorld);
		//ArcheryArrowProjectileObject->ArrowProjectileMovementComponent->Velocity =  ArrowThroughDirection * VelocityMultiplier;
		//ArcheryArrowProjectileObject->ArrowProjectileMovementComponent->Activate();
		/*ArcheryArrowProjectileObject->K2_DetachFromActor(EDetachmentRule::KeepWorld,EDetachmentRule::KeepWorld,EDetachmentRule::KeepWorld);
		ArcheryArrowProjectileObject->ArrowProjectileMovementComponent->Velocity =  ArrowThroughDirection * VelocityMultiplier;
		ArcheryArrowProjectileObject->ArrowProjectileMovementComponent->Activate();*/
		
	}
}

void AArcheryAssaults::MulticastArrowMovingEffect_Implementation(FVector Direction)
{
	if(IsValid(ArcheryArrowProjectileObject))
	{
	
		ArcheryArrowProjectileObject->K2_DetachFromActor(EDetachmentRule::KeepWorld,EDetachmentRule::KeepWorld,EDetachmentRule::KeepWorld);
		ArcheryArrowProjectileObject->ArrowProjectileMovementComponent->Velocity =  Direction * VelocityMultiplier;
		ArcheryArrowProjectileObject->ArrowProjectileMovementComponent->Activate();
	}
}
void AArcheryAssaults::EndAttackVisuals()
{
	Super::EndAttackVisuals();

	//DrawAndSheathShieldAssaults(false);
	//OwnerPlayerCharacter->bIsAiming=false;
	//if(IsValid(ArcheryArrowProjectileObject)) ArcheryArrowProjectileObject->Destroy(); &&  OwnerPlayerCharacter->IsLocallyControlled()
}

void AArcheryAssaults::AimingActorUpdateLocation_Implementation()
{
	
	
	UE_LOG(LogTemp,Warning,TEXT("%s -> %s >>> %d"), *(FString(__FUNCTION__)), *(FString::FromInt(__LINE__)), UKismetSystemLibrary::IsServer(OwnerPlayerCharacter));
	if(UKismetSystemLibrary::IsServer(OwnerPlayerCharacter) )
	{
		FVector CameraForwardVector = OwnerPlayerCharacter->Controller->GetControlRotation().Vector();

		// Make sure the forward vector is not zero (in case the camera is pointing straight up or down).
		if (!CameraForwardVector.IsNearlyZero())
		{
			// Set the actor's rotation to face the camera's forward vector.
			 FRotator NewRotation = CameraForwardVector.Rotation();
			NewRotation.Pitch =0.f;
			NewRotation.Roll =0.f;
			//SetActorRotationInMultiplayer(OwnerPlayerCharacter , NewRotation);
			OwnerPlayerCharacter->SetActorRotation(NewRotation);
			SetActorRotationInMultiplayer(OwnerPlayerCharacter , NewRotation);
		}
	}
	/*if(UKismetSystemLibrary::IsServer(OwnerPlayerCharacter) )
	{
			OwnerPlayerCharacter->SetActorRotation(NewRotation);
		}*/
	
	
}

void AArcheryAssaults::SetActorRotationInMultiplayer_Implementation(ACombatPlayerCharacter* PlayerCharacter, FRotator NewRotation)
{
	PlayerCharacter->SetActorRotation(NewRotation);
}

void AArcheryAssaults::EndAttackMechanics()
{
	Super::EndAttackMechanics();

	if (UKismetSystemLibrary::IsServer(this))
	{
		if(OwnerPlayerCharacter->bIsAiming )
		{
			DrawAndSheathShieldAssaults(true);
			//StartAttackVisuals();
			//OwnerPlayerCharacter->bIsAiming=false;
			//DrawAndSheathShieldAssaults(false);
		
			//DrawAndSheathShieldAssaults(true);
		}
	}
}

void AArcheryAssaults::CustomStartAttackEvent_Implementation()
{
}

/*
void AArcheryAssaults::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	DOREPLIFETIME(AArcheryAssaults, StartAttackLocation);
	DOREPLIFETIME(AArcheryAssaults, AttackDirection);
	DOREPLIFETIME(AArcheryAssaults, EndAttackLocation);
}
*/


