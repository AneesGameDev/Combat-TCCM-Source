// Fill out your copyright notice in the Description page of Project Settings.


#include "Weapons/DualWield.h"

#include "Components/InteractComponent.h"
#include "Kismet/KismetSystemLibrary.h"
#include "PhysicsEngine/PhysicsConstraintComponent.h"

// Sets default values
ADualWield::ADualWield()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	WeaponRootSceneComponent = CreateDefaultSubobject<USceneComponent>("WeaponRootSceneComponent");
	SetRootComponent(WeaponRootSceneComponent);
	LeftWeaponMesh = CreateDefaultSubobject<USkeletalMeshComponent>("LeftWeaponMesh");
	RightWeaponMesh = CreateDefaultSubobject<USkeletalMeshComponent>("RightWeaponMesh");

	LeftWeaponMesh->SetupAttachment(GetRootComponent());
	RightWeaponMesh->SetupAttachment(GetRootComponent());
}

// Called when the game starts or when spawned
void ADualWield::BeginPlay()
{
	Super::BeginPlay();

	//First Index Of Array Should Be RightWeapon When Type of Weapon is Dual Wield
	SetSingleHandWeaponSocketNames(TArray{RightWeaponMesh, LeftWeaponMesh});
}

// Called every frame
void ADualWield::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void ADualWield::EquippeWeapon(ACombatPlayerCharacter* _instigator)
{
	Super::EquippeWeapon(_instigator);

	if (!IsValid(LeftWeaponMesh) && !IsValid(RightWeaponMesh)) return;

	FAttachmentTransformRules Rules = FAttachmentTransformRules::SnapToTargetNotIncludingScale;
	WeaponDrawState = true;
	float DelayTime = 0.2f;
	//Call the function with the specified delay using a lambda function
	GetWorldTimerManager().SetTimer(TimerHandle, [this ,_instigator ,Rules]()
	{
		LeftWeaponMesh->AttachToComponent(_instigator->GetMesh(), Rules, EquipeLeftHandSocketName);
		RightWeaponMesh->AttachToComponent(_instigator->GetMesh(), Rules, EquipeRightHandSocketName);
		//	WeaponMesh->AttachToComponent(_instigator->GetMesh(), Rules, EquipeHandSocketName);
	}, DelayTime, false);


	Multicast_PlayAnimationMontage(_instigator,"DrawWeaponMontag");
	//Multicast_EquippeWeapon(_instigator);
}

/*void ADualWield::Multicast_EquippeWeapon_Implementation(ACombatPlayerCharacter* _instigator)
{
	UAnimMontage* MontageToPlay = WeaponStats.SheathAnimations.FindRef("DrawWeaponMontag");
	_instigator->PlayAnimMontage(MontageToPlay);
}*/

void ADualWield::DrawAndSheathWeapon()
{
	Super::DrawAndSheathWeapon();

	if (WeaponDrawState)
	{
		WeaponDrawState = false;

		
		Multicast_PlayAnimationMontage(OwnerPlayerCharacter,"HostlerWeaponMontag");
		//Multicast_DrawAndSheathWeapon(OwnerPlayerCharacter, "HostlerWeaponMontag", false);

		float DelayTime = 0.5f;

		GetWorldTimerManager().SetTimer(TimerHandle, [this]()
		{
			//UE_LOG(LogTemp, Warning, TEXT("Delayed execution!"));
			//bool LeftHostler =  LeftWeaponMesh->AttachToComponent(instigator->GetMesh(), Rules,HostlerLeftSocketName);
			//bool RightHostler =  RightWeaponMesh->AttachToComponent(instigator->GetMesh(), Rules,HostlerRightSocketName);

			Multicast_DrawandSheathWeapon(OwnerPlayerCharacter,"HostlerWeaponMontag" , LeftWeaponMesh, HostlerLeftSocketName);
			Multicast_DrawandSheathWeapon(OwnerPlayerCharacter,"HostlerWeaponMontag" , RightWeaponMesh, HostlerRightSocketName);
			
		//	Multicast_DrawAndSheathWeapon(OwnerPlayerCharacter, "HostlerWeaponMontag", true);
		}, DelayTime, false);
	}
	else
	{
		EquippeWeapon(OwnerPlayerCharacter);
	}
}

/*
void ADualWield::Multicast_DrawAndSheathWeapon_Implementation(ACombatPlayerCharacter* _instigator, FName MontageName,
                                                              bool AttachWeapon)
{
	if (AttachWeapon)
	{
		FAttachmentTransformRules Rules = FAttachmentTransformRules::SnapToTargetNotIncludingScale;

		LeftWeaponMesh->AttachToComponent(_instigator->GetMesh(), Rules, HostlerLeftSocketName);
		RightWeaponMesh->AttachToComponent(_instigator->GetMesh(), Rules, HostlerRightSocketName);
	}
	else
	{
		UAnimMontage* MontageToPlay = WeaponStats.SheathAnimations.FindRef(MontageName.ToString());
		_instigator->PlayAnimMontage(MontageToPlay);
	}
}*/

void ADualWield::StartAttackVisuals()
{
	if (WeaponDrawState && IsValid(OwnerPlayerCharacter) && IsValid(OwnerInteractComponent))
	{
		Super::StartAttackVisuals();
	
		OwnerInteractComponent->DefenceAssaultStats = E_DefenceAssaultStats::EndDefenceAssault;
		OwnerInteractComponent->AttackStates = E_AttackStats::StartAttack;

		AttackComboAnimCount = AttackComboAnimCount %  WeaponStats.ComboAnimationCount;
		AttackComboAnimCount++;

		//bool Attached =  WeaponMesh->AttachToComponent(instigator->GetMesh(), Rules,EquipeHandSocketName);

		//Multicast_StartAttackVisuals(OwnerPlayerCharacter, AttackComboAnimCount);

		float DelayTime = 1.5f;

		// Call the function with the specified delay using a lambda function
		GetWorldTimerManager().SetTimer(TimerHandle, [this]()
		{
			AttackComboAnimCount = 0;
		}, DelayTime, false);

		const FName AnimationNAme= *FString::FromInt(AttackComboAnimCount);
		Multicast_PlayAnimationMontage(OwnerPlayerCharacter, AnimationNAme);
	}
}


/*void ADualWield::Multicast_StartAttackVisuals_Implementation(ACombatPlayerCharacter* _instigator, int32 MontageId)
{
	UAnimMontage* MontageToPlay = WeaponStats.maAttackAnimatios.FindRef(FString::FromInt(MontageId));

	_instigator->PlayAnimMontage(MontageToPlay);
}*/

void ADualWield::DrawAndSheathShieldAssaults(bool Pressed)
{
	Super::DrawAndSheathShieldAssaults(Pressed);


	if (WeaponDrawState && IsValid(OwnerPlayerCharacter) && IsValid(OwnerInteractComponent))
	{
		if (Pressed)
		{
			if (OwnerInteractComponent->CanShieldAssaultCharacter())
			{
				OwnerPlayerCharacter->ShieldAnimationSequence = WeaponStats.ShieldAmimationSequence;
				OwnerInteractComponent->DefenceAssaultStats = E_DefenceAssaultStats::StartDefenceAssault;

				// Call the function with the specified delay using a lambda function
			}
		}
		else
		{
			OwnerInteractComponent->DefenceAssaultStats = E_DefenceAssaultStats::EndDefenceAssault;
		}
	}
}

void ADualWield::EndAttackVisuals()
{
	Super::EndAttackVisuals();
}

void ADualWield::SetStartAttackSocketLocation()
{
	Super::SetStartAttackSocketLocation();
	SetStartMeshSocketLocations(RightWeaponMesh);
	SetStartMeshSocketLocations(LeftWeaponMesh);
}

void ADualWield::StartAttackMechanics(int32 DualWeildIndex)
{
	Super::StartAttackMechanics(DualWeildIndex);

	if (UKismetSystemLibrary::IsServer(this))
	{
		switch (DualWeildIndex)
		{
		case 1: RightStartAttackMechanics();
			break;
		case 2: LeftStartAttackMechanics();
			break;
		case 0: DualStartAttackMechanics();
			break;
		default: return;
		}
	}
}

void ADualWield::EndAttackMechanics()
{
	Super::EndAttackMechanics();
}

void ADualWield::RightStartAttackMechanics()
{
	int32 MapSize = PreviousSocketLocations.Num();
	int32 Index = 0;
	int32 HalfSize = MapSize / 2;

	for (auto& SocketEntry : PreviousSocketLocations)
	{
		Index++;
		if (Index < HalfSize)
		{
			FName SocketName;
			FVector PreviousSocketLocation;
			FVector CurrentSocketLocation;
			FHitResult HitResults;
			FVector TraceStart;
			FVector TraceEnd;

			SocketName = SocketEntry.Key;

			FString String = SocketName.ToString();

			PreviousSocketLocation = SocketEntry.Value;
			TraceStart = PreviousSocketLocation;

			CurrentSocketLocation = RightWeaponMesh->GetSocketLocation(SocketName);

			TraceEnd = CurrentSocketLocation;

			if (auto bHit = UKismetSystemLibrary::LineTraceSingleByProfile(
				GetWorld(), TraceStart, TraceEnd, "PlayerMeshProfile", true, ActorsToIgnore,
				EDrawDebugTrace::ForDuration, HitResults, true, FColor::Red, FLinearColor::Black, 10.0f))
			{
				ACombatPlayerCharacter* Player = Cast<ACombatPlayerCharacter>(HitResults.GetActor());
				GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Green, HitResults.BoneName.ToString());
				AddHittedCharacterInfo(Player, HitResults);
			}
			SocketEntry.Value = CurrentSocketLocation;
		}
		else
		{
			return;
		}
	}
}

void ADualWield::LeftStartAttackMechanics()
{
	int32 MapSize = PreviousSocketLocations.Num();
	int32 HalfSize = MapSize / 2;
	int32 Index = 0;


	for (auto& SocketEntry : PreviousSocketLocations)
	{
		Index++;
		if (Index > HalfSize)
		{
			FName SocketName;
			FVector PreviousSocketLocation;
			FVector CurrentSocketLocation;
			FHitResult HitResults;
			FVector TraceStart;
			FVector TraceEnd;

			SocketName = SocketEntry.Key;

			FString String = SocketName.ToString();

			PreviousSocketLocation = SocketEntry.Value;
			TraceStart = PreviousSocketLocation;

			CurrentSocketLocation = LeftWeaponMesh->GetSocketLocation(SocketName);

			TraceEnd = CurrentSocketLocation;

			if (auto bHit = UKismetSystemLibrary::LineTraceSingleByProfile(
				GetWorld(), TraceStart, TraceEnd, "PlayerMeshProfile", true, ActorsToIgnore,
				EDrawDebugTrace::ForDuration, HitResults, true, FColor::Red, FLinearColor::Black, 10.0f))
			{
				ACombatPlayerCharacter* Player = Cast<ACombatPlayerCharacter>(HitResults.GetActor());
				GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Green, HitResults.BoneName.ToString());
				AddHittedCharacterInfo(Player, HitResults);
			}
			SocketEntry.Value = CurrentSocketLocation;
		}
	}
}

void ADualWield::DualStartAttackMechanics()
{
	for (auto& SocketEntry : PreviousSocketLocations)
	{
		FName SocketName;
		FVector PreviousSocketLocation;
		FVector CurrentSocketLocation;
		FHitResult HitResults;
		FVector TraceStart;
		FVector TraceEnd;

		SocketName = SocketEntry.Key;

		PreviousSocketLocation = SocketEntry.Value;
		TraceStart = PreviousSocketLocation;

		CurrentSocketLocation = LeftWeaponMesh->DoesSocketExist(SocketName)
			                        ? LeftWeaponMesh->GetSocketLocation(SocketName)
			                        : RightWeaponMesh->GetSocketLocation(SocketName);

		TraceEnd = CurrentSocketLocation;

		if (auto bHit = UKismetSystemLibrary::LineTraceSingleByProfile(
			GetWorld(), TraceStart, TraceEnd, "PlayerMeshProfile", true, ActorsToIgnore,
			EDrawDebugTrace::ForDuration, HitResults, true, FColor::Red, FLinearColor::Black, 10.0f))
		{
			ACombatPlayerCharacter* Player = Cast<ACombatPlayerCharacter>(HitResults.GetActor());
			GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Green, HitResults.BoneName.ToString());
			AddHittedCharacterInfo(Player, HitResults);
		}
		SocketEntry.Value = CurrentSocketLocation;
	}
}
