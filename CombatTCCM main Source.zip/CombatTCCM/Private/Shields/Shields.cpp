// Fill out your copyright notice in the Description page of Project Settings.


#include "Shields/Shields.h"
#include "Net/UnrealNetwork.h"
#include "PhysicsEngine/PhysicsConstraintComponent.h"

// Sets default values
AShields::AShields()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	
	LeftHandPhysicsConstraintComponent = CreateDefaultSubobject<UPhysicsConstraintComponent>(TEXT("LeftHandPhysicsConstraint"));
	LeftHandPhysicsConstraintComponent->SetupAttachment(RootComponent);
}

// Called when the game starts or when spawned
void AShields::BeginPlay()
{
	Super::BeginPlay();
	InitializePhysicsConstraints();
}

// Called every frame
void AShields::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void AShields::equippeShield(ACombatPlayerCharacter* instigator)
{
}

bool AShields::hostlerAndDrawShield(ACombatPlayerCharacter* instigator)
{
return false;
}

void AShields::StartShieldDefence(ACombatPlayerCharacter* instigator,bool Pressed)
{
}

void AShields::InitializePhysicsConstraints()
{
	if(IsValid(LeftHandPhysicsConstraintComponent) )
	{
		//Initialize Left HAnd Physics Constraints
		FConstraintInstance& LeftConstraintInstance = LeftHandPhysicsConstraintComponent->ConstraintInstance;
		LeftConstraintInstance.SetLinearXLimit(LCM_Locked, 0.0f);
		LeftConstraintInstance.SetLinearYLimit(LCM_Locked, 0.0f);
		LeftConstraintInstance.SetLinearZLimit(LCM_Locked, 0.0f);
		LeftConstraintInstance.SetAngularSwing1Limit(ACM_Locked, 0.0f);
		LeftConstraintInstance.SetAngularSwing2Limit(ACM_Locked, 0.0f);
		LeftConstraintInstance.SetAngularTwistLimit(ACM_Locked, 0.0f);
		LeftHandPhysicsConstraintComponent->UpdateConstraintFrames();
	}
}

void AShields::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	DOREPLIFETIME(AShields,LeftHandPhysicsConstraintComponent);
}