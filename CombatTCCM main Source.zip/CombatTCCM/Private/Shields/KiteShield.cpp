// Fill out your copyright notice in the Description page of Project Settings.
#include "Shields/KiteShield.h"
#include "CombatTCCM/CombatPlayerCharacter.h"
#include "Components/InteractComponent.h"
#include "PhysicsEngine/PhysicsConstraintComponent.h"


AKiteShield::AKiteShield()
{
	ShieldMesh = CreateDefaultSubobject<UStaticMeshComponent>("WeaponMesh");
	RootSceneComponent = CreateDefaultSubobject<USceneComponent>("RootSceneComponent");

	RootSceneComponent->SetupAttachment(GetRootComponent());
	RootComponent = RootSceneComponent;
	ShieldMesh->SetupAttachment(RootSceneComponent);
}

void AKiteShield::BeginPlay()
{
	Super::BeginPlay();
}

void AKiteShield::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void AKiteShield::equippeShield(ACombatPlayerCharacter* instigator)
{
	Super::equippeShield(instigator);
	if(!IsValid(instigator)) return;

	PlayerCharacter = instigator;
    InteractComponent = Cast<UInteractComponent>(PlayerCharacter->GetComponentByClass(UInteractComponent::StaticClass()));
	
	FAttachmentTransformRules Rules = FAttachmentTransformRules::SnapToTargetNotIncludingScale ;
	ShieldDrawState = true;
	//bool Attached =  WeaponMesh->AttachToComponent(instigator->GetMesh(), Rules,EquipeHandSocketName);
	
//	UAnimMontage* MontageToPlay = ShieldStats.maShieldAnimMontag.FindRef("DrawShieldMontag");
		
	//instigator->PlayAnimMontage(MontageToPlay);
	float DelayTime = 0.01f;

	// Call the function with the specified delay using a lambda function
	GetWorldTimerManager().SetTimer(TimerHandle, [this ,instigator ,Rules]() {

		
		if (IsValid(LeftHandPhysicsConstraintComponent))
		{
			//ShieldMesh->SetSimulatePhysics(true);
			UPrimitiveComponent* CharacterMesh = instigator->GetMesh();
			// Set up the constraint instance and configure it
			//bool Attached = WeaponMesh->K2_AttachToComponent(instigator->GetMesh(), EquipeHandSocketName,Rules.LocationRule, Rules.RotationRule, Rules.ScaleRule,true);
			bool Attached =  ShieldMesh->AttachToComponent(instigator->GetMesh(), Rules,LeftShieldHandSocket);
			LeftHandPhysicsConstraintComponent->SetConstrainedComponents(ShieldMesh, NAME_None, CharacterMesh, "Hand_L");
		}
		
		
	}, DelayTime, false);

	
}

bool AKiteShield::hostlerAndDrawShield(ACombatPlayerCharacter* instigator)
{
	Super::hostlerAndDrawShield(instigator);

	FAttachmentTransformRules Rules = FAttachmentTransformRules::SnapToTargetNotIncludingScale ;
	if(ShieldDrawState)
	{
		ShieldDrawState= false;
		//UAnimMontage* MontageToPlay = ShieldStats.maShieldAnimMontag.FindRef("HostlerShieldMontag");
		//instigator->PlayAnimMontage(MontageToPlay);
	
		float DelayTime = 0.01f;
		
		GetWorldTimerManager().SetTimer(TimerHandle, [this ,instigator ,Rules]() {
		
			//UE_LOG(LogTemp, Warning, TEXT("Delayed execution!"));
			bool LeftHostler =  ShieldMesh->AttachToComponent(instigator->GetMesh(), Rules,HostlerShieldSocket);
			//bool RightHostler =  RightWeaponMesh->AttachToComponent(instigator->GetMesh(), Rules,HostlerRightSocketName);
			
		}, DelayTime, false);
		
	}
	else
	{
		equippeShield(instigator);
		/*CurrentWeaponPositionSocket = EquipeLeftHandSocketName;
		UAnimMontage* MontageToPlay = WeaponInfo.maSheathAnimations.FindRef("DrawWeaponMontag");
		
		instigator->PlayAnimMontage(MontageToPlay);
		float DelayTime = 0.1f;
		
		GetWorldTimerManager().SetTimer(TimerHandle, [this ,instigator ,Rules]() {
			bool LeftEquipe =  LeftWeaponMesh->AttachToComponent(instigator->GetMesh(), Rules,EquipeLeftHandSocketName);
			bool RightEquipe =  RightWeaponMesh->AttachToComponent(instigator->GetMesh(), Rules,EquipeRightHandSocketName);
		}, DelayTime, false);*/
	
		
	}
	return ShieldDrawState;
}

void AKiteShield::StartShieldDefence(ACombatPlayerCharacter* instigator , bool Pressed)
{
	if(Pressed){
	Super::StartShieldDefence(instigator , Pressed);
	FTimerHandle LoopingFunctionTimerHandle;
		//ShieldDrawState = true;
		InteractComponent->DefenceAssaultStats = E_DefenceAssaultStats::StartDefenceAssault;
		//InteractComponent->bIsStartSheildActivate =true;
		instigator->ShieldAnimationSequence = ShieldStats.ShieldAmimationSequence;
		
	/*if((instigator->GetCurrentMontage()==MontageToPlay))
	{
	//Do Nothing
	}
	else
	{
		instigator->PlayAnimMontage(MontageToPlay);
	}*/
}
else
{
	//ShieldDrawState = false;
	//InteractComponent->bIsStartSheildActivate =false;
	InteractComponent->DefenceAssaultStats = E_DefenceAssaultStats::EndDefenceAssault;
	//instigator->StopAnimMontage(MontageToPlay);
}
        /*if(!DefenceAnimIsPlaying)
        {
		if (Pressed)
		{
			instigator->PlayAnimMontage(MontageToPlay , true);
			DefenceAnimIsPlaying=true;
			float DelayTime = 1.0f;

			// Call the function with the specified delay using a lambda function
			GetWorldTimerManager().SetTimer(TimerHandle, [this ,instigator ,MontageToPlay]() {
			
				DefenceAnimIsPlaying=false;
				//bool Attached =  ShieldMesh->AttachToComponent(instigator->GetMesh(), Rules,LeftShieldHandSocket);
		
			},DelayTime, false);
			
			// Start the looping function with a delay of 1 second
			/*GetWorldTimerManager().SetTimer(LoopingFunctionTimerHandle, [this ,instigator ,MontageToPlay]()
			{
				instigator->PlayAnimMontage(MontageToPlay);
			}, 0.1f, true);#1#
		}
		else
		{
			// Stop the looping function and clear the timer
			GetWorldTimerManager().ClearTimer(LoopingFunctionTimerHandle);
		}
        }*/
	}



/*
void AKiteShield::equippeShield(ACombatPlayerCharacter* instigator)
{
	Super::equippeShield(instigator);
	FAttachmentTransformRules Rules = FAttachmentTransformRules::SnapToTargetNotIncludingScale ;
	ShieldDrawState= true;
	
	UAnimMontage* MontageToPlay = WeaponInfo.maSheathAnimations.FindRef("DrawWeaponMontag");
		
	instigator->PlayAnimMontage(MontageToPlay);
	float DelayTime = 0.3f;
		
	GetWorldTimerManager().SetTimer(TimerHandle, [this ,instigator ,Rules]() {
		bool LeftEquipe =  LeftWeaponMesh->AttachToComponent(instigator->GetMesh(), Rules,EquipeLeftHandSocketName);
		bool RightEquipe =  RightWeaponMesh->AttachToComponent(instigator->GetMesh(), Rules,EquipeRightHandSocketName);
	}, DelayTime, false);
	
}

void AKiteShield::hostlerAndDrawShield(ACombatPlayerCharacter* instigator)
{
	Super::hostlerAndDrawShield(instigator);
}




void ADualWield::equippeWeapon(ACombatPlayerCharacter* instigator)
{
	Super::equippeWeapon(instigator);
	FAttachmentTransformRules Rules = FAttachmentTransformRules::SnapToTargetNotIncludingScale ;
	WeaponDrawState= true;
	
	UAnimMontage* MontageToPlay = WeaponInfo.maSheathAnimations.FindRef("DrawWeaponMontag");
		
	instigator->PlayAnimMontage(MontageToPlay);
	float DelayTime = 0.3f;
		
	GetWorldTimerManager().SetTimer(TimerHandle, [this ,instigator ,Rules]() {
		bool LeftEquipe =  LeftWeaponMesh->AttachToComponent(instigator->GetMesh(), Rules,EquipeLeftHandSocketName);
		bool RightEquipe =  RightWeaponMesh->AttachToComponent(instigator->GetMesh(), Rules,EquipeRightHandSocketName);
	}, DelayTime, false);
	
	//bool LeftEquipe =  LeftWeaponMesh->AttachToComponent(instigator->GetMesh(), Rules,EquipeLeftHandSocketName);
	//bool RightEquipe =  RightWeaponMesh->AttachToComponent(instigator->GetMesh(), Rules,EquipeRightHandSocketName);
}

void ADualWield::hostlerAndDrawWeapon(ACombatPlayerCharacter* instigator)
{
	Super::hostlerAndDrawWeapon(instigator);

	FAttachmentTransformRules Rules = FAttachmentTransformRules::SnapToTargetNotIncludingScale ;
	if(WeaponDrawState)
	{
		WeaponDrawState= false;
		UAnimMontage* MontageToPlay = WeaponInfo.maSheathAnimations.FindRef("HostlerWeaponMontag");
		instigator->PlayAnimMontage(MontageToPlay);
	
		float DelayTime = 0.3f;
		
		GetWorldTimerManager().SetTimer(TimerHandle, [this ,instigator ,Rules]() {
		
			//UE_LOG(LogTemp, Warning, TEXT("Delayed execution!"));
			bool LeftHostler =  LeftWeaponMesh->AttachToComponent(instigator->GetMesh(), Rules,HostlerLeftSocketName);
			bool RightHostler =  RightWeaponMesh->AttachToComponent(instigator->GetMesh(), Rules,HostlerRightSocketName);
			
		}, DelayTime, false);
		
	}
	else
	{
		equippeWeapon(instigator);
		/*CurrentWeaponPositionSocket = EquipeLeftHandSocketName;
		UAnimMontage* MontageToPlay = WeaponInfo.maSheathAnimations.FindRef("DrawWeaponMontag");
		
		instigator->PlayAnimMontage(MontageToPlay);
		float DelayTime = 0.1f;
		
		GetWorldTimerManager().SetTimer(TimerHandle, [this ,instigator ,Rules]() {
			bool LeftEquipe =  LeftWeaponMesh->AttachToComponent(instigator->GetMesh(), Rules,EquipeLeftHandSocketName);
	        bool RightEquipe =  RightWeaponMesh->AttachToComponent(instigator->GetMesh(), Rules,EquipeRightHandSocketName);
		}, DelayTime, false);#1#
	
		
	}*/

