// Fill out your copyright notice in the Description page of Project Settings.


#include "UMG/ScreenWidget.h"

#include <string>

#include "MathUtil.h"
#include "Components/ProgressBar.h"
#include "Components/StatsWidgetComponent.h"
#include "Components/TextBlock.h"
#include "Engine/RendererSettings.h"

void UScreenWidget::SetScreenStaminaPercentage(float Value)
{
	if(IsValid(ScreenStaminaBar))
	{
		ScreenStaminaBar->SetPercent(Value);
	}
	
}

void UScreenWidget::SetScreenHealthPercentage(float Value)
{
	if(IsValid(ScreenHealthaBar) && IsValid((HealthText)))
	{
		ScreenHealthaBar->SetPercent(Value);
		const int32 FinalValue = FMath::Clamp(Value*100,0,100);
		HealthText->SetText(FText::AsNumber(FinalValue));
	}
}

void UScreenWidget::NativeConstruct()
{
	Super::NativeConstruct();
	
}

void UScreenWidget::InitializeScreenWidget(UStatsWidgetComponent* OwnerStatsWidgetComponent)
{
	if(IsValid(OwnerStatsWidgetComponent))
	{
		StatsWidgetComponent = OwnerStatsWidgetComponent;
		OwnerStatsWidgetComponent->PlayerHealthChangeDelegate.AddDynamic(this,&UScreenWidget::SetScreenHealthPercentage);
	}
	//PlayerHealthChangeDelegate.AddDynamic(ScreenWidget, &UScreenWidget::SetScreenHealthPercentage);
}
