// Fill out your copyright notice in the Description page of Project Settings.


#include "UMG/CrossHairWidget.h"

#include "Components/Image.h"

void UCrossHairWidget::NativeConstruct()
{
	Super::NativeConstruct();

	/*if (CrosshairImage)
	{
		// Get the size of the viewport
		FVector2D ViewportSize;
		if (GEngine && GEngine->GameViewport)
		{
			GEngine->GameViewport->GetViewportSize(ViewportSize);
		}

		// Calculate the position to center the crosshair
		FVector2D CrosshairSize = CrosshairImage->GetDesiredSize();
		FVector2D CrosshairPosition = (ViewportSize - CrosshairSize) * 0.5f;

		// Set the position of the crosshair
		CrosshairImage->
	}*/
}
