// Fill out your copyright notice in the Description page of Project Settings.


#include "UMG/WorldWidget.h"

#include "Components/ProgressBar.h"
#include "Components/StatsWidgetComponent.h"
#include "Components/TextBlock.h"

void UWorldWidget::SetHealthPercentage(float Value)
{
	if(IsValid(HealthBar))
	{
		HealthBar->SetPercent(Value);
		const int32 FinalValue = FMath::Clamp(Value*100,0,100);
		HealthText->SetText(FText::AsNumber(FinalValue));
	}
}

void UWorldWidget::InitializeWorldWidget(UStatsWidgetComponent* OwnerStatsWidgetComponent)
{
	if(IsValid(OwnerStatsWidgetComponent))
	{
		StatsWidgetComponent =OwnerStatsWidgetComponent;
		OwnerStatsWidgetComponent->PlayerHealthChangeDelegate.AddDynamic(this,&UWorldWidget::SetHealthPercentage);
	}
}

