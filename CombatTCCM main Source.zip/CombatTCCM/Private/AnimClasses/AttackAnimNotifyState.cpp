// Fill out your copyright notice in the Description page of Project Settings.


#include "AnimClasses/AttackAnimNotifyState.h"

#include "Components/InteractComponent.h"
#include "Kismet/KismetSystemLibrary.h"

void UAttackAnimNotifyState::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation,
                                         float TotalDuration, const FAnimNotifyEventReference& EventReference)
{
	Super::NotifyBegin(MeshComp, Animation, TotalDuration, EventReference);
	PlayerCharacter =Cast<ACombatPlayerCharacter>(MeshComp->GetOwner());
	if(PlayerCharacter)
	{
		InteractComponent= Cast<UInteractComponent>(PlayerCharacter->GetComponentByClass(UInteractComponent::StaticClass()));
		InteractComponent->AttackingAndShielding = E_AttackingAndShielding::Attacking;
		
	}
	//InteractComponent->AttackStates = E_AttackStats::StartAttack;
}

void UAttackAnimNotifyState::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation,
	const FAnimNotifyEventReference& EventReference)
{
	Super::NotifyEnd(MeshComp, Animation, EventReference);
	PlayerCharacter =Cast<ACombatPlayerCharacter>(MeshComp->GetOwner());

	if(PlayerCharacter)
	{
		InteractComponent= Cast<UInteractComponent>(PlayerCharacter->GetComponentByClass(UInteractComponent::StaticClass()));
		InteractComponent->AttackingAndShielding = E_AttackingAndShielding::None;
	}
//	InteractComponent->AttackStates = E_AttackStats::EndAttack;
}

void UAttackAnimNotifyState::NotifyTick(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation,
	float FrameDeltaTime, const FAnimNotifyEventReference& EventReference)
{
	Super::NotifyTick(MeshComp, Animation, FrameDeltaTime, EventReference);
}
