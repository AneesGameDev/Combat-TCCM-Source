// Fill out your copyright notice in the Description page of Project Settings.


#include "AnimClasses/StartEndDefenceAnimTrigger.h"
#include "Components/InteractComponent.h"

void UStartEndDefenceAnimTrigger::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation,
                                       float TotalDuration, const FAnimNotifyEventReference& EventReference)
{
	Super::NotifyBegin(MeshComp, Animation, TotalDuration, EventReference);
	
    PlayerCharacter= Cast<ACombatPlayerCharacter>(MeshComp->GetOwner());
	if(PlayerCharacter)
	{
		InteractComponent= Cast<UInteractComponent>(PlayerCharacter->GetComponentByClass(UInteractComponent::StaticClass()));
		//InteractComponent->DefenceAssaultStats = E_DefenceAssaultStats::StartDefenceAssault;
		//InteractComponent->DefenceAssaultStats = E_DefenceAssaultStats::StartDefenceAssault;
	}

	
}

void UStartEndDefenceAnimTrigger::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation,
	const FAnimNotifyEventReference& EventReference)
{
	Super::NotifyEnd(MeshComp, Animation, EventReference);

	PlayerCharacter= Cast<ACombatPlayerCharacter>(MeshComp->GetOwner());
	if(PlayerCharacter)
	{
		//InteractComponent= Cast<UInteractComponent>(PlayerCharacter->GetComponentByClass(UInteractComponent::StaticClass()));
		//InteractComponent->AttackStates = E_AttackStats::EndAttack;
		//InteractComponent->DefenceAssaultStats = E_DefenceAssaultStats::EndDefenceAssault;
	}
}

void UStartEndDefenceAnimTrigger::NotifyTick(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation,
	float FrameDeltaTime, const FAnimNotifyEventReference& EventReference)
{
	Super::NotifyTick(MeshComp, Animation, FrameDeltaTime, EventReference);
}
