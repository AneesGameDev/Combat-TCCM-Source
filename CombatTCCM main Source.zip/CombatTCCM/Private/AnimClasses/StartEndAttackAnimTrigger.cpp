// Fill out your copyright notice in the Description page of Project Settings.


#include "AnimClasses/StartEndAttackAnimTrigger.h"

#include "KismetAnimationLibrary.h"
#include "Components/InteractComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Net/UnrealNetwork.h"

void UStartEndAttackAnimTrigger::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation,
                                             float TotalDuration, const FAnimNotifyEventReference& EventReference)
{
	Super::NotifyBegin(MeshComp, Animation, TotalDuration, EventReference);
	PlayerCharacter= Cast<ACombatPlayerCharacter>(MeshComp->GetOwner());
	
	if(PlayerCharacter && PlayerCharacter->InteractComponent)
	{
		if(const auto Weapon = PlayerCharacter->InteractComponent->GetReadyWeapon())
		{
			if(UKismetSystemLibrary::IsServer(Weapon) && Weapon->HasAuthority())
			{
				PlayerCharacter->InteractComponent->AttackStates = E_AttackStats::StartAttack;
				Weapon->SetStartAttackSocketLocation();

			}
		}
	}
}

	




void UStartEndAttackAnimTrigger::NotifyTick(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation,
                                            float FrameDeltaTime, const FAnimNotifyEventReference& EventReference)
{
	Super::NotifyTick(MeshComp, Animation, FrameDeltaTime, EventReference);
	
	PlayerCharacter = Cast<ACombatPlayerCharacter>(MeshComp->GetOwner());
	if (IsValid(PlayerCharacter) && PlayerCharacter->InteractComponent)
	{
		if(const auto Weapon = PlayerCharacter->InteractComponent->GetReadyWeapon())
		{
			if( IsValid(Weapon) && UKismetSystemLibrary::IsServer(Weapon) && Weapon->HasAuthority())
			{
				Weapon->StartAttackMechanics(DualWieldIndex);
			}
		}
	}
}
		
				
		




void UStartEndAttackAnimTrigger::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation,
                                           const FAnimNotifyEventReference& EventReference)
{
	Super::NotifyEnd(MeshComp, Animation, EventReference);
     
     	
	//if(UKismetSystemLibrary::IsServer(this)){
	PlayerCharacter= Cast<ACombatPlayerCharacter>(MeshComp->GetOwner());
	if(IsValid(PlayerCharacter) && PlayerCharacter->InteractComponent)
	{
		if(const auto Weapon = PlayerCharacter->InteractComponent->GetReadyWeapon())
		{
			if(UKismetSystemLibrary::IsServer(Weapon) && IsValid(Weapon) && Weapon->HasAuthority())
			{
				PlayerCharacter->InteractComponent->AttackStates = E_AttackStats::EndAttack;
				Weapon->EndAttackMechanics();
			
			}
		}
	}
}




// void UStartEndAttackAnimTrigger::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
// {
// 	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
// 	DOREPLIFETIME(UStartEndAttackAnimTrigger, EquippedWeapon);
// 	DOREPLIFETIME(UStartEndAttackAnimTrigger, InteractComponent);
// 	DOREPLIFETIME(UStartEndAttackAnimTrigger,PlayerCharacter);
// 	
// 	//DOREPLIFETIME(UInteractComponent, EquippeFist);
// 	//DOREPLIFETIME(UInteractComponent, DefenceShield);
// }

/*void UStartEndAttackAnimTrigger::UpdateSocketLocation_Implementation()
{
	if(IsValid(Weapon))
	{
		Weapon->StartAttackMechanics();
	}
}*/

/*void UStartEndAttackAnimTrigger::SetSocketLocation_Implementation()
{
	if(IsValid(Weapon))
	{
		Weapon->SetStartSocketLocations();
	}
}*/