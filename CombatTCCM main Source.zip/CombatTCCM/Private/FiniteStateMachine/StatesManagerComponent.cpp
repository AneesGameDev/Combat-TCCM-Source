// Fill out your copyright notice in the Description page of Project Settings.


#include "FiniteStateMachine/StatesManagerComponent.h"

#include "Net/UnrealNetwork.h"

// Sets default values for this component's properties
UStatesManagerComponent::UStatesManagerComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;
	SetIsReplicatedByDefault(true);

	// ...
}



// Called when the game starts
void UStatesManagerComponent::BeginPlay()
{
	Super::BeginPlay();
	// ...
	
}


// Called every frame
void UStatesManagerComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	// ...
}

bool UStatesManagerComponent::CanMoveCharacter()
{
	return (MoveActionStats != E_MoveActionStats::Jump && MoveActionStats != E_MoveActionStats::Roll );
}

bool UStatesManagerComponent::CanRunCharacter()
{
	return (MoveActionStats != E_MoveActionStats::Jump && MoveActionStats != E_MoveActionStats::Roll && AttackStates !=E_AttackStats::StartAttack && MoveActionStats != E_MoveActionStats::Crouch && CharacterLockStats != E_CharacterLockStats::Locked);
}

bool UStatesManagerComponent::CanJumpCharacter()
{
	return (MoveActionStats != E_MoveActionStats::Roll && AttackStates !=E_AttackStats::StartAttack && MoveActionStats != E_MoveActionStats::Crouch  && CharacterLockStats != E_CharacterLockStats::Locked);
}

bool UStatesManagerComponent::CanCrouchCharacter()
{
	return (MoveActionStats != E_MoveActionStats::Jump && MoveActionStats != E_MoveActionStats::Roll && MoveAxisStats!=E_MoveAxisStats::Run );
}

bool UStatesManagerComponent::CanRollCharacter()
{
	return (MoveActionStats != E_MoveActionStats::Jump && MoveAxisStats!=E_MoveAxisStats::Run && CharacterLockStats != E_CharacterLockStats::Locked);
}

bool UStatesManagerComponent::CanAttackCharacter()
{
	if(DefenceAssaultStats != E_DefenceAssaultStats::EndDefenceAssault) DefenceAssaultStats = E_DefenceAssaultStats::EndDefenceAssault;
	return (
		AttackStates != E_AttackStats::StartAttack &&
		MoveActionStats != E_MoveActionStats::Roll &&
		CharacterLockStats != E_CharacterLockStats::Locked);
}

bool UStatesManagerComponent::CanShieldAssaultCharacter()
{
	return (DefenceAssaultStats != E_DefenceAssaultStats::StartDefenceAssault && AttackStates != E_AttackStats::StartAttack && MoveActionStats != E_MoveActionStats::Roll );
}



void UStatesManagerComponent::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	DOREPLIFETIME(UStatesManagerComponent, MoveAxisStats);
	DOREPLIFETIME(UStatesManagerComponent, MoveActionStats);
	DOREPLIFETIME(UStatesManagerComponent, AttackStates);
	DOREPLIFETIME(UStatesManagerComponent, DefenceAssaultStats);
	DOREPLIFETIME(UStatesManagerComponent, AttackingAndShielding);
	DOREPLIFETIME(UStatesManagerComponent, CharacterLockStats);
	DOREPLIFETIME(UStatesManagerComponent, AimingStats);
}
