// Fill out your copyright notice in the Description page of Project Settings.


#include "Interfaces/CharacterInterface.h"

// Add default functionality here for any ICharacterInterface functions that are not pure virtual.
