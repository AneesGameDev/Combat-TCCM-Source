// Fill out your copyright notice in the Description page of Project Settings.


#include "Components/CombatSystemComponent.h"

#include "Components/InteractComponent.h"

// Sets default values for this component's properties
UCombatSystemComponent::UCombatSystemComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;

	// ...
}


// Called when the game starts
void UCombatSystemComponent::BeginPlay()
{
	Super::BeginPlay();

	// ...
	
}


// Called every frame
void UCombatSystemComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	// ...
}

/*
void UCombatSystemComponent::CombatSystemAttackFunctionality(FHitResult& HitResult, AWeapons* EquippedWeapon , ACombatPlayerCharacter* Character )
{
	//USkeletalMeshComponent* SkeletalMeshComponent = Cast<USkeletalMeshComponent>(HitResult.GetComponent());
	//ACombatPlayerCharacter* TargetCharacter= Cast<ACombatPlayerCharacter>(SkeletalMeshComponent);
	
	if (IsValid(Character))
	{
		FHitInfo HitInfo;
		if (!HittedActorsInfo.Contains(Character))
		{
			TArray<FName> BoneNames;
			BoneNames.Add(HitResult.MyBoneName); // Add the first bone name to the array
			HitInfo.HitResult = HitResult;
			HitInfo.BoneNames = BoneNames;
			HittedActorsArray.Add(Character);
			HittedActorsInfo.Add(Character, HitInfo);
		}
		else
		{
			FHitInfo& ExistingHitInfo = HittedActorsInfo[Character];
			ExistingHitInfo.BoneNames.AddUnique(HitResult.MyBoneName); // Add unique bone names to the array
		}
		
	}
}
*/



/*
void UCombatSystemComponent::CombatSystemAttackFunctionalityRun(AWeapons* EquippedWeapons,const UInteractComponent* OwnerInteractComponent)
{
	for (auto HittedActor : HittedActorsArray)
	{
		UHealthComponent* HealthComponent = Cast<UHealthComponent>(HittedActor->GetComponentByClass(UHealthComponent::StaticClass()));
		UInteractComponent* InteractComponent = Cast<UInteractComponent>(HittedActor->GetComponentByClass(UInteractComponent::StaticClass()));
		if(IsValid(HealthComponent) && IsValid(InteractComponent))
		{
			if(HealthComponent->CharacterBaseHealth>0)
			{
				float Damage = EquippedWeapons->WeaponStats.WeaponBaseDamage* GetMaxDamageFromBoneList(HittedActorsInfo[HittedActor].BoneNames , InteractComponent);
				GEngine->AddOnScreenDebugMessage(-1,2.f,FColor::Red, FString::Printf(TEXT("Apply Damage  ::  %f"),Damage));
				HealthComponent->CharacterBaseHealth-=Damage;
			}
		}
		//OwnerInteractComponent->HealthComponent->CharacterBaseHealth-= GetMaxDamageFromBoneList(HittedActorsInfo[HittedActor].BoneNames , OwnerInteractComponent);
	}
	HittedActorsInfo.Empty();
	HittedActorsArray.Empty();
}
*/

float UCombatSystemComponent::GetMaxDamageFromBoneList(const TArray<FName>& BoneNames,const
	UInteractComponent* OwnerInteractComponent)
{
	float MaxDamage = 0.0f;

	for (const FName& BoneName : BoneNames)
	{
		if (OwnerInteractComponent->BoneDamageMultipliers.Contains(BoneName))
		{
			float DamageMultiplier = OwnerInteractComponent->BoneDamageMultipliers[BoneName];
			MaxDamage = FMath::Max(MaxDamage, DamageMultiplier);
		}
	}

	return MaxDamage;
}

