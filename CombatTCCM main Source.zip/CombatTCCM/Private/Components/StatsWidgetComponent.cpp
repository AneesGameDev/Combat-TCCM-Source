// Fill out your copyright notice in the Description page of Project Settings.


#include "Components/StatsWidgetComponent.h"
#include "Blueprint/UserWidget.h"
#include "CombatTCCM/CombatHUD.h"
#include "Components/WidgetComponent.h"
#include "Net/UnrealNetwork.h"

// Sets default values for this component's properties
UStatsWidgetComponent::UStatsWidgetComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;

	// ...
	
	
	
}



// Called when the game starts
void UStatsWidgetComponent::BeginPlay()
{
	Super::BeginPlay();
	
	OwnerPlayerCharacterRef =Cast<ACombatPlayerCharacter>(GetOwner()) ;

}



// Called every frame
void UStatsWidgetComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
	//PlayerHealthChangeDelegate.Broadcast(0.5f);

	// ...
}

void UStatsWidgetComponent::CreateWorldWidget(UWidgetComponent* WidgetComponent)
{
	if(!IsValid(WidgetComponent)) return;
	
	CharacterWidgetComponent = WidgetComponent;
	CharacterWidgetComponent->SetWidgetClass(WorldWidgetClass);
	CharacterWidgetComponent->SetWidgetSpace(EWidgetSpace::Screen);
	CharacterWidgetComponent->SetDrawAtDesiredSize(true);
	auto* WidgetHealth = Cast<UWorldWidget>(CharacterWidgetComponent->GetWidget());
	
	
	if(IsValid(WidgetHealth))
	{
		WidgetHealth->InitializeWorldWidget(this);
		//PlayerHealthChangeDelegate.AddDynamic(WidgetHealth, &UWorldWidget::SetHealthPercentage);
	}
	
}

void UStatsWidgetComponent::CreateScreenWidgets()
{
		if(IsValid(ScreenWidgetClass))
		{
			ScreenWidget = Cast<UScreenWidget>(CreateWidget(GetWorld(), ScreenWidgetClass ));
			ScreenWidget->AddToViewport();
			if(IsValid(ScreenWidget))
			{
				ScreenWidget->InitializeScreenWidget(this);
			}
		}
	
}


void UStatsWidgetComponent::SetHealthDamage(float Damage)
{
 	CharacterBaseHealth-= Damage;
	if(CharacterBaseHealth<=0) GetOwner()->Destroy();
   
	
}

bool UStatsWidgetComponent::SetStaminaDamage(float Damage)
{
	CurrentStamina-=Damage;
	
	if(CurrentStamina<=0.f) return true;
	return  false;
	
}

void UStatsWidgetComponent::IncreaseStaminaOverTime(float DeltaTime)
{
	if (CurrentStamina < MaxStamina)
	{
		CurrentStamina += (DeltaTime * 2); // Increase by 10 units per second (adjust as needed)
		CurrentStamina = FMath::Clamp(CurrentStamina, 0, MaxStamina); // Clamp within 0 to MaxStamina
        OnRep_UpdateStaminaWidget();
	}
	
}

void UStatsWidgetComponent::OnRep_UpdateHealthWidget() const
{
	float MaxDamage = FMath::Max(CharacterBaseHealth , 0.0f);
	float DamagePercentage = CharacterBaseHealth/CharacterMaxHealth;
	DamagePercentage = FMath::Clamp(DamagePercentage, 0, CharacterMaxHealth);
	PlayerHealthChangeDelegate.Broadcast(DamagePercentage);
	/*if(IsValid(CharacterWidgetComponent))
	{
		auto* WidgetHealth = Cast<UWorldWidget>(CharacterWidgetComponent->GetWidget());
		if(IsValid(WidgetHealth))
		{
			
			//WidgetHealth->SetHealthPercentage(DamagePercentage);
			if(IsValid(ScreenWidget))
			{

				//ScreenWidget->SetScreenHealthPercentage(DamagePercentage);
			} //ScreenWidget->SetScreenHealthPercentage(DamagePercentage);
			/*if(IsValid(OwnerPlayerCharacterRef) && IsValid(OwnerPlayerCharacterRef->PlayerHUDRef))
			{
				OwnerPlayerCharacterRef->PlayerHUDRef->ScreenWidget->SetScreenHealthPercentage(DamagePercentage);
			}#1#
			
		}
	}*/
}

void UStatsWidgetComponent::OnRep_UpdateStaminaWidget() const
{
if(IsValid(ScreenWidget))
{
	
	const float Percentage = CurrentStamina/MaxStamina;
	ScreenWidget->SetScreenStaminaPercentage(Percentage);
	//const float Percentage = BaseStamina/MaxStamina;
	//ScreenWidget->SetStaminaPercentage(Percentage);
}
}

void UStatsWidgetComponent::PostInitProperties()
{
	Super::PostInitProperties();

	/*OwnerPlayerCharacterRef =Cast<ACombatPlayerCharacter>(GetOwner()) ;
	if(IsValid(OwnerPlayerCharacterRef))
	{
		PlayerControllerRef = Cast<ACombatPlayerController>(OwnerPlayerCharacterRef->GetController());
		if(IsValid(PlayerControllerRef))
		{
			//if(PlayerControllerRef.Serve)
			CreateWorldWidget(OwnerPlayerCharacterRef->CharacterWorldWidgetComponent);
			//CreateScreenWidgets(PlayerControllerRef,ScreenWidgetClass);
		}
	}*/
	
	
}


/*
void UStatsWidgetComponent::OnRep_UpdateStaminaWidget()
{
}*/


/*void UStatsWidgetComponent::CreateScreenWidgets(ACombatPlayerController* OwningPlayerController ,TSubclassOf<UUserWidget> SpawnedWidgetClass)
{
	if(!OwningPlayerController && !SpawnedWidgetClass) return;
	
	ScreenWidget = Cast<UScreenWidget>(CreateWidget(OwningPlayerController, SpawnedWidgetClass ));
	ScreenWidget->AddToViewport();
	//ScreenWidget->InitializeScreenWidget(this);
	
}*/



void UStatsWidgetComponent::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps ) const
{
	//DOREPLIFETIME(UStatsWidgetComponent, CharacterWidgetComponent);
	DOREPLIFETIME(UStatsWidgetComponent,CharacterBaseHealth);
	//DOREPLIFETIME(UStatsWidgetComponent,PlayerHealthChangeDelegate);
	DOREPLIFETIME_CONDITION(UStatsWidgetComponent ,CurrentStamina , COND_OwnerOnly)
//	DOREPLIFETIME(UStatsWidgetComponent,BaseStamina);
}
