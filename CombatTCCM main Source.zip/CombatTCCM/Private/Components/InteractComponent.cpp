// Fill out your copyright notice in the Description page of Project Settings.


#include "Components/InteractComponent.h"
#include "Components/StatsWidgetComponent.h"
#include "Net/UnrealNetwork.h"
#include "Weapons/ArcheryAssaults.h"


// Sets default values for this component's properties
UInteractComponent::UInteractComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;
	SetIsReplicatedByDefault(true);
	// ...
}




// Called when the game starts
void UInteractComponent::BeginPlay()
{
	Super::BeginPlay();

	PlayerCharacter = Cast<ACombatPlayerCharacter>(GetOwner());
	
	// ...
	if (PlayerCharacter)
	{
		//equipCharacterWithNewWeapon();


		CombatSystemComponent = Cast<UCombatSystemComponent>(
			PlayerCharacter->GetComponentByClass(UCombatSystemComponent::StaticClass()));
		StatsWidgetComponent = Cast<UStatsWidgetComponent>(PlayerCharacter->GetComponentByClass(UStatsWidgetComponent::StaticClass()));

		//equipeCharacterWithFists();  // For Single Player This Fist Function Works Fine But For Multiplayer Server Fist Function Works Fine
		Server_EquipeFist(true);
	}
	
	
	
}


// Called every frame
void UInteractComponent::TickComponent(float DeltaTime, ELevelTick TickType,
                                       FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
    
	// ...
}

/*void UInteractComponent::Interaction(bool pressed)
{
	equipCharacterWithNewWeapon();
}

void UInteractComponent::DrawWeapon(bool pressed)
{
	drawAndSheathWeapon();
	
}

void UInteractComponent::DrawShield(bool pressed)
{
	equipCharacterWithNewShield();
}

void UInteractComponent::StartPrimaryAttack(bool pressed)
{

	if(!PlayerCharacter  && !EquippedWeapon) return;

	if (IsValid(EquippedWeapon) )
	{
		EquippedWeapon->startAttackMechanics(PlayerCharacter);
	}

}


void UInteractComponent::StartPrimaryDefence(bool pressed)
{
	if (!PlayerCharacter && !EquippedWeapon) return;

	
	if (EquippedWeapon->WeaponStats.WeaponType != EE_WeaponEquipped::AxeShield)
	{
		EquippedWeapon->startShieldAssault(PlayerCharacter, pressed);
	}
	else if (DefenceShield && DefenceShield->ShieldDrawState)
	{
		DefenceShield->StartShieldDefence(PlayerCharacter, pressed);
	}
}*/

void UInteractComponent::EquippeWeapon_Implementation(bool pressed)
{
	IInteractionMechanicsInterface::EquippeWeapon_Implementation(pressed);
	//equipCharacterWithNewWeapon();
	//equipCharacterWithNewWeapon();
	//ServerEquipWeapon(pressed);
	Server_EquipeWeapon(pressed);
}

void UInteractComponent::DrawAndSheathWeapon_Implementation(bool pressed)
{
	IInteractionMechanicsInterface::DrawAndSheathWeapon_Implementation(pressed);
	//drawAndSheathWeapon();

	Server_DrawAndSheathWeapon(true);
}

void UInteractComponent::DrawAndSheathShield_Implementation(bool pressed)
{
	IInteractionMechanicsInterface::DrawAndSheathShield_Implementation(pressed);
	equipCharacterWithNewShield();
}

void UInteractComponent::StartPrimaryAttack_Implementation(bool pressed)
{
	//InteractionMechanicsInterface::StartPrimaryAttack_Implementation(pressed);
	const bool CanAttack = CanAttackCharacter();
	
	if(CanAttack)
	{
		FVector StartAttackLocation;
		FVector AttackDirection;
		if(PlayerCharacter->bIsAiming)
		{
			//EquippedWeapon->SetAimingWeaponDirection();
			APlayerController* PlayerController = Cast<APlayerController>(PlayerCharacter->GetController());

			if (PlayerController)
			{
				ULocalPlayer* LocalPlayer = Cast<ULocalPlayer>(PlayerController->Player);

				if (LocalPlayer)
				{
					// Get the player's viewport size
				
					int32 ViewportX, ViewportY;
					PlayerController->GetViewportSize(ViewportX, ViewportY);

					// Calculate the screen center
					FVector2D ScreenCenter(ViewportX / 2, ViewportY / 2);

					
					// Convert the screen center to a world-space location and direction
					//FVector WorldLocation, WorldDirection;
					PlayerController->DeprojectScreenPositionToWorld(ScreenCenter.X, ScreenCenter.Y, StartAttackLocation, AttackDirection);

					
					//StartAttackLocation = WorldLocation;
				
				}
			}
		}
		Server_StartPrimaryAttack(pressed ,StartAttackLocation,AttackDirection ) ;
	}
	/*if (!PlayerCharacter) return;

	if (IsValid(EquippedWeapon) && EquippedWeapon->WeaponDrawState)
	{
		EquippedWeapon->StartAttackVisuals(PlayerCharacter);
	}
	else if (IsValid(EquippeFist))
	{
		EquippeFist->StartAttackVisuals(PlayerCharacter);
	}*/
}

void UInteractComponent::StartPrimaryDefence_Implementation(bool pressed)
{
	IInteractionMechanicsInterface::StartPrimaryDefence_Implementation(pressed);

	/*if (!PlayerCharacter) return;

	if (IsValid(EquippedWeapon) && EquippedWeapon->WeaponDrawState)
	{
		if (EquippedWeapon->WeaponStats.WeaponType != EE_WeaponEquipped::AxeShield)
		{
			EquippedWeapon->DrawAndSheathShieldAssaults(PlayerCharacter, pressed);
		}
		else if (DefenceShield && DefenceShield->ShieldDrawState)
		{
			DefenceShield->StartShieldDefence(PlayerCharacter, pressed);
		}
	}
	else if (IsValid(EquippeFist))
	{
		EquippeFist->DrawAndSheathShieldAssaults(PlayerCharacter, pressed);
	}*/



	if (!IsValid(PlayerCharacter)) return;

	if (IsValid(EquippedWeapon) && EquippedWeapon->WeaponDrawState)
	{
		if (EquippedWeapon->WeaponStats.WeaponType == EE_WeaponEquipped::DualWield)
			if(auto Weapon = Cast<AArcheryAssaults>(EquippedWeapon))
			{
				Weapon->CameraZoomeClientRPC(pressed);
			}
	}
	Server_StartPrimaryDefence(pressed);
}

void UInteractComponent::TemporarySetAimingDriection()
{


}

/*void UInteractComponent::ServerEquipWeapon_Implementation(bool pressed)
{

	/*FActorSpawnParameters SpawnParam;
	SpawnParam.Owner = Cast<APawn>(GetOwner());

	EquippedWeapon = GetWorld()->SpawnActor<AWeapons>(WeaponsArray[0],
	                                                  PlayerCharacter->GetActorLocation(),
	                                                  PlayerCharacter->GetActorRotation(), SpawnParam);
	EquippedWeapon->SetReplicates(true);#1#
	//TestingEquipeCharacterWithNewWeapon();
	EquipeWeaponMulticast(pressed);
}*/
void UInteractComponent::Server_EquipeWeapon_Implementation(bool pressed)
{
	equipCharacterWithNewWeapon();
}

void UInteractComponent::Server_EquipeFist_Implementation(bool pressed)
{
    equipeCharacterWithFists();
}


void UInteractComponent::EquipeWeaponMulticast_Implementation(bool pressed)
{
	/*FActorSpawnParameters SpawnParam;
	SpawnParam.Owner = Cast<APawn>(GetOwner());

	EquippedWeapon = GetWorld()->SpawnActor<AWeapons>(WeaponsArray[1],
													  PlayerCharacter->GetActorLocation(),
													  PlayerCharacter->GetActorRotation(), SpawnParam);
	EquippedWeapon->SetReplicates(true);*/
	equipCharacterWithNewWeapon();
}


void UInteractComponent::ApplyAttackMechanics(const FHitAndBoneInfo HitAndBoneInfo, AWeapons* AttackerWeapon)
{
	
	             float MaxBoneDamage = (AttackerWeapon->WeaponStats.WeaponBaseDamage * GetCalculateMaxBoneDamage(HitAndBoneInfo.BoneNames));
				if(DefenceAssaultStats == E_DefenceAssaultStats::StartDefenceAssault)
				{
					MaxBoneDamage *= GetCalculateFinalDefenseDamage(AttackerWeapon);
				}
				GEngine->AddOnScreenDebugMessage(-1, 2.f, FColor::Red,
												 FString::Printf(TEXT("Line 235 ,InterActComponent--->Apply Damage  ::  %f"), MaxBoneDamage));
				//SetHealthDamage
				StatsWidgetComponent->SetHealthDamage(MaxBoneDamage);
			
		

}

/*void UInteractComponent::InteractAttackFunctionality(FHitResult& HitResult, ACombatPlayerCharacter* Character)
{
}*/

/*void UInteractComponent::InteractAttackFunctionality(FHitResult& HitResult, ACombatPlayerCharacter* Character)
{
	if (EquippedWeapon->WeaponDrawState)
	{
		CombatSystemComponent->CombatSystemAttackFunctionality(HitResult, EquippedWeapon, Character);
	}
}*/

/*void UInteractComponent::StartAttackMechanics(FHitResult& HitResult, AWeapons* HitWeapon)
{
	/*if (IsValid(HitWeapon))
	{
		FHitInfo HitInfo;
		if (!HittedActorsInfo.Contains(HitWeapon))
		{
			TArray<FName> BoneNames;
			BoneNames.Add(HitResult.MyBoneName); // Add the first bone name to the array
			HitInfo.HitResult = HitResult;
			HitInfo.BoneNames = BoneNames;
			//HittedActorsArray.Add(HitCharacter);
			HittedActorsInfo.Add(HitWeapon, HitInfo);
		}
		else
		{
			FHitInfo& ExistingHitInfo = HittedActorsInfo[HitWeapon];
			ExistingHitInfo.BoneNames.AddUnique(HitResult.MyBoneName); // Add unique bone names to the array
		}
	}#1#
}*/

void UInteractComponent::EndAttackMechanics(AWeapons* Weapons)
{
	/*if (HittedActorsInfo.IsEmpty()) return;
	if (!IsValid(Weapons)) return;
	

	if (const FHitInfo* HitInfo = HittedActorsInfo.Find(Weapons))
	{
		
		if (IsValid(HealthComponent) && IsValid(PlayerCharacter))
		{
			 float FinalDamage = (Weapons->WeaponStats.WeaponBaseDamage * GetCalculateFinalBoneDamage(HitInfo->BoneNames));
			if(DefenceAssaultStats == E_DefenceAssaultStats::StartDefenceAssault)
			{
				FinalDamage *= GetCalculateFinalDefenseDamage(Weapons);
			}
			GEngine->AddOnScreenDebugMessage(-1, 2.f, FColor::Red,
											 FString::Printf(TEXT("Line 235 ,InterActComponent--->Apply Damage  ::  %f"), FinalDamage));
			//SetHealthDamage
			HealthComponent->SetHealthDamage(FinalDamage);
		}
		HittedActorsInfo.Remove(Weapons);

	}*/
}

float UInteractComponent::GetCalculateMaxBoneDamage(TArray<FName> HittedBoneNames)
{
	float MaxDamage = 0.0f;

	for (const FName& BoneName : HittedBoneNames)
	{
		if (BoneDamageMultipliers.Contains(BoneName))
		{
			float DamageMultiplier = BoneDamageMultipliers[BoneName];
			MaxDamage = FMath::Max(MaxDamage, DamageMultiplier);
		}
	}

	return MaxDamage;
}

float UInteractComponent::GetCalculateFinalDefenseDamage(AWeapons* AttackerWeapon)
{

	if(IsValid(AttackerWeapon) && IsValid(PlayerCharacter))
	{
		if(IsValid(AttackerWeapon->OwnerInteractComponent) && IsValid(AttackerWeapon->OwnerPlayerCharacter))
		{
			const ACombatPlayerCharacter* AttackerCombatPlayerCharacter = AttackerWeapon->OwnerPlayerCharacter;
			FVector DefendorToAttackerVector = (PlayerCharacter->GetActorLocation() - AttackerCombatPlayerCharacter->GetActorLocation());
			DefendorToAttackerVector.Normalize();
			const float DotProduct = FVector::DotProduct(PlayerCharacter->GetActorForwardVector(),DefendorToAttackerVector);
			const float FinalAngleOfAttack =  (180.0)/UE_DOUBLE_PI * FMath::Acos(DotProduct);
			GEngine->AddOnScreenDebugMessage(-1,2.0f,FColor::Black,FString::Printf(TEXT("Damage Angle is: %f ") , FinalAngleOfAttack));
			if(FinalAngleOfAttack>140.f)
			{
				return 0;
			}
			else
			{
				return 1;
			}
		}
		
	}
	return 0.f;
	
}

//TEmporary Code is Here
void UInteractComponent::Server_StartPrimaryAttack_Implementation(bool pressed , FVector AttackLocation ,FVector AttackDirection)
{
	if (!PlayerCharacter) return;
	
	if (IsValid(EquippedWeapon) && EquippedWeapon->WeaponDrawState)
	{
		EquippedWeapon->AttackLocation = AttackLocation;
		EquippedWeapon->AttackDirection = AttackDirection;
		
		EquippedWeapon->StartAttackVisuals();
		if(PlayerCharacter->StatsWidgetComponent->SetStaminaDamage(EquippedWeapon->WeaponStats.TakeStaminaPerAttack)) CharacterLockStats = E_CharacterLockStats::Locked;
	}
	else if (IsValid(EquippeFist))
	{
		EquippeFist->StartAttackVisuals();
		if(PlayerCharacter->StatsWidgetComponent->SetStaminaDamage(EquippeFist->WeaponStats.TakeStaminaPerAttack)) CharacterLockStats = E_CharacterLockStats::Locked;
	}
	
	
}

void UInteractComponent::Server_StartPrimaryDefence_Implementation(bool pressed)
{

	if (!IsValid(PlayerCharacter)) return;

	if (IsValid(EquippedWeapon) && EquippedWeapon->WeaponDrawState)
	{
		if (EquippedWeapon->WeaponStats.WeaponType != EE_WeaponEquipped::AxeShield)
		{
			EquippedWeapon->DrawAndSheathShieldAssaults(pressed);
		}
		else if (DefenceShield && DefenceShield->ShieldDrawState)
		{
			DefenceShield->StartShieldDefence(PlayerCharacter, pressed);
		}
	}
	else if (IsValid(EquippeFist))
	{
		EquippeFist->DrawAndSheathShieldAssaults(pressed);
	}

	
}
void UInteractComponent::Server_DrawAndSheathWeapon_Implementation(bool pressed)
{
	drawAndSheathWeapon();
}

void UInteractComponent::Server_DrawAndSheathShield_Implementation(bool pressed)
{
}


/*
void UInteractComponent::TestingEquipeCharacterWithNewWeapon()
{
	if (!PlayerCharacter) return;

	//temporary written here


	FActorSpawnParameters SpawnParam;
	SpawnParam.Instigator = Cast<APawn>(GetOwner());


	CurrentWeaponIndex = WeaponIndexIncrement % WeaponsArray.Num();
	WeaponIndexIncrement++;
	EquippedWeapon = GetWorld()->SpawnActor<AWeapons>(WeaponsArray[1],
	                                                  PlayerCharacter->GetActorLocation(),
	                                                  PlayerCharacter->GetActorRotation(), SpawnParam);
	//EquippedWeapon->SetReplicates(true);
	EquippedWeapon->WeaponDrawState = true;
	EquippedWeapon->EquippeWeapon(PlayerCharacter);

	EquippedWeapon->OwnerPlayerCharacter = PlayerCharacter;
	EquippedWeapon->OwnerInteractComponent = this;
}
*/



void UInteractComponent::equipCharacterWithNewWeapon()
{
	if (!PlayerCharacter) return;

	//temporary written here
	
	
	FActorSpawnParameters SpawnParam;
	SpawnParam.Instigator = Cast<APawn>(GetOwner());

	if (IsValid(EquippedWeapon))
	{
		EquippedWeapon->Destroy();
		if (IsValid(DefenceShield))
		{
			DefenceShield->Destroy();
			DefenceShield = nullptr;
		}
		
		//equipeCharacterWithFists();
		Server_EquipeFist(true);
		return;
	}

	if (IsValid(EquippeFist))
	{
		EquippeFist->Destroy();
		CurrentWeaponIndex = WeaponIndexIncrement % WeaponsArray.Num();
		WeaponIndexIncrement++;
		EquippedWeapon = GetWorld()->SpawnActor<AWeapons>(WeaponsArray[CurrentWeaponIndex],
		                                                  PlayerCharacter->GetActorLocation(),
		                                                  PlayerCharacter->GetActorRotation(), SpawnParam);
		//EquippedWeapon->SetReplicates(true);
		EquippedWeapon->EquippeWeapon(PlayerCharacter);
		if (EquippedWeapon->WeaponStats.WeaponType == EE_WeaponEquipped::AxeShield)
		{
			DefenceShield = GetWorld()->SpawnActor<AShields>(ShieldsArray[0], PlayerCharacter->GetActorLocation(),
			                                                 PlayerCharacter->GetActorRotation(), SpawnParam);
			DefenceShield->equippeShield(PlayerCharacter);
		}
		//EquippedWeapon->OwnerPlayerCharacter = PlayerCharacter;
		//EquippedWeapon->OwnerInteractComponent = this;
		return;
	}
	
}

void UInteractComponent::drawAndSheathWeapon()
{
	if (IsValid(EquippedWeapon)) // Sheath Does Not Work If Weapon is Not Availabler
	{
		if (EquippedWeapon->WeaponDrawState)
		{
			EquippedWeapon->DrawAndSheathWeapon();

			if (EquippedWeapon->WeaponStats.WeaponType == EE_WeaponEquipped::AxeShield && IsValid(DefenceShield))
			{
				DefenceShield->hostlerAndDrawShield(PlayerCharacter);
			}
			Server_EquipeFist(true);
		}
		else if (IsValid(EquippeFist))
		{
			EquippeFist->Destroy();
			EquippedWeapon->DrawAndSheathWeapon();

			if (EquippedWeapon->WeaponStats.WeaponType == EE_WeaponEquipped::AxeShield && IsValid(DefenceShield))
			{
				DefenceShield->hostlerAndDrawShield(PlayerCharacter);
			}
		}
	}
}
		



//This Code will be used when separate Shield will be made without any dependencies
void UInteractComponent::equipCharacterWithNewShield()
{
	/*if(!OwnerPlayer) return;;
	FActorSpawnParameters SpawnParam ;
	SpawnParam.Instigator = Cast<APawn>(GetOwner());
	if(!DefenceShield)
	{

		CurrentShieldIndex = ShieldIndexIncrement%ShieldsArray.Num();
		ShieldIndexIncrement++;
		/*switch (WeaponsArray[CurrentWeaponIndex].GetDefaultObject()->WeaponInfo.WeaponType)
		{

			
			case (EE_WeaponEquipped::Fists) : {}
			case (EE_WeaponEquipped::AxeShield) : {}
			case (EE_WeaponEquipped::TwoHanded) :
				{
					EquippedWeapon = GetWorld()->SpawnActor<AWeapons>(WeaponsArray[CurrentWeaponIndex],OwnerPlayer->GetActorLocation(),OwnerPlayer->GetActorRotation() ,SpawnParam );
					//WeaponStats = EquippedWeapon->WeaponInfo;
		
					EquippedWeapon->equippeWeapon(OwnerPlayer);
				}
			case (EE_WeaponEquipped::DualWield) :{}
			
		}#1#

		DefenceShield = GetWorld()->SpawnActor<AShields>(ShieldsArray[ShieldIndexIncrement],OwnerPlayer->GetActorLocation(),OwnerPlayer->GetActorRotation() ,SpawnParam );
		//WeaponStats = EquippedWeapon->WeaponInfo;
			
		DefenceShield->equippeWeapon(OwnerPlayer);
		//WeaponsArray[CurrentWeaponIndex].GetDefaultObject()->WeaponInfo

		//EquippedWeapon = GetWorld()->SpawnActor<AWeapons>(WeaponsArray[CurrentWeaponIndex],OwnerPlayer->GetActorLocation(),OwnerPlayer->GetActorRotation() ,SpawnParam );
		//WeaponStats = EquippedWeapon->WeaponInfo;
			
		//EquippedWeapon->equippeWeapon(OwnerPlayer);
		///OwnerPlayer->GetMesh()->AttactCom
		/*FAttachmentTransformRules Rules = FAttachmentTransformRules::SnapToTargetNotIncludingScale ;
		CurrentSocketName = EquippedWeapon->HandSocketName;
		bool Attached =  EquippedWeapon->WeaponMesh->AttachToComponent(OwnerPlayer->GetMesh(), Rules,CurrentSocketName);#1#
	}else
	{
		EquippedWeapon->Destroy();
		EquippedWeapon=nullptr;
	}*/
}

/*void UInteractComponent::equipeCharacterWithFists()
{
	if (!PlayerCharacter) return;;
	FActorSpawnParameters SpawnParam;
	SpawnParam.Instigator = Cast<APawn>(GetOwner());


	EquippeFist = GetWorld()->SpawnActor<AWeapons>(WeaponsArray[0],
	                                                  PlayerCharacter->GetActorLocation(),
	                                                  PlayerCharacter->GetActorRotation(), SpawnParam);
	EquippeFist->EquippeWeapon(PlayerCharacter);
	EquippeFist->PlayerCharacter = PlayerCharacter;
	EquippeFist->InteractComponent = this;

}*/
void UInteractComponent::equipeCharacterWithFists()
{
	if (!IsValid(PlayerCharacter) || WeaponsArray.Num() == 0) return;

	FActorSpawnParameters SpawnParam;
	SpawnParam.Instigator = Cast<APawn>(GetOwner());

	EquippeFist = GetWorld()->SpawnActor<AWeapons>(
		WeaponsArray[0], PlayerCharacter->GetActorLocation(), PlayerCharacter->GetActorRotation(), SpawnParam);
	
	EquippeFist->WeaponDrawState=true;
	if (EquippeFist)
	{
		EquippeFist->EquippeWeapon(PlayerCharacter);
		EquippeFist->OwnerPlayerCharacter = PlayerCharacter;
		EquippeFist->OwnerInteractComponent = this;
	}
	//GEngine->AddOnScreenDebugMessage(-1,2.f,FColor::Red, GetOwner()->GetActorNameOrLabel());
	if(GetOwner()->GetActorNameOrLabel()=="CombatPlayerCharacter_BP2")
	{
	
		Server_StartPrimaryDefence(true);
	}
	//

	
}


void UInteractComponent::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	DOREPLIFETIME(UInteractComponent, StatsWidgetComponent);
	DOREPLIFETIME(UInteractComponent, EquippedWeapon);
	
	//DOREPLIFETIME(UInteractComponent, EquippeFist);
	//DOREPLIFETIME(UInteractComponent, DefenceShield);
}
