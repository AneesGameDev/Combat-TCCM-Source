// Fill out your copyright notice in the Description page of Project Settings.


#include "Components/CameraZoomComponent.h"

#include "Camera/CameraComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/SpringArmComponent.h"

// Sets default values for this component's properties
UCameraZoomComponent::UCameraZoomComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;

	// ...
}



// Called when the game starts
void UCameraZoomComponent::BeginPlay()
{
	Super::BeginPlay();
	
if(IsValid(CrossHairWidgetClass))
{
	CrossHairWidgetObj = CreateWidget<UCrossHairWidget>(GetWorld(), CrossHairWidgetClass);
	CrossHairWidgetObj->AddToViewport();
	CrossHairWidgetObj->SetVisibility(ESlateVisibility::Hidden);
}
	// ...
	
}


// Called every frame
void UCameraZoomComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	// ...
}



void UCameraZoomComponent::ToggleCameraZoomed(bool bNewZoomed, ACombatPlayerCharacter* PlayerCharacter)
{
	bIsZoomedIn = bNewZoomed;

	if (PlayerCharacter->GetCameraBoom() && PlayerCharacter->GetFollowCamera() && IsValid(CrossHairWidgetObj))
	{
		const APlayerController* PController = Cast<APlayerController>(PlayerCharacter->Controller);

		
		PlayerCharacter->GetCameraBoom()->TargetArmLength = bIsZoomedIn ? ZoomedCameraArmLength : PlayerCharacter->GetDefaultArmLength();
		PlayerCharacter->GetCameraBoom()->SocketOffset =bIsZoomedIn ? ZoomedSocketOffset : PlayerCharacter->GetDefaultSocketOffset() ;
		PlayerCharacter->GetCameraBoom()->TargetOffset = bIsZoomedIn ? ZoomedTargetOffset:PlayerCharacter->GetDefaultTargetOffset() ;
		PlayerCharacter->GetFollowCamera()->FieldOfView = bIsZoomedIn? ZoomedFOV : PlayerCharacter->GetDefaultFOV();
		PController->PlayerCameraManager->ViewPitchMax = bIsZoomedIn ? ZoomedCameraMaxPitch : PlayerCharacter->GetDefaultCameraMaxPitch();
		PController->PlayerCameraManager->ViewPitchMin = bIsZoomedIn ? ZoomedCameraMinPitch : PlayerCharacter->GetDefaultCameraMinPitch();


		PlayerCharacter->GetCameraBoom()->bEnableCameraLag = bIsZoomedIn;
		if(IsValid(CrossHairWidgetObj)) CrossHairWidgetObj->SetVisibility(bIsZoomedIn? ESlateVisibility::Visible :ESlateVisibility::Hidden);
		PlayerCharacter->GetCharacterMovement()->bOrientRotationToMovement = !bIsZoomedIn;
	}
}

