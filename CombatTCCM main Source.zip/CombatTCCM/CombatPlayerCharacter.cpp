// Copyright Epic Games, Inc. All Rights Reserved.

#include "CombatPlayerCharacter.h"
#include "CombatPlayerController.h"
#include "Camera/CameraComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/InputComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/Controller.h"
#include "GameFramework/SpringArmComponent.h"
#include "EnhancedInputComponent.h"
#include "EnhancedInputSubsystems.h"
#include "Components/InteractComponent.h"
#include "GameFramework/Character.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/StatsWidgetComponent.h"
#include "Components/WidgetComponent.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Net/UnrealNetwork.h"


//////////////////////////////////////////////////////////////////////////
// ACombatTCCMCharacter


ACombatPlayerCharacter::ACombatPlayerCharacter()
{
	// Set size for collision capsule
	GetCapsuleComponent()->InitCapsuleSize(42.f, 96.0f);

	// Don't rotate when the controller rotates. Let that just affect the camera.
	bUseControllerRotationPitch = false;
	bUseControllerRotationYaw = false;
	bUseControllerRotationRoll = false;

	// Configure character movement
	GetCharacterMovement()->bOrientRotationToMovement = true; // Character moves in the direction of input...	
	GetCharacterMovement()->RotationRate = FRotator(0.0f, 500.0f, 0.0f); // ...at this rotation rate

	// Note: For faster iteration times these variables, and many more, can be tweaked in the Character Blueprint
	// instead of recompiling to adjust them
	GetCharacterMovement()->JumpZVelocity = 600.f;
	GetCharacterMovement()->AirControl = 0.35f;
	GetCharacterMovement()->MaxWalkSpeed = 300.f;
	GetCharacterMovement()->MinAnalogWalkSpeed = 20.f;
	GetCharacterMovement()->BrakingDecelerationWalking = 2000.f;

	// Create a camera boom (pulls in towards the player if there is a collision)
	CameraBoom = CreateDefaultSubobject<USpringArmComponent>(TEXT("CameraBoom"));
	CameraBoom->SetupAttachment(RootComponent);
	CameraBoom->TargetArmLength = DefaultArmLength; // The camera follows at this distance behind the character	
	CameraBoom->bUsePawnControlRotation = true; // Rotate the arm based on the controller


	// Create a follow camera
	FollowCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("FollowCamera"));
	FollowCamera->SetupAttachment(CameraBoom, USpringArmComponent::SocketName);
	// Attach the camera to the end of the boom and let the boom adjust to match the controller orientation
	FollowCamera->bUsePawnControlRotation = false;
	
	FollowCamera->FieldOfView = DefaultFOV;
	// Camera does not rotate relative to arm


	//EachPlayer HAs It's Own Widget Component Created Here and Passed Reference to Health Component to Update Health , Health Component is Responsible to update health



	
	//Component Attached To Character When Character Created
	CharacterWorldWidgetComponent = CreateDefaultSubobject<UWidgetComponent>(TEXT("CharacterWorldWidgetComonent"));
	
	CharacterWorldWidgetComponent->SetupAttachment(GetMesh(), "HealthWidgetSocket");
	
	InteractComponent = CreateDefaultSubobject<UInteractComponent>(TEXT("InteractComponent"));
	
	StatsWidgetComponent = CreateDefaultSubobject<UStatsWidgetComponent>(TEXT("StatsWidgetComponent"));
	
	
	
	// Note: The skeletal mesh and anim blueprint references on the Mesh component (inherited from Character) 
	// are set in the derived blueprint asset named ThirdPersonCharacter (to avoid direct content references in C++)


	// YourPlayerCharacter.cpp
	/*if(GetMesh())
	{
		GetMesh()->OnComponentHit.AddDynamic(this, &ACombatPlayerCharacter::OnHitCharacterSkeletalMesh);
	}*/

}
void ACombatPlayerCharacter::BeginPlay()
{
	// Call the base class  
	Super::BeginPlay();


	//APlayerController* PController = Cast<APlayerController>(Controller);
	
	
	//Add Input Mapping Context
	if (APlayerController* PlayerController = Cast<APlayerController>(Controller))
	{
		
		if (UEnhancedInputLocalPlayerSubsystem* Subsystem = ULocalPlayer::GetSubsystem<UEnhancedInputLocalPlayerSubsystem>(PlayerController->GetLocalPlayer()))
		{
			Subsystem->AddMappingContext(DefaultMappingContext, 0);
		}
	}
	InteractComponent = Cast<UInteractComponent>(GetComponentByClass(UInteractComponent::StaticClass()));
	PlayerControllerRef = Cast<ACombatPlayerController>(GetController());

	if(IsValid(PlayerControllerRef) && !UKismetSystemLibrary::IsServer(PlayerControllerRef))
	{
		//PlayerHUDRef = Cast<ACombatHUD>(PlayerControllerRef->GetHUD());
	//	if(IsValid(PlayerHUDRef))
		{
			StatsWidgetComponent->CreateScreenWidgets();
		}
	}
	else if (!IsValid(PlayerControllerRef) && !UKismetSystemLibrary::IsServer(PlayerControllerRef) && IsValid(CharacterWorldWidgetComponent))
	{
		StatsWidgetComponent->CreateWorldWidget(CharacterWorldWidgetComponent);
	}

	
	if(auto* PController = Cast<APlayerController>(Controller))
	{
		PController->PlayerCameraManager->ViewPitchMax = DefaultCameraMaxPitch;
		PController->PlayerCameraManager->ViewPitchMin = DefaultCameraMinPitch;

	}
	
	
	
	
	if(IsValid(StatsWidgetComponent) && IsValid(CharacterWorldWidgetComponent) && IsValid(PlayerControllerRef))
	{
		//if(PlayerControllerRef.Serve)
		//StatsWidgetComponent->CreateWorldWidget(CharacterWorldWidgetComponent);
		//StatsWidgetComponent->CreateScreenWidgets(PlayerControllerRef,StatsWidgetComponent->ScreenWidgetClass);
	}
}

void ACombatPlayerCharacter::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	StatsWidgetComponent->IncreaseStaminaOverTime(DeltaSeconds);

	if(StatsWidgetComponent->CurrentStamina>20.f) InteractComponent->CharacterLockStats = E_CharacterLockStats::Unlocked;
}


void ACombatPlayerCharacter::PostInitializeComponents()
{
	Super::PostInitializeComponents();

		if(!IsValid(PlayerControllerRef))
		{
			
		}

	//if(IsValid(StatsWidgetComponent) && IsValid(CharacterWorldWidgetComponent)){
	//	StatsWidgetComponent->CreateWorldWidget(CharacterWorldWidgetComponent);
	
	
}

void ACombatPlayerCharacter::PreInitializeComponents()
{
	Super::PreInitializeComponents();
	/*if (APlayerController* PlayerController = Cast<APlayerController>(Controller))
	{
		if (UEnhancedInputLocalPlayerSubsystem* Subsystem = ULocalPlayer::GetSubsystem<UEnhancedInputLocalPlayerSubsystem>(PlayerController->GetLocalPlayer()))
		{
			Subsystem->AddMappingContext(DefaultMappingContext, 0);
		}
	}
	InteractComponent = Cast<UInteractComponent>(GetComponentByClass(UInteractComponent::StaticClass()));
	PlayerControllerRef = Cast<ACombatPlayerController>(GetController());
	PlayerHUDRef = Cast<ACombatHUD>(PlayerControllerRef->GetHUD());
	PlayerHUDRef->CreateWorldWidget(CharacterWorldWidgetComponent);
	PlayerHUDRef->CreateScreenWidgets();*/
	
}

/*if(IsValid(GetMesh()))
	{
		GetMesh()->OnComponentBeginOverlap.AddDynamic(this, &ACombatPlayerCharacter::OnComponentBeginOvelap);
	}*/

	
	


//////////////////////////////////////////////////////////////////////////
// Input

void ACombatPlayerCharacter::SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent)
{
	// Set up action bindings
	if (UEnhancedInputComponent* EnhancedInputComponent = CastChecked<UEnhancedInputComponent>(PlayerInputComponent))
	{
		//Jumping
		EnhancedInputComponent->BindAction(JumpAction, ETriggerEvent::Triggered, this, &ACharacter::Jump);
		///EnhancedInputComponent->BindAction(JumpAction, ETriggerEvent::Completed, this, &ACharacter::StopJumping);

		//Moving
		//EnhancedInputComponent->BindAction(MoveAction, ETriggerEvent::Triggered, this, &ACombatTCCMCharacter::Move);

		//Looking
		//EnhancedInputComponent->BindAction(LookAction, ETriggerEvent::Triggered, this, &ACombatPlayerCharacter::Look);
	}
}


void ACombatPlayerCharacter::MoveCharacter_Implementation(const FVector2D MoveInput)
{
	if (!IsValid(InteractComponent)) return;

	//FVector2D MovementVector = Value.Get<FVector2D>();
	if (InteractComponent->CanMoveCharacter())
	{
		if (Controller != nullptr)
		{
			// find out which way is forward
			const FRotator Rotation = Controller->GetControlRotation();
			const FRotator YawRotation(0, Rotation.Yaw, 0);

			// get forward vector
			const FVector ForwardDirection = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::X);

			// get right vector 
			const FVector RightDirection = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::Y);

			// add movement 
			AddMovementInput(ForwardDirection, MoveInput.Y);
			AddMovementInput(RightDirection, MoveInput.X);

			if (MoveInput.X <= 0.1f && MoveInput.Y <= 0.1f)
			{
				InteractComponent->MoveAxisStats = E_MoveAxisStats::Idle;
			}
		}
	}
}

void ACombatPlayerCharacter::JumpCharacter_Implementation(bool pressed)
{
	if (InteractComponent->CanJumpCharacter())
	{
		if (IsValid(Controller))
		{
			if (pressed)
			{
				InteractComponent->MoveActionStats = E_MoveActionStats::Jump;
				Jump();
			}
			else
			{
				InteractComponent->MoveActionStats = E_MoveActionStats::None;
				StopJumping();
			}
		}
	}
}

void ACombatPlayerCharacter::RunCharacter_Implementation(bool pressed)
{
	ICharacterInputInterface::RunCharacter_Implementation(pressed);

	if (InteractComponent->CanRunCharacter())
	{
		if (pressed)
		{
			GetCharacterMovement()->MaxWalkSpeed = DefaultCharacterRunSpeed;
			InteractComponent->MoveAxisStats = E_MoveAxisStats::Run;
		}
		else
		{
			GetCharacterMovement()->MaxWalkSpeed = DefaultCharacterWalkSpeed;
			InteractComponent->MoveAxisStats = E_MoveAxisStats::Walk;
		}
	}
	Server_SetRun(pressed);
}

void ACombatPlayerCharacter::CrouchCharacter_Implementation(bool pressed)
{
	ICharacterInputInterface::CrouchCharacter_Implementation(pressed);
	
	Server_SetCrouch(pressed);
}

void ACombatPlayerCharacter::RollCharacter_Implementation(bool pressed)
{
	if (InteractComponent->CanRollCharacter())
		ICharacterInputInterface::RollCharacter_Implementation(pressed);
}

void ACombatPlayerCharacter::Server_SetCrouch_Implementation(bool pressed)
{
	if (InteractComponent->CanCrouchCharacter())
	{
		//bIsPlayerCrouching = pressed;
		
		if (pressed)
		{
			InteractComponent->MoveActionStats = E_MoveActionStats::Crouch;
			GetCharacterMovement()->MaxWalkSpeed = DefaultCharacterCrouchSpeed;
		}
		else
		{
			InteractComponent->MoveActionStats = E_MoveActionStats::None;
			GetCharacterMovement()->MaxWalkSpeed = DefaultCharacterWalkSpeed;
		}
	}
	
}
void ACombatPlayerCharacter::Server_SetRun_Implementation(bool pressed)
{

	if (InteractComponent->CanRunCharacter())
	{
		if (pressed)
		{
			GetCharacterMovement()->MaxWalkSpeed = DefaultCharacterRunSpeed;
			InteractComponent->MoveAxisStats = E_MoveAxisStats::Run;
		}
		else
		{
			GetCharacterMovement()->MaxWalkSpeed = DefaultCharacterWalkSpeed;
			InteractComponent->MoveAxisStats = E_MoveAxisStats::Walk;
		}
	}
}

/*void ACombatPlayerCharacter::StopJump_Implementation()
{
	StopJumping();
}*/

void ACombatPlayerCharacter::LookCharacter_Implementation(const FVector2D MoveInput)
{
	//FVector2D LookAxisVector = MoveInput.Get<FVector2D>();

	if (Controller != nullptr)
	{
	
		AddControllerPitchInput(MoveInput.Y *DefaultCameraSensitivity*  GetWorld()->DeltaTimeSeconds);

		
		// add yaw and pitch input to controller
		AddControllerYawInput(MoveInput.X);


		// Calculate the desired pitch based on player input (0 or 1).
		/*float DesiredPitch = (MoveInput.Y >=0) ? (MaxPitch*MoveInput.Y) : (MinPitch *MoveInput.Y) ;

		// Set the control rotation pitch directly.
		FRotator ControllerRotation = GetControlRotation();
		ControllerRotation.Pitch = DesiredPitch;
		GetController()->SetControlRotation(ControllerRotation);*/
		//AddControllerPitchInput(MoveInput.Y);
		
	}
}



void ACombatPlayerCharacter::Interaction_Implementation(bool pressed)
{
	/**/ /*if(IsValid(InteractComponent))
	{
		InteractComponent->Interaction(pressed);
	}*/
}

void ACombatPlayerCharacter::EquippeWeapon_Implementation(bool pressed)
{
	ICharacterInputInterface::EquippeWeapon_Implementation(pressed);
	if (IsValid(InteractComponent))
	{
		IInteractionMechanicsInterface::Execute_EquippeWeapon(InteractComponent, pressed);
	}
}

void ACombatPlayerCharacter::DrawAndSheathWeapon_Implementation(bool pressed)
{
	if (IsValid(InteractComponent))
	{
		IInteractionMechanicsInterface::Execute_DrawAndSheathWeapon(InteractComponent, pressed);
	}
	else
	{
		
	}
}

void ACombatPlayerCharacter::DrawAndSheathShield_Implementation(bool pressed)
{
	ICharacterInputInterface::DrawAndSheathShield_Implementation(pressed);
}

void ACombatPlayerCharacter::StartPrimaryAttack_Implementation(bool pressed)
{
	if (IsValid(InteractComponent))
	{
		IInteractionMechanicsInterface::Execute_StartPrimaryAttack(InteractComponent, pressed);
	}
}

void ACombatPlayerCharacter::StartPrimaryDefence_Implementation(bool pressed)
{
	if (IsValid(InteractComponent))
	{
		IInteractionMechanicsInterface::Execute_StartPrimaryDefence(InteractComponent, pressed);
	}
}




void ACombatPlayerCharacter::Look(const FInputActionValue& Value)
{
	// input is a Vector2D
	const FVector2D LookAxisVector = Value.Get<FVector2D>();

	if (Controller != nullptr)
	{
		// add yaw and pitch input to controller
		AddControllerYawInput(LookAxisVector.X);
		AddControllerPitchInput(LookAxisVector.Y);
	}
}



void ACombatPlayerCharacter::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	DOREPLIFETIME(ACombatPlayerCharacter, InteractComponent);
	DOREPLIFETIME(ACombatPlayerCharacter, ShieldAnimationSequence);
	DOREPLIFETIME(ACombatPlayerCharacter, CharacterWorldWidgetComponent);
	DOREPLIFETIME(ACombatPlayerCharacter, StatsWidgetComponent);
	DOREPLIFETIME(ACombatPlayerCharacter, bIsAiming );
}
