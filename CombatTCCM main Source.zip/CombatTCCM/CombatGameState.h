// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "CombatTCCM/CombatPlayerCharacter.h"
#include "GameFramework/GameState.h"
#include "CombatGameState.generated.h"

/**
 * 
 */
UCLASS()
class COMBATTCCM_API ACombatGameState : public AGameState
{
	GENERATED_BODY()

public:

	int32 CharacterIdIncrementer;
	void SpawnCharacterWithStateData(TSubclassOf<ACharacter> Character);
};
